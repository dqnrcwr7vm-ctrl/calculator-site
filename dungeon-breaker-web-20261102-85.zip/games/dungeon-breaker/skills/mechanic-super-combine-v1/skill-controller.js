(function(root){
 class SuperCombineSkill {
  constructor(ownerId='mechanic'){this.ownerId=ownerId;this.active=false;this.remainingTurns=0;this.turnId=null;this.endedTurns=new Set();}
  onTurnStart(actorId,turnId){if(actorId!==this.ownerId||turnId==null||this.endedTurns.has(turnId))return false;this.turnId=turnId;return true;}
  eligibleMechs(units){return units.filter(u=>u.ownerId===this.ownerId&&u.kind==='mech'&&u.onField===true&&u.hp>0);}
  canActivate(units){return !this.active&&this.turnId!==null&&this.eligibleMechs(units).length>=2;}
  activate(units){if(!this.canActivate(units))return false;this.active=true;this.remainingTurns=3;return true;}
  onTurnEnd(actorId,turnId){if(actorId!==this.ownerId||turnId!==this.turnId||turnId==null||this.endedTurns.has(turnId))return false;this.endedTurns.add(turnId);this.turnId=null;if(this.active&&--this.remainingTurns===0){this.active=false;return true;}return false;}
  destroy(){this.active=false;this.remainingTurns=0;}
  snapshot(){return {name:'초 합체!',active:this.active,remainingTurns:this.remainingTurns,turnId:this.turnId};}
 }
 if(typeof module!=='undefined'&&module.exports)module.exports=SuperCombineSkill;
 root.SuperCombineSkill=SuperCombineSkill;
})(typeof window==='undefined'?globalThis:window);
