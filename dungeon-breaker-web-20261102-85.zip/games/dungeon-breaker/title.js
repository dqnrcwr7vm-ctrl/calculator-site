(() => {
  'use strict';
  const screen = document.querySelector('.title-screen');
  const video = document.querySelector('#intro');
  const music = document.querySelector('#bgm');
  const still = document.querySelector('#still');
  const menu = document.querySelector('.main-menu');
  const skip = document.querySelector('#skip');
  const replay = document.querySelector('#replay');
  const status = document.querySelector('#status');
  const opening = document.querySelector('#opening-enabled');
  const musicEnabled = document.querySelector('#music-enabled');
  const volume = document.querySelector('#music-volume');
  const volumeValue = document.querySelector('#volume-value');
  const farewell = document.querySelector('.farewell');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let enabled = true;
  let audioSettings = { muted: false, volume: 0.65 };
  try {
    enabled = localStorage.getItem('dungeon-breaker-opening') !== 'off';
    const saved = JSON.parse(localStorage.getItem('dungeon-breaker-audio') || 'null');
    if (saved && typeof saved.muted === 'boolean') audioSettings.muted = saved.muted;
    if (saved && typeof saved.volume === 'number' && Number.isFinite(saved.volume)) audioSettings.volume = Math.max(0, Math.min(1, saved.volume));
  } catch {}
  opening.checked = enabled;
  let operation = 0;
  let wantsIntro = false;
  let videoFailed = false;
  let musicFailed = false;
  const menuItems = [...menu.querySelectorAll('.menu-button'), replay];
  const menuPointer = menu.querySelector('.pointer');
  let selectedMenu = 0;

  function selectMenu(index, focus = false) {
    selectedMenu = (index + menuItems.length) % menuItems.length;
    menuItems.forEach((item, i) => item.classList.toggle('primary', i === selectedMenu));
    menuItems[selectedMenu].prepend(menuPointer);
    if (focus) menuItems[selectedMenu].focus({ preventScroll: true });
  }
  menuItems.forEach((item, index) => {
    // Mouse clicks and Tab focus share the same cursor as the arrow keys.
    item.addEventListener('focus', () => selectMenu(index));
  });
  document.addEventListener('keydown', event => {
    if (event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    if (screen.dataset.phase !== 'menu' || screen.hidden || screen.inert || document.querySelector('dialog[open]')) return;
    const direction = { ArrowUp: -1, ArrowDown: 1, ArrowLeft: -1, ArrowRight: 1 }[event.key];
    if (!direction) return;
    event.preventDefault();
    selectMenu(selectedMenu + direction, true);
    // Enter retains the focused link/button's native activation behavior.
  });

  let openingFadePending = false;
  let openingFadeFrame = 0;
  let openingFadeGain = 1;
  function prepareOpeningFade() {
    cancelAnimationFrame(openingFadeFrame);
    openingFadePending = true;
    openingFadeGain = 0;
    music.volume = 0;
  }
  function beginOpeningFade() {
    if (!openingFadePending) return;
    openingFadePending = false;
    const started = performance.now();
    function step(now) {
      openingFadeGain = Math.max(0, Math.min(1, (now - started) / 2000));
      music.volume = audioSettings.volume * openingFadeGain;
      if (openingFadeGain < 1) openingFadeFrame = requestAnimationFrame(step);
    }
    openingFadeFrame = requestAnimationFrame(step);
  }
  music.addEventListener('playing', beginOpeningFade);
  function applyAudio(save = false) {
    music.muted = audioSettings.muted;
    music.volume = audioSettings.volume * openingFadeGain;
    musicEnabled.checked = !audioSettings.muted;
    volume.value = Math.round(audioSettings.volume * 100);
    volumeValue.textContent = volume.value + '%';
    if (save) {
      try { localStorage.setItem('dungeon-breaker-audio', JSON.stringify(audioSettings)); } catch {}
    }
  }
  applyAudio();
  function setPhase(phase) {
    screen.dataset.phase = phase;
    menu.inert = phase !== 'menu';
    skip.hidden = phase !== 'intro';
    replay.hidden = phase !== 'menu';
  }
  function finish(focus = false) {
    ++operation;
    wantsIntro = false;
    video.pause();
    video.hidden = true;
    still.hidden = false;
    screen.hidden = false;
    screen.inert = false;
    setPhase('menu');
    status.textContent = 'DUNGEON BREAKER. 방향키로 게임 시작, 설정, 나가기, 오프닝 다시 보기를 선택하고 Enter로 실행하세요.';
    selectMenu(0, focus);
    // The same audio element continues across the film ending, skip and menus.
  }
  // Run before the shared music player's document listeners so a first gesture
  // can align a paused title track before any other listener starts it.
  function tryMusic() {
    if (musicFailed || screen.dataset.phase === 'exited' || screen.dataset.phase === 'game') return;
    if (music.paused && wantsIntro && Number.isFinite(music.duration) && music.duration > 0) {
      alignMusic();
    }
    music.play().catch(() => {});
  }
  function alignMusic() {
    if (!wantsIntro || screen.dataset.phase !== 'intro' || music.seeking || !Number.isFinite(music.duration) || music.duration <= 0) return;
    const position = video.currentTime % music.duration;
    const ranges = music.seekable;
    // Servers without range support may report an empty seekable interval.
    // Never repeatedly seek to an unavailable time (which restarts at zero).
    for (let i = 0; i < ranges.length; i++) {
      if (position >= ranges.start(i) && position <= ranges.end(i)) {
        if (Math.abs(music.currentTime - position) > 0.15) music.currentTime = position;
        return;
      }
    }
  }
  music.addEventListener('playing', alignMusic);
  window.addEventListener('pointerdown', tryMusic, { capture: true });
  window.addEventListener('keydown', tryMusic, { capture: true });
  async function playCurrent() {
    const ticket = ++operation;
    setPhase(wantsIntro ? 'intro' : 'menu');
    // Audio permission must never gate the automatic opening. A first real
    // gesture resumes the title song at the current picture time via tryMusic.
    if (!musicFailed) music.play().catch(() => {});
    if (ticket !== operation) return;
    if (wantsIntro && !videoFailed) {
      video.muted = true;
      try { await video.play(); }
      catch {
        if (ticket === operation) finish();
        return;
      }
    }
    if (ticket !== operation) return;
    status.textContent = wantsIntro ? 'LeeGook Entertainment Presents' : 'DUNGEON BREAKER. 방향키로 게임 시작, 설정, 나가기, 오프닝 다시 보기를 선택하고 Enter로 실행하세요.';
  }
  function start(force = false) {
    ++operation;
    farewell.hidden = true;
    screen.hidden = false;
    screen.inert = false;
    wantsIntro = !videoFailed && !reduced.matches && (force || enabled);
    if (force) { music.pause(); music.currentTime = 0; }
    if (wantsIntro) {
      prepareOpeningFade();
      video.pause(); video.currentTime = 0;
      video.hidden = false; still.hidden = true;
      status.textContent = 'LeeGook Entertainment Presents';
    } else finish();
    playCurrent();
  }
  video.addEventListener('timeupdate', () => {
    if (screen.dataset.phase !== 'intro') return;
    const t = video.currentTime;
    const text = t < 2.2 ? 'LeeGook Entertainment Presents'
      : t < 20.7 ? '여섯 동료가 일상을 보내며 모험을 준비합니다.'
      : t < 32.7 ? '영웅 일행이 여러 던전을 탐험합니다.'
      : t < 34.7 ? '갈색 로브의 인물이 나타난 뒤 화면이 어두워집니다.'
      : t < 37.6 ? '동료들이 각지의 몬스터와 보스에 맞섭니다.'
      : 'DUNGEON BREAKER';
    if (status.textContent !== text) status.textContent = text;
  });
  video.addEventListener('ended', () => { if (screen.dataset.phase === 'intro') finish(true); });
  video.addEventListener('error', () => {
    videoFailed = true;
    if (screen.dataset.phase === 'game' || screen.dataset.phase === 'exited') return;
    finish(); playCurrent();
  });
  music.addEventListener('error', () => {
    musicFailed = true;
    status.textContent = '배경 음악을 불러오지 못했습니다. 게임은 계속 이용할 수 있습니다.';
  });
  skip.addEventListener('click', () => { finish(true); playCurrent(); });
  // Consume the skip press and its repeats, so holding Enter cannot start a game.
  let skipEnterHeld = false;
  document.addEventListener('keydown', event => {
    if (event.key !== 'Enter') return;
    if (skipEnterHeld) { event.preventDefault(); event.stopImmediatePropagation(); return; }
    if (event.defaultPrevented || event.repeat || event.isComposing || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey || screen.dataset.phase !== 'intro' || screen.hidden || document.querySelector('dialog[open]')) return;
    skipEnterHeld = true;
    event.preventDefault(); event.stopImmediatePropagation(); skip.click();
  }, true);
  document.addEventListener('keyup', event => { if (event.key === 'Enter') skipEnterHeld = false; }, true);
  window.addEventListener('blur', () => { skipEnterHeld = false; });

  replay.addEventListener('click', () => start(true));

  const settings = document.querySelector('#settings');
  function wireDialogKeyboard(dialog, opener) {
    const controls = () => Array.from(dialog.querySelectorAll('input:not(:disabled), button:not(:disabled)'))
      .filter(item => !item.closest('[hidden]') && item.getClientRects().length);
    function highlight(item) {
      dialog.querySelectorAll('.dialog-selected').forEach(row => row.classList.remove('dialog-selected'));
      (item.closest('.setting-row') || item).classList.add('dialog-selected');
    }
    opener.addEventListener('click', () => {
      dialog.returnValue = 'cancel';
      dialog.showModal();
      controls()[0]?.focus({ preventScroll: true });
    });
    dialog.addEventListener('focusin', event => {
      if (controls().includes(event.target)) highlight(event.target);
    });
    dialog.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === 'Escape') {
        event.preventDefault(); event.stopPropagation();
        dialog.close('cancel');
        return;
      }
      const items = controls();
      if (!items.length) return;
      const current = document.activeElement;
      const index = items.indexOf(current);
      const horizontal = event.key === 'ArrowLeft' || event.key === 'ArrowRight';
      // Left/right retain native volume adjustment; up/down move between rows.
      if (horizontal && current?.matches('input[type="range"]')) return;
      const direction = { ArrowUp: -1, ArrowDown: 1, ArrowLeft: -1, ArrowRight: 1 }[event.key];
      if (direction) {
        event.preventDefault(); event.stopPropagation();
        const next = index < 0 ? (direction > 0 ? 0 : items.length - 1) : (index + direction + items.length) % items.length;
        items[next].focus();
      } else if (event.key === 'Enter') {
        // Prevent the form's implicit submit when toggling checkboxes.
        event.preventDefault(); event.stopPropagation();
        if (event.repeat) return;
        if (current?.matches('input[type="range"]')) items[(index + 1) % items.length].focus();
        else if (items.includes(current)) current.click();
        else items[0].focus();
      }
    });
    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      dialog.close('cancel');
    });
    dialog.addEventListener('close', () => {
      dialog.querySelectorAll('.dialog-selected').forEach(row => row.classList.remove('dialog-selected'));
      if (dialog.returnValue !== 'quit' && screen.dataset.phase === 'menu' && !screen.hidden) opener.focus({ preventScroll: true });
    });
  }
  wireDialogKeyboard(settings, document.querySelector('#settings-open'));
  opening.addEventListener('change', () => {
    enabled = opening.checked;
    try { localStorage.setItem('dungeon-breaker-opening', enabled ? 'on' : 'off'); } catch {}
  });
  musicEnabled.addEventListener('change', () => {
    audioSettings.muted = !musicEnabled.checked;
    applyAudio(true);
    if (music.paused && !musicFailed) music.play().catch(() => {});
  });
  volume.addEventListener('input', () => {
    audioSettings.volume = Number(volume.value) / 100;
    applyAudio(true);
  });
  const fullscreen = document.querySelector('#fullscreen');
  fullscreen.hidden = !document.fullscreenEnabled;
  fullscreen.addEventListener('click', async () => {
    try { await window.GameScreen.toggleFullscreen(); }
    catch { fullscreen.textContent = '전체 화면을 사용할 수 없습니다'; }
  });
  const updateFullscreen = () => { fullscreen.textContent = window.GameScreen.fullscreen ? '전체 화면 해제' : '전체 화면'; };
  document.addEventListener('fullscreenchange', updateFullscreen);
  window.addEventListener('gamefullscreenchange', updateFullscreen);
  updateFullscreen();

  const exit = document.querySelector('#exit');
  wireDialogKeyboard(exit, document.querySelector('#exit-open'));
  exit.addEventListener('close', () => {
    if (exit.returnValue !== 'quit') return;
    ++operation;
    video.pause(); music.pause();
    setPhase('exited');
    screen.inert = true;
    farewell.hidden = false;
    document.querySelector('#return').focus();
    if (window.GameScreen.fullscreen) window.GameScreen.toggleFullscreen().catch(() => {});
  });
  document.querySelector('#return').addEventListener('click', () => {
    farewell.hidden = true;
    finish(true); playCurrent();
  });
  window.addEventListener('gamescreenenter', () => {
    ++operation;
    // The shared audio now belongs to the game. Finish any opening-only fade
    // before the title is hidden so lobby/draft music keeps the saved volume.
    cancelAnimationFrame(openingFadeFrame);
    openingFadePending = false;
    openingFadeGain = 1;
    applyAudio();
    video.pause();
    setPhase('game');
    screen.hidden = true;
    screen.inert = true;
  });
  window.addEventListener('gamescreenhome', () => { finish(true); playCurrent(); });
  reduced.addEventListener('change', () => {
    if (reduced.matches && ['intro', 'ready'].includes(screen.dataset.phase)) {
      finish(); playCurrent();
    }
  });
  const forceIntro = new URLSearchParams(location.search).get('intro') === '1';
  start(forceIntro);
})();
