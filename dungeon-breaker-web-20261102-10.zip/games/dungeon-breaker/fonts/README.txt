Galmuri11 and Galmuri11 Bold by quiple
Official source: https://github.com/quiple/galmuri
License: SIL Open Font License 1.1 (Galmuri-LICENSE.txt)
Bundled locally for Korean/Latin pixel typography on the main title screen.
