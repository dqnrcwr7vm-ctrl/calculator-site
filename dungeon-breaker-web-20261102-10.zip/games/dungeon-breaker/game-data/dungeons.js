/* Names are looked up by stable ID, never by the previous display name. */
window.GameDungeons={name(id){return window.DUNGEON_NAMES?.[id]||id;},refresh(){
 document.querySelectorAll('[data-dungeon-name]').forEach(el=>{el.textContent=this.name(el.dataset.dungeonName);});
 const id=document.documentElement.dataset.dungeonId;
 if(document.documentElement.dataset.privateTitle==='true')document.title='DUNGEON BREAKER';
 else if(id)document.title='DUNGEON BREAKER · '+this.name(id);
 document.querySelectorAll('[data-dungeon-alt]').forEach(el=>{el.alt=this.name(el.dataset.dungeonAlt);});
}};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>GameDungeons.refresh());else GameDungeons.refresh();
