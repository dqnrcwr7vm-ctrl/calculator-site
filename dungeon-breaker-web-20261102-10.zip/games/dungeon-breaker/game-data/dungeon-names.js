/* Generated from 던전 설정. Apply edits with scripts/import-dungeon-names.py. */
window.DUNGEON_NAMES={
  "01": "침몰한 범선",
  "02": "가시왕관 수목탑",
  "03": "서리심장 감옥",
  "04": "몰락한 태양 용광로",
  "05": "월식의 서고",
  "06": "유리사막 왕릉",
  "07": "폭풍쇄 성채",
  "08": "포자빛 심연",
  "09": "멈춰버린 시계첨탑",
  "10": "백야의 순례계단"
};
