/* Keyboard control shared by the normal and contract dungeon character grids. */
(() => {
 const arrows=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'];
 document.addEventListener('keydown',event=>{
  if(event.defaultPrevented||event.altKey||event.ctrlKey||event.metaKey||event.isComposing)return;
  if(event.target.closest('input,textarea,select,[contenteditable="true"]'))return;
  const cards=[...document.querySelectorAll('.classgrid .classcard')];
  if(!cards.length)return;
  if(event.key==='Escape'){
   event.preventDefault();event.stopImmediatePropagation();
   if(!event.repeat)window.CharacterSelection?.cancel();
   return;
  }
  if(event.key==='Enter'){
   // Keep Tab-focused navigation, reset and slot buttons' native behavior.
   if(event.target.closest('a,button')&&!event.target.closest('.classcard,.detail .primary'))return;
   event.preventDefault();if(event.repeat)return;
   const focusedCard=event.target.closest('.classcard');
   if(focusedCard&&!focusedCard.disabled&&!focusedCard.classList.contains('selected'))focusedCard.click();
   const button=document.querySelector('.detail .primary');
   if(button&&!button.disabled)button.click();
   return;
  }
  if(!arrows.includes(event.key))return;
  event.preventDefault();
  const active=Math.max(0,cards.findIndex(card=>card.classList.contains('selected')));
  let candidates=[];
  if(event.key==='ArrowLeft'||event.key==='ArrowRight'){
   const direction=event.key==='ArrowRight'?1:-1;
   candidates=Array.from({length:cards.length-1},(_,i)=>(active+direction*(i+1)+cards.length)%cards.length);
  }else{
   const columns=3,rows=Math.ceil(cards.length/columns),direction=event.key==='ArrowDown'?1:-1;
   const row=(Math.floor(active/columns)+direction+rows)%rows,column=active%columns;
   // Prefer the same column, then the closest available card in the other row.
   candidates=Array.from({length:columns},(_,i)=>row*columns+i).sort((a,b)=>Math.abs(a%columns-column)-Math.abs(b%columns-column));
  }
  const next=candidates.find(i=>cards[i]&&!cards[i].disabled);
  if(next===undefined)return;
  cards[next].click();
  document.querySelectorAll('.classgrid .classcard')[next]?.focus({preventScroll:true});
 });
})();
