// Reuse the authored rising-aura pixels; keep all effects on the battle clock.
window.WizardCasting=(()=>{
 const colors={fire:[255,115,18],ice:[85,205,255],water:[60,135,255],lightning:[255,218,55],nature:[100,225,80],earth:[205,151,70],dark:[170,95,255],light:[255,235,155]};
 const crystals=[[386,269],[389,259],[370,214],[376,222],[384,254],[377,262],[375,283],[386,269]];
 const layers={},casts={};
 function tint(image,rgb,crystalOnly=false){
  const c=document.createElement('canvas');c.width=image.width;c.height=image.height;
  const ctx=c.getContext('2d');ctx.drawImage(image,0,0);
  const data=ctx.getImageData(0,0,c.width,c.height),p=data.data;
  for(let i=0;i<p.length;i+=4){
   if(!p[i+3] || (crystalOnly && !(p[i+1]>100&&p[i+2]>120&&p[i]<p[i+1]*.8)))continue;
   const peak=Math.max(p[i],p[i+1],p[i+2])/255;
   const white=Math.min(p[i],p[i+1],p[i+2])/255;
   for(let j=0;j<3;j++)p[i+j]=Math.round(rgb[j]*peak+(255-rgb[j])*white);
  }
  ctx.putImageData(data,0,0);return c;
 }
 function crystal(actor,position,frame){
  const b=actor.bounds,registration=actor.actions.magic.registration?.[frame],anchor=registration?.anchor||actor.actions.magic.anchor||actor.anchor||[(b[0]+b[2])/2,b[3]],scale=position.h/(b[3]-b[1])*(registration?.scale||1),point=crystals[frame];
  return{x:position.x+(point[0]-anchor[0])*scale,y:position.y+(point[1]-anchor[1])*scale};
 }
 async function load(loader,magicFrames){
  const raw={};
  await Promise.all(['back','front'].map(async layer=>{raw[layer]=await Promise.all(Array.from({length:9},(_,i)=>loader(`../effects/battle-roar-v1/frames/${layer}/aura-${String(i+1).padStart(2,'0')}.webp`)))}));
  for(const [element,rgb] of Object.entries(colors)){
   layers[element]={back:raw.back.map(im=>tint(im,rgb)),front:raw.front.map(im=>tint(im,rgb))};
   casts[element]=magicFrames.map(im=>tint(im,rgb,true));
  }
 }
 function draw(ctx,layer,actor,position,current,state,frame){
  const def=current?.def,element=def?.element;
  if(actor.id!=='wizard'||state?.phase!=='acting'||!layers[element]||!def.projectile)return;
  const release=def.projectile.release,t=state.local;
  if(t<100||t>=release+120)return;
  const progress=Math.min(1,(t-100)/(release-100)),index=Math.min(7,Math.floor(progress*8));
  const tip=crystal(actor,position,frame),im=layers[element][layer][index];
  ctx.save();ctx.globalAlpha=t>release?1-(t-release)/120:1;ctx.imageSmoothingEnabled=false;
  // Row registration keeps the ring at the feet while the upper spiral leans into the crystal.
  for(let row=0;row<128;row++){
   const rise=(111-row)/95,width=170*(1-Math.max(0,Math.min(1,rise))*.72);
   const x=position.x+(tip.x-position.x)*rise,y=position.y+(tip.y-position.y)*rise;
   ctx.drawImage(im,0,row,128,1,Math.round(x-width/2),Math.round(y),Math.round(width),Math.max(2,Math.ceil((position.y-tip.y)/95)));
  }
  if(layer==='front'&&t<release){
   ctx.fillStyle=`rgb(${colors[element].join(',')})`;
   for(let n=0;n<7;n++){
    const rise=(progress+n/7)%1,spread=18*(1-rise);
    const x=position.x+(tip.x-position.x)*rise+Math.sin(rise*10+n)*spread;
    const y=position.y+(tip.y-position.y)*rise;
    ctx.fillRect(Math.round(x),Math.round(y),3,4);
   }
  }
  ctx.restore();
 }
 return{load,draw,crystal,colors,image:(element,frame)=>casts[element]?.[frame]};
})();
