/* Shared combat skill help: hover/focus or a touch/pen hold, never cast on hold. */
(()=>{
 const grid=document.querySelector('.command-grid');if(!grid)return;
 const tip=document.createElement('aside');tip.id='combat-skill-tooltip';tip.className='combat-skill-tooltip';tip.setAttribute('role','tooltip');tip.hidden=true;tip.innerHTML='<strong></strong><p></p>';document.body.append(tip);
 let shown=null,press=null,timer=null,suppress=null;
 const button=target=>target instanceof Element?target.closest('.command-grid button[data-action]'):null;
 function info(b){const id=b.dataset.action,role=window.BATTLE_ASSETS?.[Number(grid.dataset.owner||0)]?.id;
  const entry=window.PartyBasicActions?.specs[id]||window.SkillDraftData?.catalog(role).find(s=>s.id===id)||window.PartyMechanic?.specs[id]||window.DwarfSkills?.skills.find(s=>s.id===id);
  const extra={'party-end-turn':['턴 종료','현재 캐릭터의 최대 MP 3%를 회복하고 다음 차례로 넘어갑니다. MP 부족으로 장착 스킬을 하나도 쓸 수 없다면 자신의 최대 HP 3%도 회복합니다.'],'party-wait':['대기','스킬을 사용하지 않고 다음 동료에게 행동을 넘깁니다.'],'combined-gun':['기관총 사격','합체 메카의 기관총으로 선택한 적 하나를 공격합니다.'],'combined-drill':['드릴 공격','합체 메카의 드릴로 선택한 적 하나를 공격합니다.'],'combined-beam':['가슴 빔 충전','이번 턴에 충전하고 다음 턴에 빔을 발사합니다. 합체가 두 턴 이상 남아 있어야 합니다.'],'combined-guard':['합체 메카 방어','합체 메카로 이번 턴 받는 피해를 줄입니다.']};
  return {name:entry?.name||extra[id]?.[0]||b.textContent,description:window.PartyResources?.describe(role,id,entry?.description||extra[id]?.[1]||'이 스킬을 사용합니다.')||(entry?.description||extra[id]?.[1]||'이 스킬을 사용합니다.')};
 }
 function hide(){if(shown){const ids=(shown.getAttribute('aria-describedby')||'').split(' ').filter(id=>id&&id!==tip.id);if(ids.length)shown.setAttribute('aria-describedby',ids.join(' '));else shown.removeAttribute('aria-describedby');}shown=null;tip.hidden=true;}
 function cancelTimer(){clearTimeout(timer);timer=null;}
 function show(b){hide();const data=info(b);tip.querySelector('strong').textContent=data.name;tip.querySelector('p').textContent=data.description;shown=b;b.setAttribute('aria-describedby',((b.getAttribute('aria-describedby')||'')+' '+tip.id).trim());tip.hidden=false;tip.style.left='0px';tip.style.top='0px';const r=b.getBoundingClientRect(),t=tip.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(innerWidth-t.width-8,r.left+r.width/2-t.width/2))+'px';tip.style.top=Math.max(8,Math.min(innerHeight-t.height-8,r.top-t.height-10>=8?r.top-t.height-10:r.bottom+10))+'px';}
 grid.addEventListener('pointerover',e=>{const b=button(e.target);if(e.pointerType==='mouse'&&b&&b!==shown)show(b);});
 grid.addEventListener('pointerout',e=>{if(e.pointerType==='mouse'&&shown&&!shown.contains(e.relatedTarget))hide();});
 grid.addEventListener('focusin',e=>{const b=button(e.target);if(b&&!press)show(b);});grid.addEventListener('focusout',hide);
 document.addEventListener('pointerdown',e=>{suppress=null;cancelTimer();hide();press=null;const b=button(e.target);if(!b||!['touch','pen'].includes(e.pointerType)||!e.isPrimary)return;press={b,id:e.pointerId,x:e.clientX,y:e.clientY,held:false};timer=setTimeout(()=>{if(!press||!b.isConnected)return;press.held=true;suppress=b;show(b);},450);},true);
 document.addEventListener('pointermove',e=>{if(press&&e.pointerId===press.id&&Math.hypot(e.clientX-press.x,e.clientY-press.y)>12){cancelTimer();if(press.held)hide();press=null;}},true);
 document.addEventListener('pointerup',e=>{if(press?.id!==e.pointerId)return;cancelTimer();if(press.held){e.preventDefault();suppress=press.b;}press=null;},true);
 document.addEventListener('pointercancel',()=>{cancelTimer();press=null;hide();},true);
 grid.addEventListener('click',e=>{const b=button(e.target);if(b&&b===suppress){e.preventDefault();e.stopImmediatePropagation();suppress=null;return;}hide();},true);
 grid.addEventListener('contextmenu',e=>{if(press||suppress){e.preventDefault();}},true);
 document.addEventListener('keydown',e=>{suppress=null;if(e.key==='Escape'){cancelTimer();press=null;hide();}});
 new MutationObserver(()=>{if(shown&&!shown.isConnected)hide();}).observe(grid,{childList:true});
 addEventListener('resize',hide);addEventListener('scroll',hide,true);
})();
