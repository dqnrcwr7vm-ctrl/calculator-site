/* Dungeon 02: local authored sprites retargeted to the live formation.
   PartyTurns owns target snapshots, damage, HURT and the shared battle clock. */
(function(root){
'use strict';
const base='../monsters/02-thorn-crown-attacks-v2/',images=new Map(),clips=new Map(),actors=new Map(),effects=new Map();
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x);},lerp=(a,b,p)=>a+(b-a)*p;
function frame(ds,t){for(let i=0;i<ds.length;i++){if(t<ds[i])return i;t-=ds[i];}return ds.length-1;}
function state(now,positions,enemies){const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='02'||!a.targets.length)return null;const e=enemies.find(e=>e.id===a.id),age=now-a.started;if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;return{a,e,c:a.visual,m:actors.get(a.visual.monsterId),age,positions};}
function point(p,ground=false){return[p.x,p.y-(ground?0:p.h*.55)];}
function actor(v){const {c,m,age:t,e}=v,k=c.motion,target=v.positions[v.a.targets[0]],scale=e.h/(m.bounds[3]-m.bounds[1]);let q=0;
 if(k.caster!=='stationary'&&t>=k.approachStartMs)q=t<=k.contactMs?smooth((t-k.approachStartMs)/(k.contactMs-k.approachStartMs)):t<k.returnStartMs?1:1-smooth((t-k.returnStartMs)/(k.returnEndMs-k.returnStartMs));
 const end=point(target),x=lerp(e.x,end[0]-m.contactOffset[0]*scale,q),y=lerp(e.y,end[1]-m.contactOffset[1]*scale,q),total=c.casterClip.durations.reduce((a,b)=>a+b,0),idle=m.actions.idle,clip=t<total?c.casterClip:idle,age=t<total?t:(t-total)%idle.durations.reduce((a,b)=>a+b,0),f=frame(clip.durations,age);
 return{x,y,scale,progress:q,frame:f,path:base+clip.frames[f],anchor:m.anchor};}
function records(v){const {c,age:t,e}=v,ops=[],a=actor(v),ground=['root','thorn'].includes(c.effectId),kind=c.visualKind,ratio=e.h/v.m.displayHeight;
 const targets=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0);
 const add=(effect,f,layer,xy,scale,target,tag,split)=>{const fx=effects.get(effect);ops.push({effect,frame:f,layer,x:xy[0],y:xy[1],scale,target,tag,anchor:fx.anchor,path:base+(split?fx[split]:fx.frames)[f]});};
 for(const i of targets){const p=v.positions[i];if(!p)continue;
  if(t>=c.releaseMs&&t<c.impactMs&&kind!=='melee'){const q=smooth((t-c.releaseMs)/(c.impactMs-c.releaseMs)),dst=point(p,ground),src=ground?[a.x-90*ratio,a.y-5*ratio]:[a.x-80*ratio,a.y-e.h*.6],xy=[lerp(src[0],dst[0],q),lerp(src[1],dst[1],q)];if(kind==='silk-shot'||kind==='venom-shot')xy[1]-=Math.sin(Math.PI*q)*35*ratio;
   add(c.effectId,Math.min(3,Math.floor(q*4)),'front',xy,(kind==='venom-shot'?.38:kind==='silk-shot'?.35:ground?.32:.45)*ratio,i,'travel');
   if(ground&&kind!=='charge-root')for(const trail of [.18,.36]){const z=q-trail;if(z>0)add(c.effectId,0,'back',[lerp(src[0],dst[0],z),lerp(src[1],dst[1],z)],.24*ratio,i,'ground-trail');}
  }
  const dt=t-c.impactMs,unit=p.h/165;
  if(dt>=0&&dt<500)add('contact',frame(effects.get('contact').durations,dt),'front',point(p),(kind==='melee'?1.05:.7)*unit,i,'contact');
  if(dt>=0&&dt<600&&kind!=='melee'){const f=dt<100?3:dt<220?4:dt<340?5:dt<460?6:7,xy=point(p,ground),scale=(ground?.60:.56)*unit;
   if(c.effectId==='root'){add('root',f,'back',xy,scale,i,'wrap-rear','back');add('root',f,'front',xy,scale,i,'wrap-front','front');}else add(c.effectId,f,'front',xy,scale,i,'target-impact');
  }
 }
 return ops;
}
root.ThornCrownAttackVFX={
 async load(loader){if(root.ActiveDungeon?.id!=='02')return;images.clear();clips.clear();actors.clear();effects.clear();const res=await fetch(base+'runtime-manifest.json');if(!res.ok)throw Error('Thorn Crown VFX manifest '+res.status);const data=await res.json(),ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set(),needed=new Set();
  for(const m of data.actors)if(ids.has(m.id)){actors.set(m.id,m);m.actions.idle.frames.forEach(p=>paths.add(base+p));}
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'02:'+c.monsterId+':'+c.action,adapter:'02'});c.casterClip.frames.forEach(p=>paths.add(base+p));needed.add(c.effectId);needed.add('contact');}
  for(const id of needed){const fx=data.effects[id];effects.set(id,fx);for(const key of id==='root'?['frames','back','front']:['frames'])fx[key].forEach(p=>paths.add(base+p));}
  for(const p of paths)images.set(p,await loader(p));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='02'||e.isBoss||plan.charge||plan.wipe||!['attack','special'].includes(plan.clip)||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=state(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=images.get(a.path);g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=state(now,positions,enemies);if(!v)return;for(const r of records(v)){if(r.layer!==layer)continue;const im=images.get(r.path);g.drawImage(im,r.x-r.anchor[0]*r.scale,r.y-r.anchor[1]*r.scale,im.width*r.scale,im.height*r.scale);}},
 snapshot(now,positions,enemies){const v=state(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
