/* Keyboard navigation for the real initial and mid-boss skill drafts. */
(() => {
  'use strict';
  let overlay=null,context=null,last=null;
  const available=el=>el&&!el.disabled&&!el.closest('[hidden],[inert]')&&el.getClientRects().length>0;
  const identity=el=>el?.matches('[data-card]')?'card:'+el.dataset.card:el?.matches('[data-reroll]')?'reroll:'+el.dataset.reroll:el?.id||null;
  const controls=()=>[
    [...overlay.querySelectorAll('[data-card]')].filter(available),
    [...overlay.querySelectorAll('[data-reroll]')].filter(available),
    [...overlay.querySelectorAll('.loot-footer button')].filter(available),
  ];
  const active=()=>available(overlay)&&!document.querySelector('#party-setup:not([hidden]),dialog[open]');
  function focus(el,scroll=true){
    if(!available(el))return;
    overlay.querySelectorAll('.draft-keyboard-focus').forEach(b=>b.classList.remove('draft-keyboard-focus'));
    el.classList.add('draft-keyboard-focus');last=identity(el);
    el.focus({preventScroll:true});
    if(scroll)el.scrollIntoView({block:'nearest',inline:'nearest'});
  }
  window.SkillDraftInput={
    refresh(element,key){
      const changed=context!==key;overlay=element;context=key;if(changed){last=null;overlay.scrollTop=0;}
      if(!active())return;
      const all=controls().flat();let target=all.find(b=>identity(b)===last);
      // A used/selected reroll is disabled after redraw. Keep its card in view.
      if(!target&&last?.startsWith('reroll:'))target=all.find(b=>identity(b)==='card:'+last.split(':')[1]);
      focus(target||all[0],false);
    },
    close(){overlay?.querySelectorAll('.draft-keyboard-focus').forEach(b=>b.classList.remove('draft-keyboard-focus'));overlay=null;context=last=null;}
  };
  document.addEventListener('focusin',e=>{if(active()&&overlay.contains(e.target)&&e.target.matches('button'))focus(e.target,false);});
  document.addEventListener('keydown',e=>{
    if(!active()||e.isComposing||e.ctrlKey||e.metaKey||e.altKey||e.target.closest('input,textarea,select,[contenteditable="true"]'))return;
    if(e.defaultPrevented)return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopImmediatePropagation();
      if(!e.repeat)window.GalleonCampaign?.cancelDraftSelection();
      return;
    }
    const arrow=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key),activate=e.key===' '||e.key==='Enter';
    if(!arrow&&!activate)return;
    e.preventDefault();e.stopImmediatePropagation();
    const rows=controls(),all=rows.flat();if(!all.length)return;
    const current=all.includes(document.activeElement)?document.activeElement:all.find(b=>identity(b)===last)||all[0];
    if(activate){if(!e.repeat){focus(current,false);current.click();}return;}
    let row=rows.findIndex(list=>list.includes(current)),target;
    if(e.key==='ArrowLeft'||e.key==='ArrowRight'){
      const list=rows[row],step=e.key==='ArrowLeft'?-1:1;
      target=list[(list.indexOf(current)+step+list.length)%list.length];
    }else{
      const step=e.key==='ArrowUp'?-1:1,rect=current.getBoundingClientRect(),x=rect.left+rect.width/2;
      for(let n=1;n<=rows.length;n++){
        const list=rows[(row+step*n+rows.length*2)%rows.length];if(!list.length)continue;
        target=list.reduce((best,b)=>{const r=b.getBoundingClientRect(),s=best.getBoundingClientRect();return Math.abs(r.left+r.width/2-x)<Math.abs(s.left+s.width/2-x)?b:best;});break;
      }
    }
    if(target!==current){focus(target);window.DungeonUIAudio?.play('move');}
  },true);
})();
