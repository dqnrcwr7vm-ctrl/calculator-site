/* Dungeon 07 visual adapter. PartyTurns remains the sole owner of targets,
   damage/HURT and the shared clock; source PNGs and authored timing are unchanged. */
(function(root){
'use strict';
const base='../monsters/07-storm-citadel-attack-impact-v1/',data=root.STORM_CITADEL_ATTACK_DATA,images=new Map(),clips=new Map();
const clamp=t=>Math.max(0,Math.min(1,t)),mix=(a,b,t)=>a+(b-a)*t,smooth=t=>t*t*(3-2*t),sum=a=>a.reduce((x,y)=>x+y,0);
function frameAt(durations,t,loop=false){if(loop)t=((t%sum(durations))+sum(durations))%sum(durations);for(let i=0;i<durations.length;i++){if(t<durations[i])return i;t-=durations[i]}return durations.length-1;}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='07'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const c=a.visual,asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]),m=data.monsters[c.monsterId];
 return{a,e,c,m,age,positions,scale,ratio:scale/(c.actor.worldHeight/m.sourceHeight)};
}
function actor(v){
 const target=v.positions[v.a.targets[0]];if(!target)return null;const keys=v.c.actor.motion;
 // Authored approach distance scales with the monster; do not resize/re-anchor its poses.
 const point=k=>k.anchor==='source'?[v.e.x,v.e.y]:[target.x+(k.offset?.[0]||0)*v.ratio,target.y+(k.offset?.[1]||0)*v.ratio];
 let p=point(keys[keys.length-1]);for(let i=0;i+1<keys.length;i++)if(v.age<keys[i+1].t){const a=point(keys[i]),b=point(keys[i+1]),t=smooth(clamp((v.age-keys[i].t)/(keys[i+1].t-keys[i].t)));p=a.map((x,j)=>mix(x,b[j],t));break;}
 const t=v.age-v.c.actor.castStartMs,casting=t>=0&&t<sum(v.c.actor.durations),paths=casting?v.c.actor.framePaths:v.m.idle.frames,durations=casting?v.c.actor.durations:v.m.idle.durations;
 return{x:p[0],y:p[1],scale:v.scale,anchor:v.c.actor.anchor,path:base+paths[frameAt(durations,casting?t:v.age,!casting)]};
}
function records(v){
 const recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0),out=[],c=v.c;
 for(const i of recipients){const p=v.positions[i];if(!p)continue;const unit=p.h/data.targetReferenceHeight;
  const point=q=>q.anchor==='source'?[v.e.x+(q.offset?.[0]||0)*v.ratio,v.e.y+(q.offset?.[1]||0)*v.ratio]:[p.x+(q.offset?.[0]||0)*unit,p.y+(q.offset?.[1]||0)*unit];
  if(c.projectile.enabled&&v.age>=c.releaseMs&&v.age<c.impactMs){const u=clamp((v.age-c.releaseMs)/(c.impactMs-c.releaseMs)),a=point(c.trajectory.from),b=point(c.trajectory.to);let pos=a.map((x,j)=>mix(x,b[j],u));if(c.trajectory.control){const k=point(c.trajectory.control);pos=a.map((x,j)=>(1-u)**2*x+2*(1-u)*u*k[j]+u*u*b[j]);}out.push({path:base+c.projectile.frames[frameAt(c.projectile.durations,v.age-c.releaseMs)],anchor:c.projectile.anchor,x:pos[0],y:pos[1],scale:mix(v.ratio,unit,u),layer:'front',tag:'travel',target:i});}
  if(v.age>=c.impactMs&&v.age<c.impact.endMs){const q=point(c.impact);out.push({path:base+c.impact.frames[frameAt(c.impact.durations,v.age-c.impactMs)],anchor:c.impact.localAnchor,x:q[0],y:q[1],scale:unit,layer:'front',tag:'contact',target:i});}
 }return out;
}
root.StormCitadelAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='07'||!data)return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'07:'+c.monsterId+':'+c.action,adapter:'07',durationMs:c.finishMs});c.actor.framePaths.forEach(p=>paths.add(base+p));data.monsters[c.monsterId].idle.frames.forEach(p=>paths.add(base+p));if(c.projectile.enabled)c.projectile.frames.forEach(p=>paths.add(base+p));c.impact.frames.forEach(p=>paths.add(base+p));}
  for(const path of paths)images.set(path,await loader(path));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='07'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=a&&images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(im)g.drawImage(im,q.x-q.anchor[0]*q.scale,q.y-q.anchor[1]*q.scale,im.width*q.scale,im.height*q.scale);}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
