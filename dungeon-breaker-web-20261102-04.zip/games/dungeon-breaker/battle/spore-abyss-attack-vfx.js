/* Dungeon 08 presentation only. Shared PartyTurns owns frozen targets, damage,
   actual HURT, defenses and the battle clock. Approved source art is read-only. */
(function(root){
'use strict';
const base='../monsters/08-spore-abyss-attack-delivery-v1/',data=root.SPORE_ABYSS_ATTACK_DATA,images=new Map(),clips=new Map();
const clamp=n=>Math.max(0,Math.min(1,n)),mix=(a,b,t)=>a+(b-a)*t;
function frameAt(c,t){let i=0;while(i<c.frames.length-1&&t>=c.frames[i+1].timeMs)i++;return i;}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='08'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const c=a.visual,asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]),index=frameAt(c,age),frame=c.frames[index];
 return{a,e,c,age,index,frame,positions,scale,ratio:scale/frame.body.scale};
}
function actor(v){
 const target=v.positions[v.a.targets[0]];if(!target)return null;
 const {c,frame:f}=v,n=c.frames[Math.min(v.index+1,c.frames.length-1)],q=n.timeMs>f.timeMs?clamp((v.age-f.timeMs)/(n.timeMs-f.timeMs)):0;
 const x=mix(f.body.x,n.body.x,q),home=c.sourcePosition[0],contact=c.motion.contactAnchorX;
 let progress=c.action==='attack'?clamp((home-x)/(home-contact)):0;
 // Source samples round to .001px; the authored contact hold is exactly at target.
 if(c.action==='attack'&&v.age>=c.impactMs&&v.age<=c.motion.returnStartMs)progress=1;
 const unit=target.h/data.targetReferenceHeight;
 const endX=target.x+(contact-c.targetHitPoint[0])*v.ratio+(c.targetHitPoint[0]-c.targetPosition[0])*unit;
 return{x:mix(v.e.x,endX,progress),y:mix(v.e.y,target.y,progress),scale:v.scale,anchor:f.body.anchor,path:base+f.body.path};
}
function records(v){
 const recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0),out=[];
 for(const i of recipients){const p=v.positions[i];if(!p)continue;const unit=p.h/data.targetReferenceHeight;
  for(const r of v.frame.effects){
   const {c}=v;let x,y,k,tag;
   if(r.binding==='source'){
    // A preparation effect belongs to one caster even for an area plan.
    if(i!==recipients[0])continue;
    x=v.e.x+(r.x-c.sourcePosition[0])*v.ratio;y=v.e.y+(r.y-c.sourcePosition[1])*v.ratio;k=v.ratio;tag='prepare';
   }else if(r.binding==='target'){
    x=p.x+(r.x-c.targetPosition[0])*unit;y=p.y+(r.y-c.targetPosition[1])*unit;k=unit;tag='contact';
   }else{
    // Continue authored path samples between their <=40ms boundaries, preserving
    // trailing roots/larvae and original drawn poses. At the event switch to impact.
    const q=clamp(r.pathProgress+(v.age-v.frame.timeMs)/(c.impactMs-c.releaseMs));
    const sx=r.x+(c.targetHitPoint[0]-830)*(q-r.pathProgress);
    const airborne=!/\/(roots|hatch)\//.test(r.path);
    const sy=airborne?r.y+35*Math.sin(Math.PI*r.pathProgress)-35*Math.sin(Math.PI*q):r.y;
    x=mix(v.e.x+(sx-c.sourcePosition[0])*v.ratio,p.x+(sx-c.targetPosition[0])*unit,q);
    y=mix(v.e.y+(sy-c.sourcePosition[1])*v.ratio,p.y+(sy-c.targetPosition[1])*unit,q);
    k=mix(v.ratio,unit,q);tag='travel';
   }
   out.push({path:base+r.path,x,y,size:r.size*k,anchor:r.anchor,opacity:r.opacity,layer:r.layer,tag,target:i});
  }
 }return out;
}
root.SporeAbyssAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='08'||!data)return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'08:'+c.id,adapter:'08'});for(const f of c.frames){paths.add(base+f.body.path);f.effects.forEach(r=>paths.add(base+r.path));}}
  for(const path of paths)images.set(path,await loader(path));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='08'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=a&&images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(!im)continue;const h=q.size*im.height/im.width;g.save();g.globalAlpha*=q.opacity;g.drawImage(im,q.x-q.anchor[0]*q.size,q.y-q.anchor[1]*h,q.size,h);g.restore();}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
