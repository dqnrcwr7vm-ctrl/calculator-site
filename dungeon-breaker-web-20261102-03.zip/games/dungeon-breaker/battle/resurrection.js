(function(root){
 'use strict';
 const durations=Array.from({length:24},(_,i)=>i<5?120:i<11?110:i<16?120:i<23?130:650);
 const castMs=760, reviveAt=castMs+durations.slice(0,14).reduce((a,b)=>a+b,0), endAt=castMs+durations.reduce((a,b)=>a+b,0);
 const hp=a=>a.currentHp??a.hp;
 class Resurrection {
  constructor(party){this.party=party;this.active=null;this.ratio=.3;}
  get caster(){return this.party.findIndex(a=>a.id==='priest');}
  canStart(i){return !this.active&&this.caster>=0&&hp(this.party[this.caster])>0&&Number.isInteger(i)&&i>=0&&i<this.party.length&&i!==this.caster&&hp(this.party[i])===0;}
  start(i,now){if(!this.canStart(i))return false;this.active={target:i,started:now,revived:false};return true;}
  step(now){const a=this.active;if(!a)return null;const age=Math.max(0,now-a.started);let revived=false;
   if(!a.revived&&age>=reviveAt){const target=this.party[a.target];if(hp(target)===0){target.currentHp=Math.max(1,Math.floor(target.hp*this.ratio));revived=true;}a.revived=true;}
   if(age>=endAt){this.active=null;return {done:true,revived,target:a.target};}return {done:false,revived,target:a.target};
  }
  frame(now){if(!this.active)return -1;let t=now-this.active.started-castMs;if(t<0)return -1;for(let i=0;i<24;i++){if(t<durations[i])return i;t-=durations[i];}return 23;}
  reset(){this.active=null;}
 }
 const api={Resurrection,durations,castMs,reviveAt,endAt};
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(!root.document)return;
 const party=root.BATTLE_ASSETS.slice(0,4);
 const folders={dwarf:'dwarf-tank-animations-v1',archer:'archer-animations-v1',wizard:'wizard-animations-v2',priest:'priest-animations-v2'};
 party.forEach(a=>{a.actions||={};if(folders[a.id]&&!a.actions.defeated){a.actions.defeated={frames:Array.from({length:8},(_,i)=>`../characters/${folders[a.id]}/defeated/${a.id==='priest'?'frames/defeated-':'frame-'}${String(i+1).padStart(2,'0')}.webp`),durations:[120,120,120,120,120,120,120,300]};}});
 const priest=party.find(a=>a.id==='priest');if(priest)priest.actions.magic={frames:Array.from({length:8},(_,i)=>`../characters/priest-animations-v2/magic/frames/magic-${String(i+1).padStart(2,'0')}.webp`),durations:[240,160,180,180,260,160,140,240]};
 const model=new Resurrection(party);let frames=[],bridge=null,select,button,test,notice;
 Object.assign(api,{
  get active(){return model.active;},model,
  async load(load){frames=await Promise.all(Array.from({length:24},(_,i)=>load(`../skills/healer-resurrection-runtime-v1/frames/${String(i+1).padStart(2,'0')}.webp`)));},
  mount(b){bridge=b;const row=document.createElement('div');row.className='resurrection-controls';row.innerHTML='<label>부활 대상 <select aria-label="부활 대상"></select></label><button type="button">부활의 기도</button><span role="status"></span>';
   document.querySelector('.commands').append(row);[select,button,notice]=[row.querySelector('select'),row.querySelector('button'),row.querySelector('span')];button.id='resurrection-cast';
   party.forEach((a,i)=>{if(i!==model.caster){const option=document.createElement('option');option.value=i;option.textContent=a.name;select.append(option);}});
   select.onchange=()=>api.refresh();button.onclick=()=>{if((root.PartyTurns&&!root.PartyTurns.canCast(model.caster,'resurrection'))||bridge.busy()||!model.start(Number(select.value),bridge.now()))return;bridge.resume();notice.textContent='힐러가 부활의 기도를 올립니다';api.refresh();};
   test=document.createElement('button');test.textContent='선택 아군 전투불능 테스트';test.id='resurrection-test-defeat';test.onclick=()=>{if(bridge.busy()||model.active)return;if(bridge.defeat)bridge.defeat(Number(select.value));else bridge.damage(Number(select.value),party[Number(select.value)].hp);api.refresh();};document.querySelector('.preview-controls').append(test);
   api.refresh();
  },
  refresh(){if(!bridge)return;const busy=bridge.busy()||!!model.active;button.disabled=busy||!model.canStart(Number(select.value));select.disabled=busy;test.disabled=busy||hp(party[Number(select.value)])===0;
   for(const o of select.options){const a=party[Number(o.value)];o.textContent=a.name+(hp(a)===0?' · 전투불능':' · 생존');}
   if(!model.active)notice.textContent=hp(party[Number(select.value)])===0?'선택한 아군을 HP 30%로 부활':'쓰러진 아군을 선택하세요';
  },
  update(now){const cast=model.active;if(cast){root.DungeonVoices?.action('priest','resurrection',cast);root.DungeonCombatAudio?.spell('priest','resurrection',cast,now-cast.started);}const event=model.step(now);if(event?.revived){root.DwarfSkills?.special('priest',now);bridge.sync(event.target);notice.textContent=party[event.target].name+' · HP 30%로 부활';}if(event?.done){root.DungeonCombatAudio?.stopSpell(cast);root.PartyTurns?.complete(now);notice.textContent='부활 완료';bridge.commands();}api.refresh();},
  pose(i,now){if(i===model.caster&&model.active){const age=now-model.active.started;return {clip:'magic',time:age<760?age:age<endAt-540?800:1020+Math.max(0,age-(endAt-540))};}if(hp(party[i])===0&&party[i].actions.defeated)return {clip:'defeated',time:1e8};return null;},
  hidden(i,now){const f=model.frame(now);return model.active?.target===i&&f>=11&&f<=15;},
  draw(ctx,positions,now){if(!model.active)return;const f=model.frame(now);if(f<0)return;const p=positions[model.active.target],height=Math.max(430,p.h*2.05),width=height*362/543;
   ctx.save();if(f>=20)ctx.globalAlpha=(24-f)/4;const top=Math.round(p.y-height*.87);if(f>=5&&f<=20&&top>0)ctx.drawImage(frames[f],0,0,frames[f].width,12,Math.round(p.x-width/2),0,Math.round(width),top+1);ctx.drawImage(frames[f],Math.round(p.x-width/2),Math.round(p.y-height*.87),Math.round(width),Math.round(height));ctx.restore();
   const scene=document.querySelector('#scene');scene.dataset.resurrectionFrame=String(f+1);scene.dataset.resurrectionTarget=String(model.active.target);
  },
  reset(){model.reset();if(bridge)api.refresh();}
 });
 // Getter must remain live rather than Object.assign's snapshot.
 Object.defineProperty(api,'active',{get:()=>model.active});root.BattleResurrection=api;
})(typeof window!=='undefined'?window:globalThis);
