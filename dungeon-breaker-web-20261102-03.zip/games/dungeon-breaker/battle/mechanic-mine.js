(function(root){
 const actor=root.BATTLE_ASSETS?.[0],config=root.BATTLE_CONFIG;if(actor?.id!=='mechanic'||!config)return;
 const install=actor.actions.install,release=install.durations.reduce((a,b)=>a+b,0),effectDuration=1440;
 actor.actions.mineInstall={...install,frames:[...install.frames,actor.frames[0]],durations:[...install.durations,effectDuration],size:actor.size,anchor:actor.anchor};
 const skill={id:'mine-explosion',icon:'mine-explosion',name:'지뢰 폭발',type:'special',special:true,specialActor:'mechanic',stationary:true,clip:'mineInstall',effect:'mine-explosion',release,impact:release+480,damage:240,cost:0,offensive:true,color:'#ffbe63',description:'제자리 INSTALL 완료 후 대상 발밑 지뢰 폭발 · 보스 충전 대응 특수기술 연계 (피해 240·MP 0 임시)'};
 config.skillCatalog.push(skill);if(new URLSearchParams(location.search).get('skill')===skill.id)config.initialSlots[0]={...skill};config.icons[skill.id]='../skills/mechanic-mine-explosion-v1/frames/frame-10.webp';
 config.effects??={};config.effects[skill.effect]={frames:Array.from({length:18},(_,i)=>'../skills/mechanic-mine-explosion-v1/frames/frame-'+String(i+1).padStart(2,'0')+'.webp'),durations:Array(18).fill(80),size:460,anchor:[64,500/576*128],ground:true};
 root.MechanicMine={skill,hit(now){root.DwarfSkills?.special('mechanic',now);root.dispatchEvent(new CustomEvent('party-special-hit',{detail:{actorId:'mechanic',skillId:skill.id,time:now,special:true}}));}};
})(window);
