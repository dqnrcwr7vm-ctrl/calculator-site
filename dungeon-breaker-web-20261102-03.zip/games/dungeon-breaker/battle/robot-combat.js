// One robot of each kind; enemy response advances every deployed robot once.
window.RobotCombat=(()=>{
 const total=c=>c.durations.reduce((a,b)=>a+b,0);
 const formation=window.MechFormation;
 function create(hp,mp){const s={robots:[],hp,mp,active:false,nextEnemy:Infinity,incoming:null,enemyAttackType:'ranged',blocked:0,damage:0,serial:0,turn:0,endings:[]};Object.defineProperty(s,'robot',{enumerable:true,get(){return this.robots[this.robots.length-1]||null;},set(r){this.robots=r?[r]:[];}});return s;}
 const living=s=>s.robots.filter(r=>r.hp>0&&!r.ending&&r.removeAt===undefined);
 function canInstall(slots,id,robots){return !!robots[id]&&slots.some(s=>s.clip==='install'&&s.robotId===id);}
 function install(s,id,slots,robots,time,center){if(!canInstall(slots,id,robots))return false;const home={...(formation[id]||center)};s.robots=s.robots.filter(r=>r.id!==id);s.robots.push({id,serial:++s.serial,...home,home,hp:robots[id].maxHp,turns:0,started:time,action:null,next:time+900});return true;}
 function start(s,time){if(!s.active){s.active=true;s.nextEnemy=time+6000;}}
 function position(r){r.x=r.home.x;r.y=r.home.y;return r;}
 function end(s,r,time,events){if(r.ending)return;const expired=r.hp>0,damage=expired?r.hp:0;r.ending={kind:expired?'self-destruct':'broken',started:time,until:time+(expired?1550:1100),amount:damage,id:r.id,x:r.x,y:r.y,hit:false};r.removeAt=r.ending.until;s.endings.push(r.ending);events.push({type:expired?'expire-start':'destroyed',id:r.id,amount:damage});}
 function step(s,time,defs){const events=[];if(!s.active||s.hp<=0)return events;
 for(const e of s.endings)if(e.kind==='self-destruct'&&!e.hit&&time>=e.started+650){e.hit=true;s.damage+=e.amount;events.push({type:'expire',id:e.id,amount:e.amount,x:e.x,y:e.y});}
 s.endings=s.endings.filter(e=>time<e.until);
 s.robots=s.robots.filter(r=>{if(r.removeAt!==undefined&&time>=r.removeAt){events.push({type:'removed',id:r.id});return false;}return true;});
 for(const r of living(s)){const d=defs[r.id];if(r.action&&time>=r.action.started+total(d.actions[r.action.clip]))r.action=null;if(!r.repairing&&d.role==='attack'&&!r.action&&time>=r.next){r.action={clip:'attack',started:time,hit:false};r.next=time+d.interval;}if(r.action?.clip==='attack'&&!r.action.hit&&time>=r.action.started+(d.damageImpact??d.impact)){r.action.hit=true;s.damage+=d.damage;events.push({type:'attack',amount:d.damage,id:r.id,element:d.element||'physical',attackType:d.attackType||'melee'});}}
 if(!s.incoming&&time>=s.nextEnemy){const units=living(s),taunted=units.find(r=>defs[r.id].taunt),interceptor=s.enemyAttackType==='ranged'&&units.find(r=>defs[r.id].reflectRanged),r=interceptor||taunted||units[0],d=r&&defs[r.id],defend=d?.role==='guard';s.incoming={started:time,at:time+(defend?d.impact:490),id:r?.id||null,serial:r?.serial,attackType:s.enemyAttackType,tauntedBy:taunted?.serial,reflected:!!interceptor,reduction:interceptor?1:defend?d.reduction:0};s.nextEnemy=time+6000;if(defend)r.action={clip:'guard',started:time};events.push({type:'incoming'});}
 if(s.incoming&&time>=s.incoming.at){const hit=s.incoming,raw=240,blocked=Math.round(raw*hit.reduction),amount=raw-blocked;s.incoming=null;const r=living(s).find(r=>r.serial===hit.serial);
 if(hit.serial){if(r){const d=defs[r.id];r.hp=Math.max(0,r.hp-amount);s.blocked+=blocked;const clip=hit.reflected?'guard':d.actions.hurt?'hurt':'guard';if(!(r.id==='mole'&&r.action?.clip==='attack'&&r.hp>0&&r.turns+1<3))r.action={clip,started:time-(clip==='guard'?d.impact:0),reflected:hit.reflected};r.hitAt=time;events.push({type:'robot-hurt',amount,blocked,id:r.id,hp:r.hp,turns:r.turns+1});if(hit.reflected){r.reflectedAt=time;s.damage+=raw;events.push({type:'reflect',amount:raw,id:r.id,attackType:hit.attackType});}}}
 else{s.hp=Math.max(0,s.hp-raw);events.push({type:'hurt',amount:raw,blocked:0,id:null});}
 for(const unit of s.robots.filter(r=>!r.ending&&r.removeAt===undefined)){unit.turns++;if(unit.hp<=0||unit.turns>=3)end(s,unit,time,events);}
 events.push({type:'turn-end',turn:++s.turn});}
 return events;}
 return{create,living,formation,canInstall,install,start,position,step};
})();
