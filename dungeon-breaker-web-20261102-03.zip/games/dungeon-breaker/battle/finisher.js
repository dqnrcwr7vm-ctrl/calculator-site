// Presentation time is separate from the slowed sprite clock.
window.BattleFinisher={
 deathPose(enemy,asset,now,holdId){
  if(!enemy||enemy.hp>0||enemy.hitAt==null)return null;
  const total=asset.actions.defeated?.durations.reduce((a,b)=>a+b,0)||0,age=Math.max(0,now-enemy.hitAt);
  return total&&(age<total||holdId===enemy.id)?{clip:'defeated',time:Math.min(age,total-1)}:null;
 },
 camera(focus,age){const x=focus.x,y=focus.y-focus.h*.5,t=Math.max(0,Math.min(1,age/450)),ease=t*t*(3-2*t);return {origin:(x/16)+'% '+(y/7)+'%',transform:`translate(${(800-x)*ease/16}%,${(350-y)*ease/7}%) scale(${1+.75*ease})`};},
 damage(hp,amount){const next=hp-amount;return{hp:Math.max(0,next),lethal:hp>0&&next<=0};},
 sample(age){
  const clamp=n=>Math.max(0,Math.min(1,n)),ease=n=>n*n*(3-2*n);
  // Close in on the blow, then widen for the dragon's original falling animation.
  const zoom=age<1100?1+0.38*ease(clamp(age/420)):1.38-0.32*ease(clamp((age-1100)/1400));
  return{zoom,timeScale:age<1100?0.14:0.7,deathTime:Math.max(0,age-1100),clear:age>=2700,phase:age<1100?'slow':age<2700?'defeating':'clear'};
 }
};
