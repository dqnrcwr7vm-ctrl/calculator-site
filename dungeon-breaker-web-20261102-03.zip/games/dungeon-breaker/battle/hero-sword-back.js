/* Approved 칼등 치기 v3: fixed 704px registration, separate blade VFX. */
window.HeroSwordBack=(()=>{
 const enabled=()=>!window.BATTLE_CONFIG?.partyTurns&&window.BATTLE_ASSETS[0].id==='hero';
 const root='../characters/hero-sword-back-strike-v3/';
 const skill={id:'sword-back',name:'칼등 치기',type:'special',special:true,clip:'swordBack',impact:450,damage:240,offensive:true,color:'#ffe5a1',cost:0};
 const clip={size:[704,704],anchor:[352,624],durations:[240,120,90,70,100,110,130,280],frames:Array.from({length:8},(_,i)=>root+`frames/frame-${String(i+1).padStart(2,'0')}.webp`)};
 let images=[];
 if(enabled())window.BATTLE_ASSETS[0].actions.swordBack=clip;
 async function load(loader){if(enabled())images=await Promise.all(clip.frames.map((_,i)=>loader(root+`effects/frame-${String(i+1).padStart(2,'0')}.webp`)));}
 function mount(start){
  if(!enabled())return;
  const b=document.createElement('button');b.dataset.action=skill.id;b.className='hero-special';
  b.innerHTML='<kbd>5</kbd> 칼등 치기 <small>특수 · 피해 240</small>';b.title='낮은 피해의 특수기 · 아군 연계로 필살기 취소';b.onclick=()=>start(skill.id);
  b.style.cssText='position:absolute;right:1.2%;bottom:2%;z-index:4;padding:9px 16px;background:#172032;border:1px solid #e2ba6d;border-radius:4px;color:#ffe8ba;font-size:clamp(11px,1.1vw,17px)';
  document.querySelector('#scene').append(b);
 }
 function draw(ctx,frame,x,y,height,bounds){
  const im=images[frame];if(!im)return;
  const scale=height/(bounds[3]-bounds[1]);
  ctx.drawImage(im,Math.round(x-352*scale),Math.round(y-624*scale),Math.round(704*scale),Math.round(704*scale));
 }
 function hit(now){window.dispatchEvent(new CustomEvent('party-special-hit',{detail:{actorId:'hero',skillId:skill.id,time:now,special:true}}));}
 return {skill:enabled()?skill:null,load,mount,draw,hit};
})();
