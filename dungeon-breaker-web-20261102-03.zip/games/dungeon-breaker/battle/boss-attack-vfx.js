/* Boss delivery uses existing isolated artwork; PartyTurns alone owns damage.
   The original impact and action duration are preserved, including wipe attacks. */
(function(root){
'use strict';
const images=new Map(),clips=new Map(),clamp=x=>Math.max(0,Math.min(1,x)),mix=(a,b,t)=>a+(b-a)*t;
function clipFor(e,plan){
 if(!e.isBoss||!['all','single','self'].includes(plan.target))return null;
 const asset=e.spriteAsset||root.BATTLE_ASSETS[4],skill=plan.effectClip||(plan.target==='self'&&plan.skillId?plan.skillId.slice((root.ActiveDungeon.id+':'+asset.id+':').length):plan.clip);
 const source=clips.get(asset.id+':'+skill),body=asset.actions[plan.clip];
 if(!source||!body)return null;
 const total=body.durations.reduce((a,b)=>a+b,0),impactMs=body.impactMs??Math.round(total*.48);
 return {...source,id:'boss:'+asset.id+':'+plan.clip,adapter:'boss',action:plan.clip,target:plan.target,
  impactMs,releaseMs:Math.max(0,impactMs-460),durationMs:total+300};
}
function records(a,e,positions,now){
 const c=a.visual,age=now-a.started;if(!c||c.adapter!=='boss'||age<c.releaseMs||age>=a.end)return[];
 const incoming=age<c.impactMs,progress=clamp((age-c.releaseMs)/(c.impactMs-c.releaseMs)),tail=clamp((age-c.impactMs)/(a.end-c.impactMs));
 const targets=c.target==='self'?[-1]:a.hit?(a.resolvedTargets||[]):a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0);
 // Approach culminates at the existing hit event; the final drawings dissipate.
 const phase=incoming?progress*.48:.48+tail*.52,frame=Math.min(c.frames.length-1,Math.floor(phase*c.frames.length));
 const [left,top,right,bottom]=c.bounds,w=right-left,h=bottom-top;
 const result=[];
 for(const i of targets){
  const p=i<0?e:positions[i];if(!p)continue;
  const width=(c.ground?1.45:1.1)*p.h,scale=Math.min(width/w,p.h*1.25/h);
  const end={x:p.x,y:c.ground?p.y:p.y-p.h*.5},start={x:e.x-e.h*.25,y:e.y-e.h*.55};
  const x=c.ground||i<0?end.x:mix(start.x,end.x,progress),y=c.ground||i<0?end.y:mix(start.y,end.y,progress);
  const opacity=(incoming?Math.min(1,progress*4):1-Math.pow(tail,3))*(c.ground&&incoming?.6:1);
  for(const layer of ['back','front']){
   const layered=c.layers?.back?.length||c.layers?.front?.length;
   const paths=layered?c.layers[layer]:layer==='front'?c.frames:null;if(!paths?.length)continue;
   result.push({target:i,layer,path:paths[Math.min(frame,paths.length-1)],x:x-(left+w/2)*scale,
    y:y-(c.ground?bottom:top+h/2)*scale,scale,opacity,tag:incoming?'release':'impact',family:c.family});
  }
 }
 return result;
}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;
 if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='boss')return null;
 const e=enemies.find(e=>e.id===a.id);if(!e||e.hp<=0||now<a.started||now>=a.started+a.end)return null;
 return {a,e,effects:records(a,e,positions,now)};
}
root.BossAttackVFX={clipFor,records,
 async load(loader){
  images.clear();clips.clear();
  const ids=[root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)],paths=new Set();
  for(const id of ids)for(const [action,c]of Object.entries(root.BOSS_ATTACK_DATA?.[root.ActiveDungeon?.id+':'+id]||{})){
   clips.set(id+':'+action,c);c.frames.forEach(p=>paths.add(p));Object.values(c.layers||{}).flat().forEach(p=>paths.add(p));
  }
  await Promise.all([...paths].map(async p=>images.set(p,await loader(p))));
 },
 draw(g,layer,now,positions,enemies){
  const v=context(now,positions,enemies);if(!v)return;
  for(const r of v.effects){if(r.layer!==layer)continue;const im=images.get(r.path);if(!im)continue;
   g.save();g.globalAlpha*=r.opacity;g.drawImage(im,r.x,r.y,im.width*r.scale,im.height*r.scale);g.restore();}
 },
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.e.id,clipId:v.a.visual.id,age:now-v.a.started,impactMs:v.a.impact,targets:[...v.a.targets],effects:v.effects}:null;},
 loaded(){return {clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
