/* Dungeon 03 presentation only. PartyTurns owns targets, hits and battle time.
   Replay v2 local drawings, keeping its poses, release/travel/impact/fade timing.
   Reference-scene PNGs, linked previews and allies are never loaded by the game. */
(function(root){
'use strict';
const base='../monsters/03-frost-prison-v2/',images=new Map(),clips=new Map();
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x);},lerp=(a,b,t)=>a+(b-a)*t;
function frame(ds,t){for(let i=0;i<ds.length;i++){if(t<ds[i])return i;t-=ds[i];}return ds.length-1;}
function context(now,positions,enemies){const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='03'||!a.targets.length)return null;const e=enemies.find(e=>e.id===a.id),age=now-a.started;if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;return{a,e,c:a.visual,age,positions,asset:e.spriteAsset||root.BATTLE_ASSETS[4]};}
const point=(p,ground=false)=>[p.x,p.y-(ground?0:p.h*.55)];
function actor(v){const {c,e,age:t,asset}=v,target=v.positions[v.a.targets[0]],scale=e.h/(asset.bounds[3]-asset.bounds[1]);let q=0;
 if(c.action==='attack'&&t>=150)q=t<=c.impactMs?smooth((t-150)/(c.impactMs-150)):t<680?1:1-smooth((t-680)/360);
 const dst=point(target),x=lerp(e.x,dst[0]-(c.tipSource[0]-380)*scale+4*scale/1.18,q),y=lerp(e.y,dst[1]-(c.tipSource[1]-340)*scale,q),total=c.actor.durations.reduce((a,b)=>a+b,0),f=t<total?frame(c.actor.durations,t):0;
 return{x,y,scale,progress:q,frame:f,anchor:c.actor.anchor,path:base+(t<total?c.actor.frames[f]:'actors/'+c.monsterId+'/idle/frame-01.webp')};
}
function records(v){const {c,age:t,e}=v,ops=[],body=actor(v),ratio=body.scale/1.18,basic=c.action==='attack',id=c.effect;
 const targets=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0);
 const add=(effect,n,layer,xy,scale,target,tag,opacity=1,split=null,anchor=null)=>ops.push({effect,frame:n-1,layer,x:xy[0],y:xy[1],scale,target,tag,opacity,split,anchor:anchor||[320,['breath','shards'].includes(effect)?220:340],path:base+'source/reused-effects/'+effect+'/keypose-0'+n+'.webp'});
 for(const i of targets){const p=v.positions[i];if(!p)continue;const ground=['eruption','shockwave'].includes(id),target=point(p,ground),unit=p.h/177;
  if(!basic&&t>=c.releaseMs&&t<c.impactMs){const u=(t-c.releaseMs)/(c.impactMs-c.releaseMs),src=[e.x-110*ratio,e.y-(ground?2:110)*ratio],xy=[lerp(src[0],target[0],u),lerp(src[1],target[1],u)+(id==='chain'?-35*4*u*(1-u)*ratio:0)],n=Math.min(3,1+Math.floor(u*3));
   if(id==='chain'){add(id,2,'front',xy,.42*ratio,i,'travel',1,null,[320,275]);if(c.monsterId==='frozen-dead-elite')add(id,2,'front',[xy[0]+30*ratio,xy[1]+32*ratio],.42*ratio,i,'travel',1,null,[320,275]);}
   else if(ground){add(id,n,'back',xy,.38*ratio,i,'travel');if(u>.2)add(id,4,'back',[xy[0]+65*ratio,xy[1]],.25*ratio,i,'trail',.55);if(u>.4)add(id,4,'back',[xy[0]+125*ratio,xy[1]],.18*ratio,i,'trail',.3);}
   else add(id,n,'front',xy,.55*ratio,i,'travel');
  }
  if(t>=c.impactMs&&t<c.impactMs+480){const u=(t-c.impactMs)/480,n=u<.16?2:u<.55?3:4,opacity=u<.75?1:(1-u)/.25;
   if(basic)add(id,n,'front',point(p,id==='shockwave'),(id==='shockwave'?.42:.33)*unit,i,'contact',opacity);
   else if(id==='chain'){for(const layer of ['back','front'])add(id,n,layer,point(p,true),.95*unit,i,'contact',opacity,p.y-75*unit);if(c.monsterId==='frozen-dead-elite')add(id,4,'front',[p.x,p.y-90*unit],.45*unit,i,'links',opacity);}
   else if(id==='breath'||id==='shards'){add(id,n,'front',point(p),.6*unit,i,'contact',opacity);add('eruption',u<.5?2:4,'front',point(p,true),.36*unit,i,'ground-impact',opacity);}
   else for(const layer of ['back','front'])add(id,n,layer,point(p,true),.75*unit,i,'contact',opacity,p.y-75*unit);
  }
 }
 return ops;
}
root.FrostPrisonAttackVFX={
 async load(loader){if(root.ActiveDungeon?.id!=='03')return;images.clear();clips.clear();const response=await fetch(base+'manifest.json');if(!response.ok)throw Error('Frost Prison VFX manifest '+response.status);const data=await response.json(),ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set(),effects=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'03:'+c.monsterId+':'+c.action,adapter:'03',durationMs:c.totalMs});c.actor.frames.forEach(p=>paths.add(base+p));paths.add(base+'actors/'+c.monsterId+'/idle/frame-01.webp');effects.add(c.effect);if(c.action==='special'&&['breath','shards'].includes(c.effect))effects.add('eruption');}
  for(const id of effects)for(let n=1;n<=4;n++)paths.add(base+'source/reused-effects/'+id+'/keypose-0'+n+'.webp');
  for(const p of paths)images.set(p,await loader(p));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='03'||e.isBoss||plan.charge||plan.wipe||!['attack','special'].includes(plan.clip)||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=images.get(a.path);g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const op of records(v)){if(op.layer!==layer)continue;const im=images.get(op.path);g.save();g.globalAlpha*=op.opacity;if(op.split!==null){g.beginPath();g.rect(0,layer==='back'?0:op.split,(window.MonsterRaster?.width(g.canvas)??g.canvas.width),layer==='back'?op.split:(window.MonsterRaster?.height(g.canvas)??g.canvas.height)-op.split);g.clip();}g.drawImage(im,op.x-op.anchor[0]*op.scale,op.y-op.anchor[1]*op.scale,im.width*op.scale,im.height*op.scale);g.restore();}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
