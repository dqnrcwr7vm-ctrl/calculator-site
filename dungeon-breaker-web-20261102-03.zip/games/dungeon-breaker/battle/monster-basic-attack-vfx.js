/* Basic attacks: authored bodies, short attack trails and recipient-bound impacts.
 * Presentation only; PartyTurns owns targets, damage, hit time and turn duration. */
(function(root){
'use strict';
const clamp=n=>Math.max(0,Math.min(1,n)),mix=(a,b,t)=>a+(b-a)*t;
const COLORS={slash:['#fff5d4','#ffc16c','#ba584e'],fire:['#fff3b0','#ffad32','#ef4935'],ice:['#f2ffff','#90eaff','#439bdb'],water:['#ecffff','#61dce8','#287cbe'],lightning:['#ffffdf','#ddc9ff','#8d70f0'],poison:['#f0ffb5','#a6e660','#508a5c'],leaf:['#f2ffbe','#95dc71','#44895e'],dark:['#ffe6ff','#cb92ec','#7247ad'],light:['#ffffdf','#ffe291','#d49b49'],wind:['#f5ffff','#a3e7d9','#5ea8be']};
function family(dungeon,element){
 if(element==='fire')return 'fire';
 if(dungeon==='03')return 'ice';
 if(dungeon==='08')return 'poison';
 if(dungeon==='07'&&['water','light'].includes(element))return 'lightning';
 if(dungeon==='10'&&['water','neutral'].includes(element))return 'wind';
 return {water:'water',grass:'leaf',dark:'dark',light:'light'}[element]||'slash';
}
function records(action,enemy,positions,party,now,dungeon){
 const age=now-action.started;if(action.plan.clip!=='attack'||action.plan.charge||action.plan.target==='self'||age<0||age>=action.end)return [];
 const magic=action.plan.damageType==='magic',type=family(dungeon,action.plan.element||enemy.element);
 const ids=action.hit?(action.resolvedTargets||[]):action.targets.filter(i=>party[i]&&(party[i].currentHp??party[i].hp)>0);
 const impactAge=age-action.impact,life=Math.min(540,action.end-action.impact);
 const travelStart=Math.max(0,action.impact-320),travel=clamp((age-travelStart)/(action.impact-travelStart));
 return ids.flatMap(i=>{
  const p=positions[i];if(!p)return [];
  const hit={x:p.x,y:p.y-p.h*.48},size=Math.max(45,Math.min(100,p.h*.4));
  if(impactAge<0){
   // Existing delivery adapters already draw their own trajectories.
   if(action.visual||age<travelStart)return [];
   const start={x:enemy.x-enemy.h*.25,y:enemy.y-enemy.h*.55};
   return [{target:i,kind:magic?'bolt':'trail',family:type,x:mix(start.x,hit.x,travel),y:mix(start.y,hit.y,travel),size:size*.6,progress:travel,opacity:Math.min(1,travel*5),start,end:hit}];
  }
  if(!action.hit||impactAge>=life)return [];
  const t=impactAge/life;
  return [{target:i,kind:'impact',family:type,x:hit.x,y:hit.y,size,progress:t,opacity:Math.pow(1-t,1.4),physical:!magic}];
 });
}
const api={family,records};if(typeof module==='object'&&module.exports)module.exports=api;
if(!root.document)return;
const images=new Map();
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;
 if(root.PartyTurns?.cycle.phase!=='enemies'||!a||a.plan.clip!=='attack'||a.plan.charge)return null;
 const e=enemies.find(e=>e.id===a.id);if(!e||e.hp<=0||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const age=now-a.started;if(age<0||age>=a.end)return null;
 return {a,e,age,effects:records(a,e,positions,root.BATTLE_ASSETS,now,root.ActiveDungeon?.id)};
}
function actorPose(v,positions){
 const asset=v.e.spriteAsset||root.BATTLE_ASSETS[4],clip=asset.actions.attack,target=positions[v.a.targets[0]],magic=v.a.plan.damageType==='magic';
 let time=v.age,index=0;while(index<clip.durations.length-1&&time>=clip.durations[index])time-=clip.durations[index++];
 const start=Math.max(0,v.a.impact-290),back=Math.min(v.a.end-1,v.a.impact+420);
 const approach=clamp((v.age-start)/(v.a.impact-start)),returning=clamp((v.age-v.a.impact)/(back-v.a.impact));
 const progress=magic?0:v.age<v.a.impact?approach*approach:1-returning*returning*(3-2*returning);
 const scale=v.e.h/(asset.bounds[3]-asset.bounds[1]);
 return {path:clip.frames[index],anchor:asset.anchor,scale,x:mix(v.e.x,(target?.x??v.e.x)+Math.max(90,v.e.h*.38),progress),y:mix(v.e.y,target?.y??v.e.y,progress),progress};
}
function stroke(g,color,width,draw){g.strokeStyle=color;g.lineWidth=width;g.beginPath();draw();g.stroke();}
function slash(g,r,palette){
 const s=r.size,q=r.progress,spread=1+q*.35;
 g.save();g.rotate(-.35);g.scale(spread,spread);
 for(let i=0;i<3;i++){
  const x=(i-1)*s*.24,y=(i-1)*s*.12;
  stroke(g,palette[2],10,()=>{g.moveTo(x+s*.42,y-s*.72);g.quadraticCurveTo(x-s*.38,y-s*.08,x-s*.48,y+s*.6);});
  stroke(g,palette[0],4,()=>{g.moveTo(x+s*.42,y-s*.72);g.quadraticCurveTo(x-s*.38,y-s*.08,x-s*.48,y+s*.6);});
 }g.restore();
}
function paint(g,r){
 const c=COLORS[r.family],s=r.size,t=r.progress;
 g.save();g.translate(Math.round(r.x),Math.round(r.y));g.globalAlpha*=r.opacity;
 g.lineJoin='round';g.lineCap='round';
 if(r.kind!=='impact'){
  const angle=Math.atan2(r.end.y-r.start.y,r.end.x-r.start.x);g.rotate(angle);
  for(let j=4;j>=0;j--){g.globalAlpha=r.opacity*(1-j*.16);g.fillStyle=c[j<2?0:1];const size=(r.kind==='bolt'?s*.27:s*.1)*(1-j*.13);g.fillRect(-j*s*.3-size,-size,size*2,size*2);}
  stroke(g,c[1],r.kind==='bolt'?6:3,()=>{g.moveTo(-s*1.5,0);g.lineTo(s*.2,0);});
  g.restore();return;
 }
 if(r.physical||r.family==='slash')slash(g,r,c);
 const radius=s*(.22+t*.85);
 // Element silhouettes stay legible over the existing character HURT pose.
 if(r.family==='ice'){
  for(let i=0;i<6;i++){const a=i*Math.PI/3;g.save();g.rotate(a);g.fillStyle=c[1];g.beginPath();g.moveTo(radius*.2,-s*.08);g.lineTo(radius+s*.3,0);g.lineTo(radius*.2,s*.12);g.closePath();g.fill();stroke(g,c[0],2,()=>{g.moveTo(0,0);g.lineTo(radius+s*.28,0);});g.restore();}
 }else if(r.family==='lightning'){
  for(let i=0;i<5;i++){g.save();g.rotate(i*Math.PI*2/5+t*.5);stroke(g,c[1],7,()=>{g.moveTo(0,0);g.lineTo(radius*.4,-s*.16);g.lineTo(radius*.6,s*.17);g.lineTo(radius+s*.32,-s*.1);});stroke(g,c[0],2,()=>{g.moveTo(0,0);g.lineTo(radius*.4,-s*.16);g.lineTo(radius*.6,s*.17);g.lineTo(radius+s*.32,-s*.1);});g.restore();}
 }else if(['water','wind','dark'].includes(r.family)){
  for(let i=0;i<2;i++)stroke(g,c[i],5-i*2,()=>g.ellipse(0,0,radius+s*.1*i,radius*.55,(-.5+i)*.5,t*3+i,Math.PI*1.7+t*3+i));
 }else if(r.family==='fire'){
  for(let i=0;i<5;i++){const x=(i-2)*s*.27;g.fillStyle=c[1];g.beginPath();g.moveTo(x-s*.2,s*.22);g.quadraticCurveTo(x-s*.4,-s*.4,x+s*.1,-s*(.6+t*.7));g.quadraticCurveTo(x+s*.5,-s*.08,x+s*.18,s*.22);g.closePath();g.fill();}
 }else if(['poison','leaf'].includes(r.family)){
  for(let i=0;i<5;i++){const a=i*2.4;g.fillStyle=c[1];g.beginPath();g.ellipse(Math.cos(a)*radius*.6,Math.sin(a)*radius*.4,s*.18,s*.1,a,0,Math.PI*2);g.fill();}
 }else if(r.family==='light'){
  for(let i=0;i<8;i++){g.save();g.rotate(i*Math.PI/4);stroke(g,c[1],4,()=>{g.moveTo(radius*.4,0);g.lineTo(radius+s*.25,0);});g.restore();}
 }
 // One bright contact flash and deterministic fragments; no random game state.
 if(t<.28){g.fillStyle=c[0];const core=s*(.32-t*.7);g.fillRect(-core,-core,core*2,core*2);}
 for(let i=0;i<12;i++){
  const a=i*2.399+r.target*.7,reach=s*(.35+t*(1+(i%3)*.18)),x=Math.cos(a)*reach,y=Math.sin(a)*reach*.7+t*t*s*.5;
  const z=Math.max(2,(i%3+2)*(1-t));g.fillStyle=c[i%3];g.fillRect(Math.round(x),Math.round(y),z,z+(r.family==='ice'?7:0));
 }
 g.restore();
}
root.MonsterBasicAttackVFX={...api,
 async load(loader){
  images.clear();const assets=[root.BATTLE_ASSETS[4],...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset)].filter(Boolean);
  await Promise.all([...new Set(assets.flatMap(a=>a.actions.attack?.frames||[]))].map(async p=>images.set(p,await loader(p))));
 },
 drawActor(g,id,p,now,pose,enemies,positions){
  const v=context(now,positions,enemies);if(!v||v.a.id!==id||v.a.visual||pose!=='attack')return false;
  const a=actorPose(v,positions),im=images.get(a.path);if(!im)return false;
  if(a.progress>.06&&a.progress<.99){
   for(const trail of [2,1]){g.save();g.globalAlpha*=.10/trail;g.drawImage(im,a.x+(v.e.x-a.x)*.1*trail-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);g.restore();}
  }
  g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;
 },
 draw(g,layer,now,positions,enemies){if(layer!=='front')return;const v=context(now,positions,enemies);if(v)for(const r of v.effects)paint(g,r);},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.e.id,clipId:'basic:'+v.e.id,age:v.age,impactMs:v.a.impact,targets:[...v.a.targets],effects:v.effects,actor:!v.a.visual?actorPose(v,positions):null}:null;}
};
})(typeof window!=='undefined'?window:globalThis);
