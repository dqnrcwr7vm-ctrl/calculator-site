// Crisp canvas pixels: cold mechanical breakup vs a charged, hot self-destruction.
window.RobotVFX=(()=>{
 function burst(ctx,x,y,age){
  if(age<0||age>900)return;const frame=Math.floor(age/75),t=frame/12;
  ctx.save();ctx.globalAlpha=Math.max(0,1-t);
  for(let i=0;i<32;i++){const a=i*Math.PI*2/32,r=18+125*t+(i%3)*12,size=Math.max(5,26-frame*2);ctx.fillStyle=['#ffeaa0','#ffac32','#ed5028'][i%3];ctx.fillRect(Math.round((x+Math.cos(a)*r)/4)*4,Math.round((y+Math.sin(a)*r*.7)/4)*4,size,size);}
  if(frame<4){ctx.fillStyle=frame<2?'#fff8c9':'#ffbb41';const n=80-frame*10;ctx.fillRect(x-n/2,y-n/2,n,n);}
  ctx.restore();
 }
 function robot(ctx,r,def,im,time){
  const age=time-r.ending.started,scale=def.height/(def.sourceHeight||400),x=r.x-def.anchor[0]*scale,y=r.y-def.anchor[1]*scale;
  if(r.ending.kind==='broken'){
   // Break the original metal silhouette into tiles, with gravity and dim smoke.
   const t=Math.min(1,age/1100),tile=48;ctx.save();ctx.globalAlpha=1-t;
   for(let sy=0;sy<576;sy+=tile)for(let sx=0;sx<576;sx+=tile){const seed=(sx*7+sy*13)%113,dx=(seed-56)*t*.45,dy=90*t*t+(seed%13)*t;ctx.drawImage(im,sx,sy,tile,tile,Math.round(x+sx*scale+dx),Math.round(y+sy*scale+dy),Math.ceil(tile*scale),Math.ceil(tile*scale));}
   for(let i=0;i<10;i++){ctx.fillStyle=i%2?'#53606b':'#899199';ctx.fillRect(r.x-30+(i*19)%70,r.y-60-age*.05-i*5,8+i%3*4,8+i%3*4);}ctx.restore();
  }else if(age<650){
   ctx.drawImage(im,Math.round(x),Math.round(y),Math.round(576*scale),Math.round(576*scale));
   const phase=Math.floor(age/80);ctx.fillStyle=phase%2?'#ffeaa0':'#ff6335';
   for(let i=0;i<12;i++){const a=i*Math.PI/6,radius=80-age*.07;ctx.fillRect(Math.round(r.x+Math.cos(a)*radius),Math.round(r.y-65+Math.sin(a)*radius*.7),8,8);}
   ctx.font='bold 18px sans-serif';ctx.textAlign='center';ctx.fillText('자폭 충전',r.x,r.y-def.height-5);
  }else burst(ctx,r.x,r.y-65,age-650);
 }
 function impact(ctx,event,time,target){const age=time-event.started;if(age>900)return;burst(ctx,target.x,target.y-target.h*.45,age);ctx.save();ctx.globalAlpha=1-age/1000;ctx.fillStyle='#ffe69c';ctx.font='bold 38px sans-serif';ctx.textAlign='center';ctx.fillText('자폭 −'+event.amount,target.x,target.y-target.h*.65-age*.04);ctx.restore();}
 function pose(r,time,target,height=140){
  if(r.id!=='mole'||r.action?.clip!=='attack'||r.ending)return{x:r.x,y:r.y};
  const age=time-r.action.started;
  // 880ms tread advance, 900ms strike, 360ms pivot, 640ms forward return, 360ms facing.
  let t=0,phase='forward';
  if(age<880)t=age/880;
  else if(age<1780){t=1;phase='strike';}
  else if(age<2140){t=1;phase='turn';}
  else if(age<2780){t=1-(age-2140)/640;phase='return';}
  else{t=0;phase='face';}
  const e=t*t*(3-2*t);return{x:r.x+(target.x-100*(height/140)-r.x)*e,y:r.y+(target.y-r.y)*e,phase};
 }
 function spark(ctx,x,y,age,color){
  if(age<0||age>300)return;ctx.fillStyle=color;
  for(let i=0;i<8;i++){const a=i*Math.PI/4,d=8+age*.12;ctx.fillRect(Math.round(x+Math.cos(a)*d),Math.round(y+Math.sin(a)*d),6,6);}
 }
 function fireball(ctx,sx,sy,tx,ty,t,clock,reflected=false){
  const x=sx+(tx-sx)*t,y=sy+(ty-sy)*t,a=Math.atan2(ty-sy,tx-sx);
  ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.shadowColor=reflected?'#71faff':'#ff6b16';ctx.shadowBlur=18;
  for(let i=9;i>=0;i--){const flicker=Math.sin(clock/35+i*2)*4,n=17-i;ctx.globalAlpha=1-i*.075;ctx.fillStyle=reflected?(i%2?'#2b9fff':'#73ffff'):(i%2?'#fa4918':'#ff9a20');ctx.fillRect(-i*7,-n/2+flicker,n+7,n);}
  ctx.globalAlpha=1;ctx.fillStyle='#ff6b20';ctx.fillRect(-14,-13,30,26);ctx.fillStyle='#ffd35b';ctx.fillRect(-9,-9,23,18);ctx.fillStyle='#fffbd3';ctx.fillRect(-3,-5,15,10);ctx.restore();
 }
 function status(ctx,r,time,height){ /* Paired overhead markers are drawn by the shared battlefield. */ }
 function reflection(ctx,r,time,target,height){
  if(r.reflectedAt===undefined)return;const age=time-r.reflectedAt;if(age<0||age>1100)return;
  const sx=r.x+35*height/140,sy=r.y-80*height/140,tx=target.x-35,ty=target.y-target.h*.45;
  ctx.save();
  if(age<260){ctx.globalAlpha=1-age/300;ctx.strokeStyle='#c4ffff';ctx.lineWidth=7;ctx.shadowColor='#38e5ff';ctx.shadowBlur=20;ctx.beginPath();ctx.arc(sx,sy,16+age*.16,0,Math.PI*2);ctx.stroke();spark(ctx,sx,sy,age,'#fff8cf');}
  if(age<750){ctx.fillStyle='#d1ffff';ctx.font='bold 23px sans-serif';ctx.textAlign='center';ctx.fillText('반사!',sx,sy-65-age*.025);}
  if(age>=150&&age<750)fireball(ctx,sx,sy,tx,ty,(age-150)/600,time,true);
  if(age>=750){spark(ctx,tx,ty,age-750,'#fff0b2');spark(ctx,tx,ty,age-770,'#70faff');}
  ctx.restore();
 }
 function weapon(ctx,r,time,target,height=140){
  if(!r||r.ending||!r.action)return;
  const k=height/140;target={...target,x:r.x+(target.x-r.x)/k,y:r.y+(target.y-r.y)/k};
  const age=time-r.action.started,p=pose(r,time,target);ctx.save();ctx.translate(r.x,r.y);ctx.scale(k,k);ctx.translate(-r.x,-r.y);
  if(r.action.clip==='attack'&&r.id==='rivet'){
   const sx=r.x+38,sy=r.y-90,tx=target.x-45,ty=target.y-100;
   if(age>=110&&age<510){fireball(ctx,sx,sy,tx,ty,(age-110)/400,time);spark(ctx,sx,sy,age-110,'#ffbf52');}
   spark(ctx,tx,ty,age-510,'#ff7a25');spark(ctx,tx,ty,age-550,'#fff0a2');
  }
  if(r.action.clip==='attack'&&r.id==='mole'){
   if(age>=1080&&age<1530){ctx.fillStyle='#aaa28a';for(let i=0;i<5;i++)ctx.fillRect(p.x-40-i*12,p.y-4-(i%2)*7,7,5);ctx.strokeStyle='#e3f5ff';ctx.lineWidth=3;for(let i=0;i<3;i++){const shift=(Math.floor(age/40)+i)%3*9;ctx.beginPath();ctx.moveTo(p.x+25+shift,p.y-60);ctx.lineTo(p.x+32+shift,p.y-47);ctx.stroke();}}
   spark(ctx,target.x-45,target.y-60,age-1210,'#d7c99d');
  }
  if(r.action.clip==='guard'){
   const contact=r.id==='bulwark'?490:310;
   if(r.id==='bulwark'&&age>=200&&age<970){
    ctx.strokeStyle='#8dd5df';ctx.lineWidth=4;ctx.strokeRect(r.x+20,r.y-125,15,110);
    if(age>=contact){for(let i=0;i<3;i++){ctx.strokeStyle=['#e2d9b5','#a3cbd1','#5f8490'][i];ctx.beginPath();ctx.moveTo(r.x+48+i*12,r.y-110);ctx.lineTo(r.x+56+i*12,r.y-65);ctx.lineTo(r.x+48+i*12,r.y-25);ctx.stroke();}spark(ctx,r.x+40,r.y-70,age-contact,'#ffe6a3');}
   }

  }
  ctx.restore();
 }
 return{robot,impact,pose,weapon,status,reflection};
})();
