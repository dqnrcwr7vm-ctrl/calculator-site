/* Approved v2: character-free layers; the battle clock owns timing and damage. */
window.HeroPrincess=(()=>{
 const enabled=!window.BATTLE_CONFIG?.partyTurns&&window.BATTLE_ASSETS[0].id==='hero';
 const root='../skills/hero-princess-im-coming-v2/';
 const skill={id:'princess-im-coming',name:'공주, 제가 갑니다!',clip:'princessSlam',impact:800,damage:980,offensive:true,target:'all-living-enemies',color:'#ffe3a0',cost:0};
 const order=[1,2,3,3,4,5,5,5,5,5,6,6,7,7,8,8,1,1,1,1];
 if(enabled){const attack=window.BATTLE_ASSETS[0].actions.attack;window.BATTLE_ASSETS[0].actions.princessSlam={...attack,frames:order.map(n=>attack.frames[n-1]),durations:order.map(()=>100)};}
 const layers={princess:[],ground:[]};
 async function load(loader){if(!enabled)return;await Promise.all(Object.keys(layers).map(async key=>{layers[key]=await Promise.all(order.map((_,i)=>loader(root+`frames/${key}/frame-${String(i+1).padStart(2,'0')}.webp`)));}));}
 function frame(current,state){return enabled&&current?.kind===skill.id&&state?.phase==='acting'?Math.min(19,Math.floor(state.local/100)):-1;}
 function drawBack(ctx,current,state){const n=frame(current,state);if(n<0)return;
  // Uniform 2x scale preserves the approved pixels; the ground lies under the enemy formation.
  ctx.drawImage(layers.princess[n],0,0,1600,800);
  ctx.drawImage(layers.ground[n],0,-145,1600,800);
 }
 function mount(start){if(!enabled)return;const b=document.createElement('button');b.dataset.action=skill.id;b.className='hero-princess';b.textContent='6 · 공주, 제가 갑니다!';b.title='살아 있는 적 전체 공격 · 기본 피해 980';b.style.cssText='position:absolute;right:1.2%;bottom:10%;z-index:4;padding:9px 16px;background:#242036;border:1px solid #e2ba6d;border-radius:4px;color:#ffe8ba;font-size:clamp(11px,1.1vw,17px)';b.onclick=()=>start(skill.id);document.querySelector('#scene').append(b);}
 return {skill:enabled?skill:null,load,frame,drawBack,mount};
})();
