/* Campaign economy. Existing class runtimes retain hero/wizard casting clocks. */
(function(root){
'use strict';
const CHARACTERS={dwarf:{hp:3400,mp:500},hero:{hp:2800,mp:700},archer:{hp:1800,mp:800},wizard:{hp:1400,mp:1200},priest:{hp:2200,mp:900},mechanic:{hp:2000,mp:600}};
const COSTS={
 hero:{'fire-slash':60,'frost-slash':60,'lightning-slash':60,'leaf-slash':60,'dark-slash':60,magic:90,'hero-roar':90,'sword-back':30,'princess-im-coming':180},
 dwarf:{'dwarf-taunt':30,'dwarf-bulwark':50,'dwarf-bash':45,'dwarf-wake':25,'dwarf-quake':60,'dwarf-mjolnir':75},
 archer:{'phoenix-shot':200,sniping:180,'arrow-rain':140,'leaf-wind':110,'stun-shot':35,'leg-bind':40,'natures-cure':60,'eagle-eye':70},
 wizard:{fireball:80,'ice-spear':80,'thunder-ball':80,void:80,meteor:240,blizzard:190,thunderstorm:210,'black-hole':280},
 priest:{'living-water':80,recovery:55,healing:100,blessing:120,barrier:90,resurrection:200,sanctuary:180,'holy-light':160},
 mechanic:{'mine-explosion':40,'install-rivet':80,'install-mole':100,'install-bulwark':110,'install-swat':90,'super-combine':140,'combined-gun':35,'combined-drill':45,'combined-beam':120}
};
const ROBOTS={rivet:{hp:320,reduction:0},mole:{hp:420,reduction:0},bulwark:{hp:650,reduction:.35},swat:{hp:450,reduction:.25}};
class ManaPool{
 constructor(){this.reset();}reset(){this.values=Object.fromEntries(Object.entries(CHARACTERS).map(([id,c])=>[id,c.mp]));}
 cost(role,id){return COSTS[role]?.[id]||0;}can(role,id){return this.values[role]>=this.cost(role,id);}
 spend(role,id){if(!this.can(role,id))return false;this.values[role]-=this.cost(role,id);return true;}
 restore(role,n){this.values[role]=Math.max(0,Math.min(CHARACTERS[role].mp,Number(n)||0));}
}
if(typeof module==='object'&&module.exports)module.exports={CHARACTERS,COSTS,ROBOTS,ManaPool};
if(!root.document)return;
const enabled=new URLSearchParams(location.search).get('campaign')==='1',pool=new ManaPool();
const native=role=>role==='hero'?root.PartyHero:role==='wizard'?root.WizardSkills:null;
const api=root.PartyResources={enabled,CHARACTERS,COSTS,ROBOTS,cost:(role,id)=>enabled?pool.cost(role,id):0,
 read(role){return native(role)?.mp??pool.values[role];},
 can(role,id){return !enabled||this.read(role)>=this.cost(role,id);},
 spend(role,id){if(!enabled||native(role))return true;return pool.spend(role,id);},
 restore(role,n){if(!enabled)return;if(native(role))native(role).restoreMp(n);else pool.restore(role,n);},
 recover(role,fraction){this.restore(role,this.read(role)+Math.round(CHARACTERS[role].mp*fraction));},
 snapshot(){return Object.fromEntries(root.BATTLE_ASSETS.slice(0,4).map(a=>[a.id,this.read(a.id)]));},
 restoreAll(values){if(values)for(const a of root.BATTLE_ASSETS.slice(0,4))if(values[a.id]!=null)this.restore(a.id,values[a.id]);},
 reset(){pool.reset();},
 sync(){if(!enabled)return;root.BATTLE_ASSETS.slice(0,4).forEach((a,i)=>{const card=document.querySelectorAll('#party .member')[i],mp=this.read(a.id);if(card){card.querySelector('.stat-line.mp').title='층 클리어: MP 25% 회복 · 중간 보스: MP 35%, HP 10% 회복';card.querySelector('.stat-line.mp span').textContent=mp+' / '+a.mp;card.querySelector('.mp-bar i').style.width=100*mp/a.mp+'%';}});},
 describe(role,id,text){if(!enabled)return text;if(role==='mechanic'&&id.startsWith('install-')){const robot=ROBOTS[id.slice(8)];if(robot)text='메카 HP '+robot.hp+' · 종류별 1기 동시 설치 · 3회 적 행동 후 남은 HP로 자폭. 광역 공격에 개별 피격.';}if(role==='mechanic'&&id==='super-combine')text='살아 있는 서로 다른 메카 2기 이상 필요. 설치된 메카를 소모하여 3턴 동안 합체합니다.';const clean=(text||'').replace(/MP\s*\d+\.?/g,'').trim();return clean+' · MP '+this.cost(role,id);}
};
})(typeof window!=='undefined'?window:globalThis);
