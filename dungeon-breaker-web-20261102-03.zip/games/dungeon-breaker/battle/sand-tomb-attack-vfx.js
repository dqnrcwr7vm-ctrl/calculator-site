/* Dungeon 06: approved body poses/local effects mapped to the live formation.
   PartyTurns owns target snapshots, damage, HURT and the shared clock. */
(function(root){
'use strict';
const base='../monsters/06-sand-tomb-v2/',data=root.SAND_TOMB_ATTACK_DATA,images=new Map(),clips=new Map();
const clamp=t=>Math.max(0,Math.min(1,t)),lerp=(a,b,t)=>a+(b-a)*t;
function frameAt(c,t){let i=0;while(i+1<c.timeline.length&&c.timeline[i+1].t<=t)i++;return i;}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='06'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;
 if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const c=a.visual,asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]),i=frameAt(c,age),f=c.timeline[i],next=c.timeline[Math.min(i+1,c.timeline.length-1)],u=next.t>f.t?clamp((age-f.t)/(next.t-f.t)):0;
 return{a,e,c,age,positions,scale,ratio:scale/c.monsterScale,f,position:f.position.map((x,j)=>lerp(x,next.position[j],u))};
}
function actor(v){
 const p=v.positions[v.a.targets[0]];if(!p)return null;const c=v.c,contactX=c.targetHitAnchor[0]-(c.sourceSocket[0]-c.sourceAnchor[0])*c.monsterScale;
 const progress=c.motionType==='melee-lunge'?clamp((c.homeAnchor[0]-v.position[0])/(c.homeAnchor[0]-contactX)):0;
 return{x:lerp(v.e.x,p.x-(c.sourceSocket[0]-c.sourceAnchor[0])*v.scale,progress),y:lerp(v.e.y,p.y-p.h*.55-(c.sourceSocket[1]-c.sourceAnchor[1])*v.scale,progress),scale:v.scale,anchor:c.sourceAnchor,path:base+c.bodyFrames[v.f.body],progress};
}
function records(v){
 const recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0),out=[],body=actor(v),c=v.c;
 for(const i of recipients){const p=v.positions[i];if(!p)continue;const target=[p.x,p.y-p.h*.55],unit=p.h/data.targetReferenceHeight;
  for(const q of v.f.sprites){let x,y,k;
   if(q.layer==='back'){
    // One physical actor/ground trail, even if an existing plan is area-targeted.
    if(i!==recipients[0])continue;k=v.ratio;x=body.x+(q.x-v.f.position[0])*k;y=body.y+(q.y-v.f.position[1])*k;
   }else if(q.layer==='impact'){
    k=unit;x=target[0]+(q.x-c.targetHitAnchor[0])*k;y=target[1]+(q.y-c.targetHitAnchor[1])*k;
   }else{
    // Preserve the authored arc/spread while continuously moving to the frozen recipient.
    const u=clamp((v.age-c.releaseMs)/(c.impactMs-c.releaseMs)),sampleU=clamp((v.f.t-c.releaseMs)/(c.impactMs-c.releaseMs));
    const src=c.sourceSocket.map((x,j)=>c.homeAnchor[j]+(x-c.sourceAnchor[j])*c.monsterScale),start=[v.e.x+(c.sourceSocket[0]-c.sourceAnchor[0])*v.scale,v.e.y+(c.sourceSocket[1]-c.sourceAnchor[1])*v.scale];
    k=lerp(v.ratio,unit,u);x=lerp(start[0],target[0],u)+(q.x-lerp(src[0],c.targetHitAnchor[0],sampleU))*k;y=lerp(start[1],target[1],u)+(q.y-lerp(src[1],c.targetHitAnchor[1],sampleU))*k;
   }
   out.push({path:base+q.path,anchor:q.anchor,x,y,scale:q.scale*k,alpha:q.opacity/255,layer:q.layer==='back'?'back':'front',tag:q.layer==='impact'?'contact':q.layer,target:i});
  }
 }return out;
}
root.SandTombAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='06')return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'06:'+c.monsterId+':'+c.action,adapter:'06',durationMs:c.endMs});c.bodyFrames.forEach(p=>paths.add(base+p));for(const f of c.timeline)for(const s of f.sprites)paths.add(base+s.path);}
  for(const path of paths)images.set(path,await loader(path));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='06'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=a&&images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(!im)continue;g.save();g.globalAlpha*=q.alpha;g.drawImage(im,q.x-q.anchor[0]*q.scale,q.y-q.anchor[1]*q.scale,im.width*q.scale,im.height*q.scale);g.restore();}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
