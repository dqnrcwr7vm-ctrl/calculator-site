/* Dungeon 10 visuals only. PartyTurns freezes recipients and owns damage/HURT,
   defenses, boss rules and lifecycle. Approved source assets remain read-only. */
(function(root){
'use strict';
const base='../monsters/10-pale-pilgrimage-v2/',data=root.PALE_PILGRIMAGE_ATTACK_DATA,images=new Map(),clips=new Map();
const clamp=x=>Math.max(0,Math.min(1,x)),mix=(a,b,t)=>a+(b-a)*t,total=a=>a.reduce((x,y)=>x+y,0),smooth=t=>{t=clamp(t);return t*t*(3-2*t)};
function frameAt(ds,t){let i=0;while(i<ds.length-1&&t>=ds[i])t-=ds[i++];return i;}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='10'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;
 if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]);
 return{a,e,c:a.visual,age,positions,scale,ratio:scale/data.referenceMonsterScale};
}
function hitPoint(v,i){const p=v.positions[i];return{x:p.x,y:p.y-p.h*data.targetHitHeightFraction,unit:p.h/data.targetReferenceHeight};}
function actor(v){
 const {c,e,age,scale}=v;let x=e.x,y=e.y;
 if(c.delivery==='contact'&&v.positions[v.a.targets[0]]){
  const hit=hitPoint(v,v.a.targets[0]),end={x:hit.x-(c.contactSocket[0]-c.body.anchor[0])*scale,y:hit.y-(c.contactSocket[1]-c.body.anchor[1])*scale},p=c.contactMotion;
  const u=age<p.approachStartMs?0:age<p.approachEndMs?smooth((age-p.approachStartMs)/(p.approachEndMs-p.approachStartMs)):age<p.contactHoldEndMs?1:age<p.returnEndMs?1-smooth((age-p.contactHoldEndMs)/(p.returnEndMs-p.contactHoldEndMs)):0;
  x=mix(e.x,end.x,u);y=mix(e.y,end.y,u);
 }
 const body=age<total(c.body.durations)?c.body:c.idle,t=body===c.idle?age%total(body.durations):age;
 return{x,y,scale,anchor:body.anchor,path:base+body.frames[frameAt(body.durations,t)]};
}
function records(v){
 const {c,age,e}=v,out=[],recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0);
 for(const i of recipients){if(!v.positions[i])continue;const hit=hitPoint(v,i);
  if(age>=c.releaseMs&&age<c.impactMs){
   const u=(age-c.releaseMs)/(c.impactMs-c.releaseMs),origin={x:e.x+(c.launchSocket[0]-c.body.anchor[0])*v.scale,y:e.y+(c.launchSocket[1]-c.body.anchor[1])*v.scale};
   const contact=c.delivery==='contact';
   out.push({path:base+c.travel.frames[frameAt(c.travel.durations,age-c.releaseMs)],anchor:c.travel.anchor,x:contact?hit.x+75*hit.unit*(1-u):mix(origin.x,hit.x,u),y:contact?hit.y-35*hit.unit*(1-u):mix(origin.y,hit.y,u),angle:contact?0:Math.atan2(hit.y-origin.y,hit.x-origin.x)-Math.PI,scale:contact?hit.unit:mix(v.ratio,hit.unit,u),layer:'front',tag:'travel',target:i});
  }
  const t=age-c.impactMs;if(t>=0&&t<total(c.impact.durations))out.push({path:base+c.impact.frames[frameAt(c.impact.durations,t)],anchor:c.impact.anchor,x:hit.x,y:hit.y,angle:0,scale:hit.unit,layer:'front',tag:'contact',target:i});
 }return out;
}
root.PalePilgrimageAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='10'||!data)return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.id,{...c,id:'10:'+c.id,adapter:'10'});for(const key of ['body','idle','travel','impact'])c[key].frames.forEach(p=>paths.add(base+p));}
  for(const p of paths)images.set(p,await loader(p));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='10'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(im){g.save();g.translate(q.x,q.y);g.rotate(q.angle);g.drawImage(im,-q.anchor[0]*q.scale,-q.anchor[1]*q.scale,im.width*q.scale,im.height*q.scale);g.restore();}}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
