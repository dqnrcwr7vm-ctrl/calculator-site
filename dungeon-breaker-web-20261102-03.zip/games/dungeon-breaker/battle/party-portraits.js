/* Portrait state playback shares the battle clock, pause, speed and reset. */
(()=>{
 let actors=[],canvases=[],images={},tracks=[];
 function fresh(){return {state:null,since:0,hurtAt:null,frame:-1};}
 function duration(clip){return clip.durations.reduce((a,b)=>a+b,0);}
 function frame(clip,age,loop){let t=Math.max(0,age),sum=duration(clip);if(loop)t%=sum;else if(t>=sum)return clip.durations.length-1;for(let n=0;n<clip.durations.length;n++){if(t<clip.durations[n])return n;t-=clip.durations[n];}return 0;}
 window.PartyPortraits={
 async load(load){actors=BATTLE_ASSETS.slice(0,4);await Promise.all(actors.map(async a=>{const source=window.PartyPortraitData[a.id];if(!source)return;images[a.id]={};await Promise.all(Object.entries(source).map(async([state,clip])=>{images[a.id][state]=await Promise.all(clip.frames.map(load));}));}));},
 mount(){canvases=[...document.querySelectorAll('#party .portrait')];tracks=actors.map(fresh);},
 hit(i,now){if(tracks[i]&&(actors[i].currentHp??actors[i].hp)>0){tracks[i].hurtAt=now;if(tracks[i].state==='hurt'){tracks[i].since=now;tracks[i].frame=-1;}}},
 update(now,victory){actors.forEach((a,i)=>{const source=window.PartyPortraitData[a.id],canvas=canvases[i],t=tracks[i];if(!source||!canvas||!t)return;
 const dead=(a.currentHp??a.hp)<=0;if(t.state==='defeat'&&!dead)t.hurtAt=null;
 const state=dead?'defeat':victory?'victory':t.hurtAt!==null&&now-t.hurtAt<duration(source.hurt)?'hurt':'idle';
 if(t.state!==state){t.state=state;t.since=state==='hurt'?t.hurtAt:now;t.frame=-1;canvas.dataset.portraitState=state;canvas.setAttribute('aria-label',a.name+' · '+state.toUpperCase());}
 const n=frame(source[state],now-t.since,state==='idle'||state==='victory');if(n===t.frame)return;t.frame=n;canvas.dataset.portraitFrame=String(n);const im=images[a.id]?.[state]?.[n];if(!im)return;
 const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);ctx.imageSmoothingEnabled=false;const scale=Math.min(canvas.width/im.width,canvas.height/im.height);ctx.drawImage(im,Math.round((canvas.width-im.width*scale)/2),Math.round((canvas.height-im.height*scale)/2),Math.round(im.width*scale),Math.round(im.height*scale));
 });},
 reset(){tracks=actors.map(fresh);}
 };
})();
