/* Aseprite-exported ultimate: 32 firing frames, 60 ms each. */
window.MechanicBeamVFX={
 images:[],
 async load(load){this.images=await Promise.all(Array.from({length:32},(_,i)=>load('../skills/mechanic-chest-beam-v3/beam/frame-'+String(i+1).padStart(2,'0')+'.webp?v=1')));},
 draw(ctx,actor,target,state,time){
  const k=(actor.h/371*2)/.78,origin={x:actor.x+70*k,y:actor.y-225*k};
  ctx.save();
  if(state.phase==='charging'){
   ctx.strokeStyle='#6ff5ff';ctx.fillStyle='#fff3a0';ctx.shadowColor='#29dfff';ctx.shadowBlur=16;
   for(let i=0;i<18;i++){const t=(time/950+i/18)%1,a=i*2.4+time/1700,r=(1-t)*115;ctx.globalAlpha=t;ctx.beginPath();ctx.arc(origin.x+Math.cos(a)*r,origin.y+Math.sin(a)*r*.7,2+t*3,0,Math.PI*2);ctx.fill();}
   ctx.globalAlpha=.7;ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(origin.x,origin.y,20+Math.sin(time/100)*4,32, -.4,0,Math.PI*2);ctx.stroke();
  }else if(state.phase==='acting'&&state.local>=560&&state.local<2480){
   const i=Math.min(31,Math.floor((state.local-560)/60)),end={x:target.x-45,y:target.y-target.h*.65},dx=end.x-origin.x,dy=end.y-origin.y,len=Math.hypot(dx,dy);
   ctx.translate(origin.x,origin.y);ctx.rotate(Math.atan2(dy,dx));ctx.globalCompositeOperation='lighter';
   ctx.drawImage(this.images[i],-90*len/810,-150,1024*len/810,300);
   ctx.globalAlpha=.65*(1-i/32);ctx.strokeStyle='#fff4b4';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(len,0,15+i*3,28+i*5,0,0,Math.PI*2);ctx.stroke();
  }
  ctx.restore();
 }
};
