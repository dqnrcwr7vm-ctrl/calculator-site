// Uses the battle clock, so pause, speed and finishing slow-motion stay in sync.
window.FireballVFX = {
 sample(def, local, origin, target) {
  const p=def.projectile;
  if(!p || local<p.release || local>=def.impact) return null;
  const progress=(local-p.release)/(def.impact-p.release);
  const from=p.origin||{x:origin.x+48,y:origin.y-origin.h*.62};
  return {x:from.x+(target.x-from.x)*progress,
   y:from.y+(target.y-from.y)*progress,
   angle:Math.atan2(target.y-from.y,target.x-from.x),age:local-p.release};
 },
 draw(ctx, image, pose, projectile) {
  ctx.save();ctx.translate(Math.round(pose.x),Math.round(pose.y));ctx.rotate(pose.angle);
  ctx.imageSmoothingEnabled=false;
  ctx.drawImage(image,-projectile.anchor[0]*projectile.size/128,-projectile.anchor[1]*projectile.size/128,projectile.size,projectile.size);
  ctx.restore();
 }
};
