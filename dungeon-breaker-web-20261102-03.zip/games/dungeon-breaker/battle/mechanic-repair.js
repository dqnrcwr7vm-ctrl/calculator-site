(function(root){
 const BALANCE={healRatio:.3,mpCost:0};
 function canRepair(s){const r=s?.robots?s.robots.find(r=>r.serial===s.repairTargetSerial)||s.robots.find(r=>r.hp>0&&!r.ending):s?.robot;return !!r&&r.hp>0&&!r.ending&&r.removeAt===undefined;}
 function repair(s,robots,serial){if(!canRepair(s)||!(s.robots?s.robots.some(r=>r.serial===serial&&r.hp>0&&!r.ending):s.robot.serial===serial))return null;const r=s.robots?s.robots.find(r=>r.serial===serial):s.robot,max=robots[r.id].maxHp,before=r.hp;r.hp=Math.min(max,r.hp+Math.round(max*BALANCE.healRatio));r.turns=0;return {healed:r.hp-before,hp:r.hp,remainingTurns:3};}
 function pose(time,home,target,work){const travel=1050,start=1170,end=start+work,total=end+1140,ease=t=>t*t*(3-2*t),mix=(a,b,t)=>a+(b-a)*ease(t);let x=home.x,y=home.y,phase='complete',phaseTime=0;
 if(time<travel){phase='advancing';phaseTime=time;const t=Math.max(0,time)/travel;x=mix(home.x,target.x,t);y=mix(home.y,target.y,t);}
 else if(time<start){phase='settling';x=target.x;y=target.y;}
 else if(time<end){phase='acting';phaseTime=time-start;x=target.x;y=target.y;}
 else if(time<total){phaseTime=time-end;if(phaseTime<280){phase='turning';x=target.x;y=target.y;}else if(phaseTime<760){phase='returning';const t=(phaseTime-280)/480;x=mix(target.x,home.x,t);y=mix(target.y,home.y,t);}else phase='facing';}
 return{x,y,phase,phaseTime,local:Math.max(0,time-start),stationary:false};}
 const api={BALANCE,canRepair,repair,pose};root.MechanicRepair=api;if(typeof module==='object')module.exports=api;
 const actor=root.BATTLE_ASSETS?.[0],c=root.BATTLE_CONFIG;if(actor?.id!=='mechanic'||!c)return;
 const source=actor.actions.install,seq=[0,1,2,1,2,1,2,0];actor.actions.mechRepair={...source,frames:seq.map(i=>source.frames[i]),durations:[180,220,300,220,300,220,300,180]};
 const skill={id:'mech-repair',name:'메카 수리',icon:'mech-repair',clip:'mechRepair',type:'skill',cost:BALANCE.mpCost,offensive:false,description:'설치된 메카로 이동해 수리 · 최대 HP 30% 회복(임시) · 남은 생존 3턴으로 갱신'};
 c.skillCatalog.push(skill);c.icons[skill.icon]=source.frames[2];api.skill=skill;
 if(new URLSearchParams(location.search).get('skill')==='mech-repair')c.initialSlots[0]={...skill};
})(typeof window==='undefined'?globalThis:window);
