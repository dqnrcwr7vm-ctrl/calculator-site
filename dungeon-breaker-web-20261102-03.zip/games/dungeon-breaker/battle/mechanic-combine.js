/* Adapter for the mechanic battle's resolved-attack turn boundaries. */
(function(root){
 const clips={"idle": {"frames": ["../characters/mechanic-combined-animations-v4/idle/frame-01.webp", "../characters/mechanic-combined-animations-v4/idle/frame-02.webp", "../characters/mechanic-combined-animations-v4/idle/frame-03.webp", "../characters/mechanic-combined-animations-v4/idle/frame-04.webp", "../characters/mechanic-combined-animations-v4/idle/frame-05.webp", "../characters/mechanic-combined-animations-v4/idle/frame-06.webp"], "durations": [240, 160, 180, 180, 160, 240], "size": [768, 768], "anchor": [320, 650]}, "attack": {"frames": ["../characters/mechanic-combined-animations-v4/attack/frame-01.webp", "../characters/mechanic-combined-animations-v4/attack/frame-02.webp", "../characters/mechanic-combined-animations-v4/attack/frame-03.webp", "../characters/mechanic-combined-animations-v4/attack/frame-04.webp", "../characters/mechanic-combined-animations-v4/attack/frame-05.webp", "../characters/mechanic-combined-animations-v4/attack/frame-06.webp"], "durations": [160, 120, 100, 100, 120, 220], "size": [768, 768], "anchor": [320, 650]}, "guard": {"frames": ["../characters/mechanic-combined-animations-v4/guard/frame-01.webp", "../characters/mechanic-combined-animations-v4/guard/frame-02.webp", "../characters/mechanic-combined-animations-v4/guard/frame-03.webp", "../characters/mechanic-combined-animations-v4/guard/frame-04.webp", "../characters/mechanic-combined-animations-v4/guard/frame-05.webp", "../characters/mechanic-combined-animations-v4/guard/frame-06.webp"], "durations": [160, 120, 220, 100, 180, 220], "size": [768, 768], "anchor": [320, 650]}, "hurt": {"frames": ["../characters/mechanic-combined-animations-v4/hurt/frame-01.webp", "../characters/mechanic-combined-animations-v4/hurt/frame-02.webp", "../characters/mechanic-combined-animations-v4/hurt/frame-03.webp", "../characters/mechanic-combined-animations-v4/hurt/frame-04.webp", "../characters/mechanic-combined-animations-v4/hurt/frame-05.webp", "../characters/mechanic-combined-animations-v4/hurt/frame-06.webp"], "durations": [100, 70, 140, 160, 140, 220], "size": [768, 768], "anchor": [320, 650]}, "drill": {"frames": ["../characters/mechanic-combined-animations-v4/skill/frame-01.webp", "../characters/mechanic-combined-animations-v4/skill/frame-02.webp", "../characters/mechanic-combined-animations-v4/skill/frame-03.webp", "../characters/mechanic-combined-animations-v4/skill/frame-04.webp", "../characters/mechanic-combined-animations-v4/skill/frame-05.webp", "../characters/mechanic-combined-animations-v4/skill/frame-06.webp"], "durations": [160, 120, 100, 130, 180, 220], "size": [768, 768], "anchor": [320, 650]}, "beam": {"frames": ["../characters/mechanic-combined-animations-v4/special-skill/frame-01.webp", "../characters/mechanic-combined-animations-v4/special-skill/frame-02.webp", "../characters/mechanic-combined-animations-v4/special-skill/frame-03.webp", "../characters/mechanic-combined-animations-v4/special-skill/frame-04.webp", "../characters/mechanic-combined-animations-v4/special-skill/frame-05.webp", "../characters/mechanic-combined-animations-v4/special-skill/frame-06.webp"], "durations": [160, 160, 240, 240, 180, 240], "size": [768, 768], "anchor": [320, 650]}};
 class MechanicCombineBattle {
  constructor(){this.skill=new root.SuperCombineSkill();this.hurtAt=null;this.beam=null;this.skill.onTurnStart('mechanic',1);}
  get active(){return this.skill.active;}
  get remainingTurns(){return this.skill.remainingTurns;}
  commands(normalSlots){
   if(!this.active)return normalSlots;
   // Reuse the existing attack damage until separate skill balancing is specified.
   const damage=root.BATTLE_CONFIG.skillCatalog.find(s=>s.id==='attack').damage;
   return [
    {id:'combined-gun',name:'기관총 사격',clip:'combinedAttack',impact:380,damage,offensive:true,icon:'combined-attack'},
    {id:'combined-drill',name:'드릴 공격',clip:'combinedDrill',impact:380,damage,offensive:true,icon:'combined-drill'},
    {id:'combined-beam',name:'가슴 빔 공격',clip:'combinedBeam',impact:560,damage,offensive:true,icon:'combined-beam'},
    {id:'combined-guard',name:'합체 메카 방어',clip:'combinedGuard',impact:500,damage:0,offensive:false,icon:'combined-guard'}
   ].map(s=>({...s,type:'skill',cost:0,color:'#ffd38b',description:s.name+' · 합체 상태 전용'}));
  }
  canChargeBeam(){return this.active&&this.remainingTurns>=2&&!this.beam;}
  chargeBeam(){if(!this.canChargeBeam())return false;this.beam={phase:'charging',turn:this.skill.turnId};return true;}
  beamPose(time,home){
   if(!this.beam)return {...home,phase:'complete',local:0,stationary:true};
   if(this.beam.phase==='charging')return {...home,phase:'charging',local:319,stationary:true};
   const local=560+Math.max(0,time-this.beam.started);
   return {...home,phase:local<2480?'acting':'beam-recovery',local:Math.min(local,2479),stationary:true};
  }
  drillPose(time,home,target){
   const advance=520,attack=910,retreat=620,end=advance+attack,total=end+retreat;
   const contact={x:target.x-170,y:target.y+100};
   const ease=t=>t*t*(3-2*t),mix=(a,b,t)=>a+(b-a)*ease(t);
   if(time<advance){const t=Math.max(0,time)/advance;return {x:mix(home.x,contact.x,t),y:mix(home.y,contact.y,t),phase:'advancing',local:0,stationary:false};}
   if(time<end)return {...contact,phase:'acting',local:time-advance,stationary:false};
   if(time<total){const t=(time-end)/retreat;return {x:mix(contact.x,home.x,t),y:mix(contact.y,home.y,t),phase:'returning',local:attack-1,stationary:false};}
   return {...home,phase:'complete',local:attack-1,stationary:false};
  }
  units(combat){return (combat?.robots||[]).filter(r=>r.hp>0&&!r.ending&&r.removeAt===undefined).map(r=>({ownerId:'mechanic',kind:'mech',onField:true,hp:r.hp}));}
  canActivate(combat){return combat?.hp>0&&this.skill.canActivate(this.units(combat));}
  activate(combat){
   if(!this.canActivate(combat)||!this.skill.activate(this.units(combat)))return false;
   const serials=combat.robots.map(r=>r.serial);
   combat.robots=[];
   // The summoned unit is consumed, including an in-flight attack or guard.
   if(serials.includes(combat.incoming?.serial)){combat.incoming.id=null;combat.incoming.serial=null;combat.incoming.reduction=0;}
   return true;
  }
  event(event,time){
   if(event.type==='hurt'&&this.active)this.hurtAt=time;
   if(event.type!=='turn-end')return false;
   const expired=this.skill.onTurnEnd('mechanic',event.turn);
   if(expired)this.beam=null;
   else if(this.beam?.phase==='charging'&&event.turn===this.beam.turn)this.beam={phase:'firing',started:time,turn:event.turn+1};
   else if(this.beam?.phase==='firing'&&event.turn===this.beam.turn)this.beam=null;
   this.skill.onTurnStart('mechanic',event.turn+1);return expired;
  }
  destroy(){this.skill.destroy();this.beam=null;}
  action(def){if(!this.active)return def;
   if(def.clip==='attack')return {...def,name:'어깨 기관총 사격',clip:'combinedAttack',impact:380,description:'현재 자리에서 어깨 기관총으로 전방의 적을 공격합니다.'};
   if(def.clip==='guard')return {...def,name:'합체 메카 방어',clip:'combinedGuard',impact:500,description:'현재 자리에서 합체 메카의 방패로 방어합니다.'};
   return def;
  }
 }
 root.MechanicCombineBattle=MechanicCombineBattle;
 if(root.BATTLE_CONFIG&&root.BATTLE_ASSETS?.[0]?.id==='mechanic'){
  const c=root.BATTLE_CONFIG;
  const skill={id:'super-combine',name:'초 합체!',type:'skill',clip:'combinedAssembly',impact:0,damage:0,offensive:false,color:'#ffa54d',icon:'super-combine',description:'필드에 메카 2기 이상 필요 · 사용 턴 포함 3턴 유지'};
  c.superCombine=true;c.skillCatalog.push(skill);if(!c.installOnlyLoadout)c.initialSlots[2]={...skill};c.icons['super-combine']=clips.idle.frames[0];
  for(const key of ['attack','drill','beam','guard'])c.icons['combined-'+key]=clips[key].frames[3];
  root.BATTLE_ASSETS[0].actions.combinedAssembly={frames:Array.from({length:12},(_,i)=>'../skills/mechanic-super-combine-assembly-v1/frame-'+String(i+1).padStart(2,'0')+'.webp'),durations:[260,180,120,220,120,220,120,300,180,260,160,320],size:[768,768],anchor:[320,650]};
  clips.beam={frames:Array.from({length:40},(_,i)=>'../skills/mechanic-chest-beam-v3/mech/frame-'+String(i+1).padStart(2,'0')+'.webp?v=3'),durations:[...Array(8).fill(70),...Array(32).fill(60)],size:[768,768],anchor:[320,650]};
  for(const [key,clip] of Object.entries(clips))root.BATTLE_ASSETS[0].actions['combined'+key[0].toUpperCase()+key.slice(1)]=clip;
 }
})(typeof window==='undefined'?globalThis:window);
