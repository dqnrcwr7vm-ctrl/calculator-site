// One-run loot state. Equipping always replaces one of four slots atomically.
window.BattleLoot=(()=>{
 const initial=[
  {id:'attack',name:'철퇴 강타',type:'skill',clip:'attack',impact:690,damage:980,offensive:true,color:'#ffe3a0',icon:0,cost:20,description:'철퇴로 적에게 980 피해를 줍니다.'},
  {id:'charge',name:'방패 돌진',type:'skill',clip:'guard',impact:600,damage:720,offensive:true,color:'#83dfff',icon:1,cost:15,description:'방패를 앞세워 720 피해를 줍니다.'},
  {id:'magic',name:'불굴의 의지',type:'skill',clip:'magic',impact:950,damage:0,offensive:false,color:'#f5d374',icon:2,cost:30,description:'수호의 힘을 끌어올립니다.'},
  {id:'item',name:'회복 물약',type:'heal',clip:'item',impact:1050,damage:0,offensive:false,color:'#72efbc',icon:3,quantity:3,description:'회복 물약을 제자리에서 사용합니다.'}
 ];
 const pool=[
  {id:'knife',name:'투척 단검',type:'item',clip:'attack',impact:690,damage:800,offensive:true,icon:0,quantity:3,description:'날카로운 단검으로 적에게 800 피해.'},
  {id:'bomb',name:'화약 폭탄',type:'item',clip:'attack',impact:690,damage:1200,offensive:true,icon:0,quantity:2,description:'폭탄을 사용해 적에게 1,200 피해.'},
  {id:'axe',name:'투척 도끼',type:'item',clip:'attack',impact:690,damage:1050,offensive:true,icon:0,quantity:3,description:'묵직한 도끼로 적에게 1,050 피해.'},
  {id:'fire',name:'화염 폭발',type:'scroll',clip:'magic',impact:950,damage:1450,offensive:true,icon:2,cost:35,description:'스크롤을 익혀 화염 스킬을 장착합니다. 피해 1,450.'},
  {id:'frost',name:'서리 강타',type:'scroll',clip:'magic',impact:950,damage:1150,offensive:true,icon:1,cost:25,description:'스크롤을 익혀 서리 스킬을 장착합니다. 피해 1,150.'},
  {id:'thunder',name:'낙뢰',type:'scroll',clip:'magic',impact:950,damage:1600,offensive:true,icon:2,cost:40,description:'스크롤을 익혀 번개 스킬을 장착합니다. 피해 1,600.'},
  {id:'greater-potion',name:'상급 회복 물약',type:'heal',clip:'item',impact:1050,damage:0,offensive:false,icon:3,quantity:3,description:'기존 행동 한 칸에 상급 회복 물약을 장착합니다.'},
  {id:'elixir',name:'생명의 영약',type:'heal',clip:'item',impact:1050,damage:0,offensive:false,icon:3,quantity:2,description:'생명의 영약을 제자리에서 사용합니다.'},
  {id:'herbs',name:'치유의 약초',type:'heal',clip:'item',impact:1050,damage:0,offensive:false,icon:3,quantity:5,description:'치유의 약초를 제자리에서 사용합니다.'}
 ].map(x=>({...x,color:x.offensive?'#ffe3a0':'#72efbc'}));
 function create(round=1){return{round,stage:'battle',slots:initial.map(x=>({...x})),offers:[],selected:null,lastSwap:null};}
 function clear(state){if(state.stage!=='battle')throw Error('전투 중에만 클리어할 수 있습니다.');return{...state,stage:'clear'};}
 function open(state,rng=Math.random){
  if(state.stage!=='clear')throw Error('클리어 후 전리품을 확인하세요.');
  const offers=['item','scroll','heal'].map(type=>{const choices=pool.filter(x=>x.type===type&&!state.slots.some(s=>s.id===x.id));return{...choices[Math.min(choices.length-1,Math.floor(rng()*choices.length))]};});
  for(let i=offers.length-1;i>0;i--){const j=Math.min(i,Math.floor(rng()*(i+1)));[offers[i],offers[j]]=[offers[j],offers[i]];}
  return{...state,stage:'loot',offers,selected:null};
 }
 function select(state,id){if(state.stage!=='loot'||!state.offers.some(o=>o.id===id))throw Error('전리품을 선택하세요.');return{...state,stage:'replace',selected:id};}
 function back(state){if(state.stage!=='replace')throw Error('교체 화면이 아닙니다.');return{...state,stage:'loot',selected:null};}
 function advance(state,slots=state.slots,lastSwap=null){return{...state,round:Math.min(3,state.round+1),stage:state.round===3?'complete':'battle',slots,offers:[],selected:null,lastSwap};}
 function replace(state,index){
  if(state.stage!=='replace'||!Number.isInteger(index)||index<0||index>3)throw Error('교체할 행동을 선택하세요.');
  const item=state.offers.find(o=>o.id===state.selected);if(!item)throw Error('전리품이 없습니다.');
  const slots=state.slots.map((s,i)=>i===index?{...item}:s);
  return advance(state,slots,{from:state.slots[index].name,to:item.name,index});
 }
 function skip(state){if(state.stage!=='loot')throw Error('전리품 선택 화면에서만 건너뛸 수 있습니다.');return advance(state);}
 return{create,clear,open,select,back,replace,skip};
})();
