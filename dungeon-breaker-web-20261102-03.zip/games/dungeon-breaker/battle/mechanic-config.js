window.BATTLE_ASSETS[0] = {
  "frames": [
    "../characters/mechanic-animations-v1/idle/frame-01.webp",
    "../characters/mechanic-animations-v1/idle/frame-02.webp",
    "../characters/mechanic-animations-v1/idle/frame-03.webp",
    "../characters/mechanic-animations-v1/idle/frame-04.webp",
    "../characters/mechanic-animations-v1/idle/frame-05.webp",
    "../characters/mechanic-animations-v1/idle/frame-06.webp",
    "../characters/mechanic-animations-v1/idle/frame-07.webp",
    "../characters/mechanic-animations-v1/idle/frame-08.webp"
  ],
  "durations": [
    300,
    140,
    160,
    240,
    180,
    160,
    140,
    300
  ],
  "id": "mechanic",
  "name": "메카닉",
  "hp": 1720,
  "mp": 300,
  "size": [
    576,
    576
  ],
  "bounds": [
    95,
    130,
    440,
    501
  ],
  "anchor": [
    270,
    500
  ],
  "portrait": "../characters/mechanic-status-animations-v1/idle/frame-01.webp",
  "portraitBounds": [
    11,
    45,
    106,
    159
  ],
  "actions": {
    "attack": {
      "frames": [
        "../characters/mechanic-animations-v1/attack/frame-01.webp",
        "../characters/mechanic-animations-v1/attack/frame-02.webp",
        "../characters/mechanic-animations-v1/attack/frame-03.webp",
        "../characters/mechanic-animations-v1/attack/frame-04.webp",
        "../characters/mechanic-animations-v1/attack/frame-05.webp",
        "../characters/mechanic-animations-v1/attack/frame-06.webp",
        "../characters/mechanic-animations-v1/attack/frame-07.webp",
        "../characters/mechanic-animations-v1/attack/frame-08.webp"
      ],
      "durations": [
        240,
        170,
        220,
        70,
        110,
        150,
        180,
        240
      ]
    },
    "guard": {
      "frames": [
        "../characters/mechanic-animations-v1/guard/frame-01.webp",
        "../characters/mechanic-animations-v1/guard/frame-02.webp",
        "../characters/mechanic-animations-v1/guard/frame-03.webp",
        "../characters/mechanic-animations-v1/guard/frame-04.webp",
        "../characters/mechanic-animations-v1/guard/frame-05.webp",
        "../characters/mechanic-animations-v1/guard/frame-06.webp",
        "../characters/mechanic-animations-v1/guard/frame-07.webp",
        "../characters/mechanic-animations-v1/guard/frame-08.webp"
      ],
      "durations": [
        240,
        120,
        140,
        240,
        90,
        200,
        150,
        240
      ]
    },
    "install": {
      "frames": [
        "../characters/mechanic-animations-v1/install/frame-01.webp",
        "../characters/mechanic-animations-v1/install/frame-02.webp",
        "../characters/mechanic-animations-v1/install/frame-03.webp",
        "../characters/mechanic-animations-v1/install/frame-04.webp",
        "../characters/mechanic-animations-v1/install/frame-05.webp",
        "../characters/mechanic-animations-v1/install/frame-06.webp",
        "../characters/mechanic-animations-v1/install/frame-07.webp",
        "../characters/mechanic-animations-v1/install/frame-08.webp"
      ],
      "durations": [
        250,
        200,
        220,
        230,
        320,
        240,
        230,
        500
      ]
    },
    "item": {
      "frames": [
        "../characters/mechanic-animations-v1/item/frame-01.webp",
        "../characters/mechanic-animations-v1/item/frame-02.webp",
        "../characters/mechanic-animations-v1/item/frame-03.webp",
        "../characters/mechanic-animations-v1/item/frame-04.webp",
        "../characters/mechanic-animations-v1/item/frame-05.webp",
        "../characters/mechanic-animations-v1/item/frame-06.webp",
        "../characters/mechanic-animations-v1/item/frame-07.webp",
        "../characters/mechanic-animations-v1/item/frame-08.webp"
      ],
      "durations": [
        250,
        160,
        170,
        350,
        160,
        180,
        150,
        250
      ]
    },
    "forward": {
      "frames": [
        "../characters/mechanic-travel-animations-v1/approach/frame-01.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-02.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-03.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-04.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-05.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-06.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-07.webp",
        "../characters/mechanic-travel-animations-v1/approach/frame-08.webp"
      ],
      "durations": [
        160,
        110,
        110,
        100,
        110,
        100,
        140,
        220
      ],
      "anchor": [
        288,
        500
      ]
    },
    "return": {
      "frames": [
        "../characters/mechanic-travel-animations-v1/return/frame-01.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-02.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-03.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-04.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-05.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-06.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-07.webp",
        "../characters/mechanic-travel-animations-v1/return/frame-08.webp"
      ],
      "durations": [
        140,
        140,
        120,
        110,
        120,
        130,
        160,
        220
      ],
      "anchor": [
        288,
        500
      ]
    }
  }
};
window.BATTLE_CONFIG = {
  "positions": {"4": {"x": 1380}},
  "round": 3,
  "initialSlots": [
    {
      "id": "attack",
      "name": "몽키스패너 강타",
      "type": "skill",
      "clip": "attack",
      "impact": 700,
      "damage": 980,
      "offensive": true,
      "color": "#ffe3a0",
      "icon": 0,
      "cost": 0,
      "description": "중앙으로 이동해 몽키스패너로 공격한 뒤 돌아옵니다."
    },
    {
      "id": "install-rivet",
      "name": "리벳 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "rivet",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "rivet",
      "cost": 30,
      "description": "2.4초마다 260 피해 · 종류별 1기 · 다른 메카와 동시 설치"
    },
    {
      "id": "install-bulwark",
      "name": "불워크 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "bulwark",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "bulwark",
      "cost": 30,
      "description": "적 공격 피해 75% 차단 · 종류별 1기 · 다른 메카와 동시 설치"
    },
    {
      "id": "item",
      "name": "회복 물약",
      "type": "heal",
      "clip": "item",
      "impact": 930,
      "damage": 0,
      "offensive": false,
      "color": "#72efbc",
      "icon": 3,
      "quantity": 3,
      "description": "현재 자리에서 물약을 사용합니다."
    }
  ],
  "icons": {
    "0": "../characters/mechanic-animations-v1/attack/frame-05.webp",
    "1": "../characters/mechanic-animations-v1/install/frame-05.webp",
    "2": "../characters/mechanic-animations-v1/guard/frame-05.webp",
    "3": "../characters/mechanic-animations-v1/item/frame-05.webp",
    "rivet": "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-01.webp",
    "mole": "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-01.webp",
    "bulwark": "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-01.webp",
    "swat": "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-01.webp"
  },
  "robots": {
    "rivet": {
      "name": "리벳",
      "damageImpact": 510,
      "role": "attack",
      "damage": 260,
      "interval": 2400,
      "reduction": 0,
      "impact": 330,
      "actions": {
        "idle": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/idle/frame-06.webp"
          ],
          "durations": [
            240,
            160,
            180,
            160,
            160,
            240
          ]
        },
        "attack": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/01-rivet/attack/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/attack/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/attack/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/attack/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/attack/frame-05.webp"
          ],
          "durations": [
            200,
            130,
            80,
            170,
            320
          ]
        },
        "hurt": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/01-rivet/hurt/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/hurt/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/hurt/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/hurt/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/01-rivet/hurt/frame-05.webp"
          ],
          "durations": [
            180,
            70,
            150,
            180,
            320
          ]
        }
      },
      "size": [
        576,
        576
      ],
      "anchor": [
        260,
        500
      ],
      "height": 220,
      "sourceHeight": 233,
      "maxHp": 600
    },
    "mole": {
      "name": "몰",
      "role": "attack",
      "damage": 460,
      "interval": 4600,
      "reduction": 0,
      "impact": 330,
      "actions": {
        "idle": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/idle/frame-06.webp"
          ],
          "durations": [
            240,
            160,
            180,
            160,
            160,
            240
          ]
        },
        "attack": {
          "frames": [
            "../characters/mole-travel-v1/forward/frame-01.webp",
            "../characters/mole-travel-v1/forward/frame-02.webp",
            "../characters/mole-travel-v1/forward/frame-03.webp",
            "../characters/mole-travel-v1/forward/frame-04.webp",
            "../characters/mole-travel-v1/forward/frame-05.webp",
            "../characters/mole-travel-v1/forward/frame-06.webp",
            "../characters/mole-travel-v1/forward/frame-07.webp",
            "../characters/mole-travel-v1/forward/frame-08.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-05.webp",
            "../characters/mole-travel-v1/return/frame-01.webp",
            "../characters/mole-travel-v1/return/frame-02.webp",
            "../characters/mole-travel-v1/return/frame-03.webp",
            "../characters/mole-travel-v1/return/frame-04.webp",
            "../characters/mole-travel-v1/return/frame-05.webp",
            "../characters/mole-travel-v1/return/frame-06.webp",
            "../characters/mole-travel-v1/return/frame-07.webp",
            "../characters/mole-travel-v1/return/frame-08.webp"
          ],
          "durations": [
            110,
            110,
            110,
            110,
            110,
            110,
            110,
            110,
            200,
            130,
            80,
            170,
            320,
            180,
            180,
            160,
            160,
            160,
            160,
            180,
            180
          ]
        },
        "hurt": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/02-mole/hurt/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/hurt/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/hurt/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/hurt/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/hurt/frame-05.webp"
          ],
          "durations": [
            180,
            70,
            150,
            180,
            320
          ]
        },
        "strike": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/02-mole/attack/frame-05.webp"
          ],
          "durations": [
            200,
            130,
            80,
            170,
            320
          ]
        },
        "forward": {
          "frames": [
            "../characters/mole-travel-v1/forward/frame-01.webp",
            "../characters/mole-travel-v1/forward/frame-02.webp",
            "../characters/mole-travel-v1/forward/frame-03.webp",
            "../characters/mole-travel-v1/forward/frame-04.webp",
            "../characters/mole-travel-v1/forward/frame-05.webp",
            "../characters/mole-travel-v1/forward/frame-06.webp",
            "../characters/mole-travel-v1/forward/frame-07.webp",
            "../characters/mole-travel-v1/forward/frame-08.webp"
          ],
          "durations": [
            110,
            110,
            110,
            110,
            110,
            110,
            110,
            110
          ]
        },
        "return": {
          "frames": [
            "../characters/mole-travel-v1/return/frame-01.webp",
            "../characters/mole-travel-v1/return/frame-02.webp",
            "../characters/mole-travel-v1/return/frame-03.webp",
            "../characters/mole-travel-v1/return/frame-04.webp",
            "../characters/mole-travel-v1/return/frame-05.webp",
            "../characters/mole-travel-v1/return/frame-06.webp",
            "../characters/mole-travel-v1/return/frame-07.webp",
            "../characters/mole-travel-v1/return/frame-08.webp"
          ],
          "durations": [
            180,
            180,
            160,
            160,
            160,
            160,
            180,
            180
          ]
        }
      },
      "size": [
        576,
        576
      ],
      "anchor": [
        260,
        500
      ],
      "height": 220,
      "sourceHeight": 219,
      "maxHp": 900,
      "damageImpact": 1210
    },
    "bulwark": {
      "name": "불워크",
      "role": "guard",
      "damage": 0,
      "interval": 0,
      "reduction": 0.75,
      "impact": 490,
      "actions": {
        "idle": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/idle/frame-06.webp"
          ],
          "durations": [
            240,
            160,
            180,
            160,
            160,
            240
          ]
        },
        "guard": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-06.webp",
            "../characters/mechanic-robots-animations-v2/03-bulwark/guard/frame-07.webp"
          ],
          "durations": [
            200,
            110,
            180,
            80,
            260,
            140,
            250
          ]
        }
      },
      "size": [
        576,
        576
      ],
      "anchor": [
        260,
        500
      ],
      "height": 220,
      "sourceHeight": 335,
      "maxHp": 1200
    },
    "swat": {
      "name": "스와트",
      "role": "guard",
      "damage": 0,
      "interval": 0,
      "reduction": 0.5,
      "impact": 310,
      "actions": {
        "idle": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/idle/frame-06.webp"
          ],
          "durations": [
            240,
            160,
            180,
            160,
            160,
            240
          ]
        },
        "guard": {
          "frames": [
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-01.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-02.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-03.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-04.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-05.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-06.webp",
            "../characters/mechanic-robots-animations-v2/04-swat/guard/frame-07.webp"
          ],
          "durations": [
            200,
            110,
            80,
            140,
            120,
            140,
            250
          ]
        }
      },
      "size": [
        576,
        576
      ],
      "anchor": [
        260,
        500
      ],
      "height": 220,
      "sourceHeight": 323,
      "maxHp": 800
    }
  },
  "skillCatalog": [
    {
      "id": "attack",
      "name": "몽키스패너 강타",
      "type": "skill",
      "clip": "attack",
      "impact": 700,
      "damage": 980,
      "offensive": true,
      "color": "#ffe3a0",
      "icon": 0,
      "cost": 0,
      "description": "중앙으로 이동해 몽키스패너로 공격한 뒤 돌아옵니다."
    },
    {
      "id": "guard",
      "name": "스패너 방어",
      "type": "skill",
      "clip": "guard",
      "impact": 500,
      "damage": 0,
      "offensive": false,
      "color": "#83dfff",
      "icon": 2,
      "cost": 0,
      "description": "현재 자리에서 몽키스패너로 방어합니다."
    },
    {
      "id": "item",
      "name": "회복 물약",
      "type": "heal",
      "clip": "item",
      "impact": 930,
      "damage": 0,
      "offensive": false,
      "color": "#72efbc",
      "icon": 3,
      "quantity": 3,
      "description": "현재 자리에서 물약을 사용합니다."
    },
    {
      "id": "install-rivet",
      "name": "리벳 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "rivet",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "rivet",
      "cost": 30,
      "description": "2.4초마다 260 피해 · 종류별 1기 · 다른 메카와 동시 설치"
    },
    {
      "id": "install-mole",
      "name": "몰 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "mole",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "mole",
      "cost": 30,
      "description": "3.6초마다 460 피해 · 종류별 1기 · 다른 메카와 동시 설치"
    },
    {
      "id": "install-bulwark",
      "name": "불워크 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "bulwark",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "bulwark",
      "cost": 30,
      "description": "적 공격 피해 75% 차단 · 종류별 1기 · 다른 메카와 동시 설치"
    },
    {
      "id": "install-swat",
      "name": "스와트 설치",
      "type": "skill",
      "clip": "install",
      "robotId": "swat",
      "impact": 1460,
      "damage": 0,
      "offensive": false,
      "color": "#75e8de",
      "icon": "swat",
      "cost": 30,
      "description": "적 공격 피해 50% 차단 · 종류별 1기 · 다른 메카와 동시 설치"
    }
  ]
};

// Four independent deployment commands for the mechanic installation sandbox.
window.BATTLE_CONFIG.installOnlyLoadout = true;
window.BATTLE_CONFIG.initialSlots = ["rivet", "mole", "bulwark", "swat"].map(id => ({...window.BATTLE_CONFIG.skillCatalog.find(skill => skill.id === "install-" + id)}));

// Summon combat identities; damage values remain the existing test balance.
Object.assign(window.BATTLE_CONFIG.robots.rivet, {attackType:'ranged', element:'fire'});
Object.assign(window.BATTLE_CONFIG.robots.mole, {attackType:'melee', element:'physical'});
Object.assign(window.BATTLE_CONFIG.robots.bulwark, {taunt:true});
Object.assign(window.BATTLE_CONFIG.robots.swat, {reflectRanged:true, reduction:0});
for (const skill of [...window.BATTLE_CONFIG.skillCatalog, ...window.BATTLE_CONFIG.initialSlots]) {
 const descriptions = {rivet:'불속성 일반 공격 260 · 후방 화염탄', mole:'일반 공격 460 · 전진 드릴 타격', bulwark:'도발로 적 공격 유도 · 받는 피해 75% 감소', swat:'원거리 공격을 막고 같은 피해 반사 · 근접 반사 불가'};
 if (skill.robotId) skill.description = descriptions[skill.robotId];
}
