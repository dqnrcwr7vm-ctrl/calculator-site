/* Shared learned basic actions; existing hero/mechanic adapters retain their actions. */
(()=>{
 const specs={};
 for(const role of ['dwarf','archer','wizard','priest']){
  specs[role+'-potion']={id:role+'-potion',name:'회복 물약',clip:'item',heal:600,description:'자신의 HP를 600 회복합니다. 층마다 3회 사용할 수 있습니다.'};
  if(['dwarf','archer'].includes(role)){
   specs[role+'-attack']={id:role+'-attack',name:'일반 공격',clip:'attack',single:true,damage:980,description:(role==='dwarf'?'망치':'활')+'로 선택한 적 하나에게 980 기본 피해를 줍니다. MP 소모 없음.'};
   specs[role+'-guard']={id:role+'-guard',name:'일반 방어',clip:'guard',guard:true,description:(role==='dwarf'?'방패':'활')+'로 방어해 이번 적 행동 동안 받는 피해를 50% 줄입니다.'};
  }
 }
 for(const role of ['hero','dwarf','archer','mechanic','wizard','priest'])for(const [key,def]of Object.entries({
  strike:{name:'기본 공격',clip:'attack',single:true,damage:150,description:'MP 없이 단일 적을 공격합니다.'},
  brace:{name:'방어·집중',clip:'guard',guard:true,description:'이번 적 행동의 받는 피해를 50% 줄이고 자신의 최대 MP 12%를 회복합니다.'},
  check:{name:'견제',clip:'attack',single:true,damage:25,disrupt:true,description:'MP 없이 충전 파훼에 참여합니다. 같은 적을 두 명이 견제하면 이번 턴 화력 40% 감소, 추가 장갑과 독 부여를 억제합니다.'},
  supply:{name:'비상 보급',clip:'item',supply:true,description:'층마다 개인 1회. 자신의 HP 20%, MP 15%를 회복하며 행동을 사용합니다.'}
 })){const id=role+'-common-'+key;specs[id]={id,...def,clip:def.clip==='attack'&&['wizard','priest'].includes(role)?'magic':def.clip,common:true};}
 specs['mechanic-common-strike'].name='일반공격';
 // Fixed command: independent of the four learned skills and never a draft offer.
 for(const role of ['hero','dwarf','archer','mechanic','wizard','priest']){
  const id=role+'-default-guard';specs[id]={id,name:'일반 방어',clip:'guard',guard:true,defaultCommand:true,description:'MP 소모 없이 이번 적 행동 동안 자신이 받는 피해를 50% 줄입니다. 현재 캐릭터의 행동을 사용합니다.'};
 }
 let active=null;const guards=new Set(),potions=new Map(),supplies=new Set(),total=c=>c.durations.reduce((a,b)=>a+b,0);
 const party=()=>BATTLE_ASSETS.slice(0,4),guardClip=a=>a.id==='mechanic'&&window.PartyMechanic?.state.combined?'combinedGuard':'guard',sample=now=>{const a=party()[active.i],s=specs[active.id];return BattleMotion.sample((s.defaultCommand&&a.id!=='dwarf'||a.id==='mechanic'&&s.common)?'magic':s.clip,now-active.started,total(a.actions[active.clip]),a.id,BATTLE_CONFIG.positions[active.i]);};
 window.PartyBasicActions={specs,catalog:role=>Object.values(specs).filter(s=>s.id.startsWith(role+'-')&&!s.common&&!s.defaultCommand),get busy(){return !!active;},
 canUse(i,id,targets){const s=specs[id],a=party()[i];return !!s&&id.startsWith(a.id+'-')&&!active&&(a.currentHp??a.hp)>0&&(!s.supply||!supplies.has(i))&&(!s.heal||(potions.get(i)??3)>0)&&(!s.single||targets.some(e=>e.hp>0&&(!window.WizardSkills||WizardSkills.canSelect(e))));},
 start(i,id,target,now){if(!this.canUse(i,id,target?[target]:[]))return false;active={i,id,target:target?.id,started:now,hit:false,clip:specs[id].defaultCommand?guardClip(party()[i]):specs[id].clip};return true;},
 update(now,bridge){if(!active)return;const a=active,s=specs[a.id],m=sample(now);if(m.phase==='acting')window.DungeonVoices?.action(party()[a.i].id,a.id,a);if(!a.hit&&now-a.started>=m.start+Math.min(700,total(party()[a.i].actions[a.clip])*.6)){a.hit=true;if(s.heal){potions.set(a.i,(potions.get(a.i)??3)-1);const unit=party()[a.i];unit.currentHp=Math.min(unit.hp,(unit.currentHp??unit.hp)+s.heal);bridge.hit(a.i,0);}if(s.supply){supplies.add(a.i);const unit=party()[a.i];unit.currentHp=Math.min(unit.hp,(unit.currentHp??unit.hp)+Math.round(unit.hp*.2));const runtime=unit.id==='hero'?window.PartyHero:unit.id==='wizard'?window.WizardSkills:null;if(window.PartyResources?.enabled)PartyResources.recover(unit.id,.15);else if(runtime)runtime.restoreMp(runtime.mp+Math.round(unit.mp*.15));bridge.hit(a.i,0);}if(s.guard){guards.add(a.i);if(s.common&&window.PartyResources?.enabled)PartyResources.recover(party()[a.i].id,.12);}if(s.single){const es=bridge.enemies().filter(e=>e.id===a.target&&e.hp>0&&(!window.WizardSkills||WizardSkills.canSelect(e)));if(es.length&&s.disrupt){window.CampaignChallenge?.disrupt(a.target,party()[a.i].id);if(window.DwarfSkills?.model.charge?.enemyId===a.target)DwarfSkills.special(party()[a.i].id,now,a.id,a.target);}if(es.length)a.lethal=bridge.damage(a.i,es,s.damage,false,{element:'neutral',skillId:a.id,damageType:['wizard','priest'].includes(party()[a.i].id)?'magic':'physical'}).lethal;}}
 if(m.phase==='complete'){active=null;if(a.lethal)bridge.finish();else PartyTurns.complete(now);}},
 pose(i,now){if(active?.i!==i)return guards.has(i)?{clip:guardClip(party()[i]),time:550}:null;const m=sample(now),s=specs[active.id],a=party()[i];let clip=active.clip,time=m.local;if(m.phase==='advancing'){clip='forward';time=m.phaseTime/1050*total(a.actions.forward);}else if(m.phase==='returning'){clip='return';time=m.phaseTime/480*total(a.actions.return);}else if(m.phase==='turning'){clip='turn';time=m.phaseTime;}else if(m.phase==='facing'){clip=a.actions.face?'face':'turn';time=clip==='face'?m.phaseTime:Math.max(0,total(a.actions.turn)-1-m.phaseTime);}else if(m.phase!=='acting'){clip='idle';time=now;}return {clip,time,x:m.x,y:m.y};},
 incoming(i,n){return guards.has(i)?Math.round(n*.5):n;},end(){guards.clear();},reset(){active=null;guards.clear();potions.clear();supplies.clear();}
 };
})();
