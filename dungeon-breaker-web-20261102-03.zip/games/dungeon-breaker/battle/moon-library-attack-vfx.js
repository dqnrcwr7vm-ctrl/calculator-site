/* Dungeon 05 visual adapter. PartyTurns owns target snapshots, damage and time.
   Uses the approved pure sampler, body PNGs and local VFX; never scene previews. */
(function(root){
'use strict';
const base='../monsters/05-moon-library-attacks-v2/',data=root.MOON_LIBRARY_ATTACK_DATA,D=root.MoonLibraryDelivery,images=new Map(),clips=new Map();
function packs(c){
 const s=c.style,set=new Set();
 if(s.startsWith('paper')){set.add('paper');set.add('ink-dart');}
 else if(['ink','ink-double','double-seal'].includes(s))set.add('ink-dart');
 if(['seal','double-seal'].includes(s))set.add('seal');
 else if(['stone','obsidian'].includes(s)){set.add(s);set.add('contact-rake');}
 else if(s==='chain')set.add('chain-lash');
 else if(s==='roar')set.add('roar-wave');
 else if(s.startsWith('melee')||s==='pounce')set.add('contact-rake');
 return set;
}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='05'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;
 if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]);
 return{a,e,c:a.visual,age,positions,scale};
}
// Run the authored reference sampler in source-pixel space, then map to live world space.
function sampled(v,index){
 const p=v.positions[index],s=v.c.defaultSource,k=v.scale;
 if(!p)return null;
 const target=[s[0]+(p.x-v.e.x)/k,s[1]+(p.y-p.h*.55-v.e.y)/k],ground=[target[0],s[1]+(p.y-v.e.y)/k];
 return D.sample(v.c,v.age,s,target,ground);
}
const world=(v,xy)=>[v.e.x+(xy[0]-v.c.defaultSource[0])*v.scale,v.e.y+(xy[1]-v.c.defaultSource[1])*v.scale];
function actor(v){
 const state=sampled(v,v.a.targets[0]);if(!state)return null;
 const idle=v.age>=v.c.casterDurationMs,c=idle?v.c.actorIdle:v.c.sourceClip,f=D.frameAt(c.durations,idle?v.age-v.c.casterDurationMs:v.age,idle),xy=world(v,state.actor);
 return{x:xy[0],y:xy[1],scale:v.scale,frame:f,anchor:v.c.sourceAnchor,path:base+(idle?c.frames:c.bodyFrames)[f]};
}
function records(v){
 const recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0),out=[];
 for(const i of recipients){const state=sampled(v,i);if(!state)continue;const p=v.positions[i],unit=p.h/160,impact=v.age>=v.c.impactMs,u=Math.max(0,Math.min(1,(v.age-v.c.releaseMs)/(v.c.impactMs-v.c.releaseMs))),fxScale=impact?unit:v.scale+(unit-v.scale)*u;
  for(const q of state.calls){const pack=data.effectPacks[q.pack],xy=world(v,[q.x,q.y]),frame=Math.max(0,Math.min(pack.frames.length-1,q.frame));
   // Recipient-attached offsets and rings follow ally size, independently of the enlarged enemy.
   if(impact){xy[0]=p.x+(xy[0]-p.x)*unit/v.scale;const center=p.y-p.h*.55;xy[1]=center+(xy[1]-center)*unit/v.scale;}
   out.push({...q,frame,x:xy[0],y:xy[1],scale:q.scale*fxScale,target:i,tag:impact?'contact':'travel',anchor:pack.anchors[frame],path:base+pack.frames[frame]});}}
 return out;
}
root.MoonLibraryAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='05')return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set(),effects=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){clips.set(c.monsterId+':'+c.action,{...c,sourceId:c.id,id:'05:'+c.id,adapter:'05',durationMs:c.totalMs});[...c.sourceClip.bodyFrames,...c.actorIdle.frames].forEach(p=>paths.add(base+p));for(const id of packs(c))effects.add(id);}
  for(const id of effects)for(const p of data.effectPacks[id].frames)paths.add(base+p);
  for(const path of paths)images.set(path,await loader(path));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='05'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=a&&images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(!im)continue;const x=q.x-q.anchor[0]*q.scale,y=q.y-q.anchor[1]*q.scale,w=im.width*q.scale,h=im.height*q.scale;g.save();g.globalAlpha*=q.alpha;if(q.split){const splitY=y+128*q.scale;g.beginPath();g.rect(x,q.split==='front'?splitY:y,w,q.split==='front'?h-(splitY-y):splitY-y);g.clip();}g.drawImage(im,x,y,w,h);g.restore();}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
