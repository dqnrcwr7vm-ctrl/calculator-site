/* Approved A: original frames, high-density destination, high-quality interpolation.
 * World coordinates and animation timing remain independent of backing pixels. */
(function(root){
'use strict';
const worlds=new WeakMap();
function width(canvas){return worlds.get(canvas)?.width??canvas.width;}
function height(canvas){return worlds.get(canvas)?.height??canvas.height;}
function quality(ctx,draw){
 const smooth=ctx.imageSmoothingEnabled,quality=ctx.imageSmoothingQuality;
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 try{return draw();}finally{ctx.imageSmoothingEnabled=smooth;ctx.imageSmoothingQuality=quality;}
}
function image(ctx,...args){return quality(ctx,()=>ctx.drawImage(...args));}
function mount(canvas){
 if(worlds.has(canvas))return;
 const world={width:canvas.width,height:canvas.height};worlds.set(canvas,world);
 const ctx=canvas.getContext('2d');canvas.style.imageRendering='auto';
 const drawImage=ctx.drawImage.bind(ctx);ctx.drawImage=(im,...args)=>drawImage(im,...(root.SpiderDetail?.drawArgs(im,args)||args));
 function resize(){
  const ratio=Math.max(2,Math.min(3,Math.ceil((canvas.clientWidth||world.width)*(root.devicePixelRatio||1)/world.width)));
  const w=world.width*ratio,h=world.height*ratio;
  if(canvas.width===w&&canvas.height===h)return;
  canvas.width=w;canvas.height=h;ctx.setTransform(ratio,0,0,ratio,0,0);ctx.imageSmoothingEnabled=false;
  canvas.dataset.rasterScale=String(ratio);canvas.dataset.worldWidth=String(world.width);canvas.dataset.worldHeight=String(world.height);
 }
 resize();new ResizeObserver(resize).observe(canvas);root.addEventListener('resize',resize);
}
root.MonsterRaster={mount,width,height,quality,image};
})(window);
