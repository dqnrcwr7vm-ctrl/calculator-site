/* Dungeon 09 presentation. PartyTurns alone freezes recipients and applies damage,
   HURT, defenses and lifecycle on the shared clock. Approved assets stay read-only. */
(function(root){
'use strict';
const base='../monsters/09-clock-spire-attacks-v2/',data=root.CLOCK_SPIRE_ATTACK_DATA,images=new Map(),clips=new Map();
const clamp=n=>Math.max(0,Math.min(1,n)),mix=(a,b,t)=>a+(b-a)*t,total=d=>d.reduce((a,b)=>a+b,0);
function frameAt(d,t){let i=0;while(i<d.length-1&&t>=d[i])t-=d[i++];return i;}
function context(now,positions,enemies){
 const a=root.PartyTurns?.enemyAction;if(root.PartyTurns?.cycle.phase!=='enemies'||a?.visual?.adapter!=='09'||!a.targets.length)return null;
 const e=enemies.find(e=>e.id===a.id),age=now-a.started;
 if(!e||e.hp<=0||age<0||age>=a.end||root.WizardSkills&&!root.WizardSkills.canEnemyAct(e))return null;
 const c=a.visual,asset=e.spriteAsset||root.BATTLE_ASSETS[4],scale=e.h/(asset.bounds[3]-asset.bounds[1]);
 return{a,e,c,age,positions,scale,ratio:scale/c.actor.scale};
}
function hitPoint(v,i){const p=v.positions[i],unit=p.h/data.targetReferenceHeight;return{x:p.x+(v.c.targetPoint[0]-data.targetFoot[0])*unit,y:p.y+(v.c.targetPoint[1]-data.targetFoot[1])*unit,unit};}
function actor(v){
 const a=v.c.actor,home={x:v.e.x,y:v.e.y},target=v.positions[v.a.targets[0]];
 let x=home.x,y=home.y;
 if(a.mode!=='stationary'&&target){
  const hit=hitPoint(v,v.a.targets[0]),end={x:hit.x+(a.contactPosition[0]-v.c.targetPoint[0])*v.ratio,y:hit.y+(a.contactPosition[1]-v.c.targetPoint[1])*v.ratio};
  for(let i=1;i<a.motion.length;i++)if(v.age<=a.motion[i].ms){
   const q=a.motion[i-1],r=a.motion[i],t=clamp((v.age-q.ms)/(r.ms-q.ms)),u=t*t*(3-2*t);
   const at=k=>k.position[0]===a.origin[0]&&k.position[1]===a.origin[1]?home:end;
   const from=at(q),to=at(r);x=mix(from.x,to.x,u);y=mix(from.y,to.y,u)-(i===2?a.approachArcHeight*v.ratio*Math.sin(Math.PI*u):0);break;
  }
 }
 return{x,y,scale:v.scale,anchor:a.anchor,path:base+(v.age>=total(a.durations)?a.idleFrame:a.frames[frameAt(a.durations,v.age)])};
}
function records(v){
 const recipients=v.a.hit?(v.a.resolvedTargets||[]):v.a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0),out=[],{c,age}=v;
 for(const i of recipients){if(!v.positions[i])continue;const hit=hitPoint(v,i),p=c.projectile;
  if(p&&age>=c.releaseMs&&age<c.impactMs){
   const u=(age-c.releaseMs)/(c.impactMs-c.releaseMs),k=mix(v.ratio,hit.unit,u),from=p.path.from,origin=c.actor.origin;
   out.push({path:base+p.frames[frameAt(p.durations,age-c.releaseMs)],anchor:p.anchor,x:mix(v.e.x+(from[0]-origin[0])*v.ratio,hit.x,u),y:mix(v.e.y+(from[1]-origin[1])*v.ratio,hit.y,u)-p.path.arcHeight*k*4*u*(1-u),scale:k,layer:'front',tag:'travel',target:i});
  }
  const t=age-c.impactMs;
  if(t>=0&&t<total(c.impact.durations))for(const layer of ['back','front'])out.push({path:base+c.impact[layer][frameAt(c.impact.durations,t)],anchor:c.impact.anchor,x:hit.x,y:hit.y,scale:hit.unit,layer,tag:'contact',target:i});
 }return out;
}
root.ClockSpireAttackVFX={
 async load(loader){images.clear();clips.clear();if(root.ActiveDungeon?.id!=='09'||!data)return;
  const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set();
  for(const c of data.clips)if(ids.has(c.monsterId)){
   clips.set(c.id,{...c,sourceId:c.id,id:'09:'+c.id,adapter:'09'});
   [...c.actor.frames,c.actor.idleFrame,...c.impact.back,...c.impact.front,...(c.projectile?.frames||[])].forEach(p=>paths.add(base+p));
  }
  for(const path of paths)images.set(path,await loader(path));
 },
 clipFor(e,plan){if(root.ActiveDungeon?.id!=='09'||e.isBoss||plan.charge||plan.wipe||!['single','all'].includes(plan.target))return null;const c=clips.get((e.spriteAsset||root.BATTLE_ASSETS[4]).id+':'+plan.clip);return c?{...c,target:plan.target}:null;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const a=actor(v),im=images.get(a.path);if(!im)return false;g.drawImage(im,a.x-a.anchor[0]*a.scale,a.y-a.anchor[1]*a.scale,im.width*a.scale,im.height*a.scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;for(const q of records(v)){if(q.layer!==layer)continue;const im=images.get(q.path);if(im)g.drawImage(im,q.x-q.anchor[0]*q.scale,q.y-q.anchor[1]*q.scale,im.width*q.scale,im.height*q.scale);}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);return v?{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:actor(v),effects:records(v)}:null;},
 loaded(){return{clips:[...clips.keys()],images:[...images.keys()]};}
};
})(window);
