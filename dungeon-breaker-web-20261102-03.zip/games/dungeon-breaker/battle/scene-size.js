// Approved battlefield proportions across all dungeons, floors and actor modes.
// Scale runtime drawing only; preserve original PNGs, portraits and animation anchors.
window.BattleSceneSize=Object.freeze({ally:0.75,enemy:1.25,minEnemy:270});
