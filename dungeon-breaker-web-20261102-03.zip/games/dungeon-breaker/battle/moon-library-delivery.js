/* Visual-only, deterministic effect sampler. No HP/status/turn writes. */
(()=>{'use strict';
const clamp=(p,a=0,b=1)=>Math.max(a,Math.min(b,p)),mix=(a,b,p)=>a+(b-a)*p,smooth=p=>{p=clamp(p);return p*p*(3-2*p)};
function frameAt(d,t,loop=false){t=loop?(t%sum(d)+sum(d))%sum(d):clamp(t,0,sum(d)-1);for(let i=0;i<d.length;i++){if(t<d[i])return i;t-=d[i]}return d.length-1}
function sum(a){return a.reduce((s,x)=>s+x,0)}
function sample(e,t,source=e.defaultSource,target=e.defaultTarget,ground=e.defaultTargetGround){
 const [sx,sy]=source,[tx,ty]=target,[gx,gy]=ground,m=e.actorMotion,hit=e.impactMs,release=e.releaseMs,s=e.style;
 let actor=[sx,sy];
 if(m.mode!=='stationary'&&t>=m.approachStartMs){
  const cx=tx-(m.sourceContactPoint[0]-380),cy=ty-(m.sourceContactPoint[1]-340);
  if(t<=hit){const p=clamp((t-m.approachStartMs)/(hit-m.approachStartMs)),u=smooth(p);actor=[mix(sx,cx,u),mix(sy,cy,u)-m.jumpHeight*Math.sin(p*Math.PI)]}
  else if(t<m.returnStartMs)actor=[cx,cy];
  else{const u=smooth((t-m.returnStartMs)/Math.max(1,m.returnEndMs-m.returnStartMs));actor=[mix(cx,sx,u),mix(cy,sy,u)]}
 }
 const calls=[],emit=[sx-75,sy-105],u=clamp((t-release)/(hit-release)),age=t-hit,travel=release<=t&&t<hit;
 const fx=(pack,frame,x,y,scale=1,alpha=1,split=null,layer='front')=>calls.push({pack,frame,x,y,scale,alpha,split,layer});
 if(travel){const x=mix(emit[0],tx,u),y=mix(emit[1],ty,u);
  if(s.startsWith('paper')){const count=e.kind==='SPECIAL'?3:s==='paper-double'?2:1;for(let n=0;n<count;n++)fx('paper',Math.floor(u*8)%4,x,y+(n-(count-1)/2)*35*Math.sin(Math.PI*u),.85)}
  else if(['ink','ink-double','double-seal'].includes(s)){const count=s==='ink'?1:2;for(let n=0;n<count;n++)fx('ink-dart',Math.min(7,Math.floor(u*8)),x,y+(n-(count-1)/2)*60*Math.sin(Math.PI*u),.7)}
  else if(s==='seal')fx('seal',Math.min(8,1+Math.floor(u*8)),x,y,.75);
  else if(['stone','obsidian'].includes(s)){for(let n=0;n<3;n++){const p=clamp(u-n*.09);fx(s,2,mix(sx-60,gx,p),mix(sy-10,gy-15,p),.32+.12*p,1,null,'back')}}
  else if(s==='chain')fx('chain-lash',Math.floor(u*4)%4,x,y,.9);
  else if(s==='roar')fx('roar-wave',Math.min(3,Math.floor(u*4)),x,y,.6+.35*u);
 }
 if(age>=0&&age<420){const p=age/420,fade=p<.8?1:(1-p)/.2;
  if(['ink','ink-double','double-seal'].includes(s)||s.startsWith('paper'))fx('ink-dart',8+Math.min(3,Math.floor(p*4)),tx,ty,.7,fade);
  if(['seal','double-seal'].includes(s)){for(let n=0;n<(s==='double-seal'?2:1);n++)fx('seal',Math.min(17,9+Math.floor(p*9)),s==='double-seal'?tx+(n-.5)*30:tx,ty,.8,fade)}
  else if(['stone','obsidian'].includes(s)){for(const side of ['back','front'])fx(s,p<.6?2:3,tx,ty,.8+p*.45,fade,side,side);fx('contact-rake',p<.5?4:Math.min(11,8+Math.floor(p*4)),tx,ty,.48,fade)}
  else if(s==='chain')for(const side of ['back','front'])fx('chain-lash',4+Math.min(7,Math.floor(p*8)),tx,ty,.95,fade,side,side);
  else if(s==='roar')fx('roar-wave',4+Math.min(7,Math.floor(p*8)),tx,ty,1,fade);
  else if(s.startsWith('melee')||s==='pounce'){
   const idx=s==='melee-stab'?[0,4,4,8,9,10,11][Math.min(6,Math.floor(p*7))]:Math.min(11,Math.floor(p*12));
   fx('contact-rake',idx,tx,ty,['pounce','melee-axe'].includes(s)?1.15:.85,fade);
   if(s==='melee-double')fx('contact-rake',Math.min(11,idx+2),tx+24,ty-20,.7,fade);
  }
 }
 return {actor,calls,phase:t<release?'telegraph':t<hit?'travel':t<hit+420?'impact':'recovery',impactMs:hit,sourceClipFrame:frameAt(e.sourceClip.durations,t)};
}
function draw(ctx,state,layer,packs,images){
 for(const q of state.calls){if(q.layer!==layer)continue;const p=packs[q.pack],i=clamp(q.frame,0,p.frames.length-1),im=images(p.frames[i]);if(!im||!im.complete||!im.naturalWidth)continue;
  const anchor=p.anchors[i],x=Math.round(q.x-anchor[0]*q.scale),y=Math.round(q.y-anchor[1]*q.scale),w=Math.round(p.canvas[0]*q.scale),h=Math.round(p.canvas[1]*q.scale);
  ctx.save();ctx.globalAlpha=q.alpha;
  if(q.split){const splitY=y+128*q.scale;ctx.beginPath();ctx.rect(x,q.split==='front'?splitY:y,w,q.split==='front'?h-(splitY-y):splitY-y);ctx.clip()}
  ctx.drawImage(im,x,y,w,h);ctx.restore();
 }
}
window.MoonLibraryDelivery={sample,draw,frameAt,sum};
})();

