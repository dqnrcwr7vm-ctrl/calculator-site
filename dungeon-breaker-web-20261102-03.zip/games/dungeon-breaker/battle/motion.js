// Shared choreography clock; original sprite canvases retain their registration.
window.BattleMotion=(()=>{
 const home={x:685,y:657},center={x:850,y:545},travel=1050,settle=120,retreat=480;
 // Ranged attackers and casters perform their actions from their formation slot.
 const stationaryActors=new Set(['archer','wizard','priest']);
 const ease=t=>t*t*(3-2*t),lerp=(a,b,t)=>a+(b-a)*ease(t);
 function isStationary(kind,actorId){return kind==='item'||kind==='magic'||stationaryActors.has(actorId)||(actorId==='mechanic'&&!['attack','install'].includes(kind));}
 function sample(kind,time,duration,actorId,origin=home){
  if(actorId==='mechanic'&&!isStationary(kind,actorId)){
   const advance=travel,start=advance+settle,end=start+duration,total=end+280+retreat+380;
   let x=origin.x,y=origin.y,phase='complete',phaseTime=0;
   if(time<advance){phase='advancing';phaseTime=Math.max(0,time);x=lerp(origin.x,center.x,phaseTime/advance);y=lerp(origin.y,center.y,phaseTime/advance);}
   else if(time<start){phase='settling';x=center.x;y=center.y;}
   else if(time<end){phase='acting';phaseTime=time-start;x=center.x;y=center.y;}
   else if(time<total){
    phaseTime=time-end;
    // Frames 1–2 pivot at center; 3–6 walk home; 7–8 face the enemy at home.
    if(phaseTime<280){phase='turning';x=center.x;y=center.y;}
    else if(phaseTime<280+retreat){phase='returning';const t=(phaseTime-280)/retreat;x=lerp(center.x,origin.x,t);y=lerp(center.y,origin.y,t);}
    else phase='facing';
   }
   return{x,y,phase,phaseTime,local:Math.max(0,time-start),start,end,total,stationary:false};
  }
  if(['dwarf','hero'].includes(actorId)&&!isStationary(kind,actorId)){
   const advance=travel,turn=actorId==='hero'?360:540,walkBack=retreat,start=advance+settle,end=start+duration;
   const returnStart=end+turn,faceStart=returnStart+walkBack,total=faceStart+(actorId==='hero'?270:turn);
   let x=origin.x,y=origin.y,phase='complete',phaseTime=0;
   if(time<advance){phase='advancing';phaseTime=Math.max(0,time);const t=phaseTime/advance;x=lerp(origin.x,center.x,t);y=lerp(origin.y,center.y,t);}
   else if(time<start){phase='settling';x=center.x;y=center.y;}
   else if(time<end){phase='acting';phaseTime=time-start;x=center.x;y=center.y;}
   else if(time<returnStart){phase='turning';phaseTime=time-end;x=center.x;y=center.y;}
   else if(time<faceStart){phase='returning';phaseTime=time-returnStart;const t=phaseTime/walkBack;x=lerp(center.x,origin.x,t);y=lerp(center.y,origin.y,t);}
   else if(time<total){phase='facing';phaseTime=time-faceStart;}
   return{x,y,phase,phaseTime,local:Math.max(0,time-start),start,end,total,stationary:false};
  }
  const stationary=isStationary(kind,actorId),start=stationary?0:travel+settle,end=start+duration,total=end+(stationary?160:retreat);
  let x=origin.x,y=origin.y,phase='acting',local=Math.max(0,time-start);
  if(!stationary){
   if(time<travel){phase='advancing';let t=Math.max(0,time)/travel;x=lerp(origin.x,center.x,t);y=lerp(origin.y,center.y,t);}
   else if(time<start){phase='settling';x=center.x;y=center.y;}
   else if(time<end){x=center.x;y=center.y;}
   else if(time<total){phase='returning';let t=(time-end)/retreat;x=lerp(center.x,origin.x,t);y=lerp(center.y,origin.y,t);}
  }
  if(time>=total)phase='complete';
  return{x,y,phase,local,start,end,total,stationary};
 }
 return{home,center,travel,settle,retreat,isStationary,sample};
})();
