/* Solar Furnace normal/elite attack presentation. Damage stays in PartyTurns. */
(function(root){
'use strict';
const clamp=n=>Math.max(0,Math.min(1,n)),lerp=(a,b,t)=>a+(b-a)*t;
function frameAt(c,age){let i=0;while(i<c.frameTimes.length-1&&age>=c.frameTimes[i+1])i++;return i;}
function geometry(c,age,enemy,target,ratio){
 const f=frameAt(c,age),a=c.motion[f],b=c.motion[Math.min(f+1,c.motion.length-1)],q=b.timeMs>a.timeMs?clamp((age-a.timeMs)/(b.timeMs-a.timeMs)):0;
 const x=lerp(a.actorAnchor[0],b.actorAnchor[0],q),home=c.actorFormationAnchor[0],contact=c.motion[frameAt(c,c.releaseMs)].actorAnchor[0];
 const progress=c.action==='attack'&&home!==contact&&Math.abs(home-x)>.02?clamp((home-x)/(home-contact)):0;
 return {frame:a.sourceFrame,x:lerp(enemy.x,target.x+(contact-320)*ratio,progress),y:lerp(enemy.y,target.y,progress),progress};
}
function retarget(r,c,fixture,enemy,target,ratio){
 const home=c.actorFormationAnchor,original=fixture.position,unit=target.h/fixture.height;
 if(r.attachment==='caster')return{x:enemy.x+(r.position[0]-home[0])*ratio,y:enemy.y+(r.position[1]-home[1])*ratio};
 if(r.attachment==='target')return{x:target.x+(r.position[0]-original[0])*unit,y:target.y+(r.position[1]-original[1])*unit};
 const ground=['rupture','ring'].includes(r.primitive),q=r.progress;
 const src=[home[0]-110,ground?445:325],dst=[original[0],original[1]-(ground?0:55)];
 const start=[enemy.x-110*ratio,enemy.y-(ground?0:120)*ratio],end=[target.x,target.y-(ground?0:55*unit)];
 return{x:lerp(start[0],end[0],q)+(r.position[0]-lerp(src[0],dst[0],q))*ratio,y:lerp(start[1],end[1],q)+(r.position[1]-lerp(src[1],dst[1],q))*ratio};
}
const helpers={frameAt,geometry,retarget};if(typeof module==='object'&&module.exports)module.exports=helpers;
if(!root.document)return;
const data=root.SOLAR_ATTACK_DATA,images=new Map();let loaded=false,loadedClips=[];
const enabled=()=>!!data&&root.ActiveDungeon?.id===data.dungeonId;
function clipFor(e,plan){return enabled()&&!e.isBoss&&!plan.charge&&!plan.wipe?Object.values(data.clips).find(c=>c.monsterId===(e.spriteAsset||root.BATTLE_ASSETS[4]).id&&c.action===plan.clip&&c.target===plan.target)||null:null;}
function targetsFor(a){return a.hit?(a.resolvedTargets||[]):a.targets.filter(i=>(root.BATTLE_ASSETS[i].currentHp??root.BATTLE_ASSETS[i].hp)>0);}
function recordsFor(v){const targets=targetsFor(v.a);return v.c.drawFrames[frameAt(v.c,v.age)].filter(r=>targets.includes(v.a.targets[v.c.target==='all'?r.fixture:0]));}
function action(){const a=root.PartyTurns?.enemyAction;return root.PartyTurns?.cycle.phase==='enemies'&&a?.visual&&a.targets.length?a:null;}
function context(now,positions,enemies){const a=action();if(!a||!loaded)return null;const e=enemies.find(e=>e.id===a.id);if(!e||e.hp<=0||(root.WizardSkills&&!root.WizardSkills.canEnemyAct(e)))return null;const age=now-a.started;if(age<0||age>=a.end)return null;const c=a.visual,asset=e.spriteAsset||root.BATTLE_ASSETS[4],ratio=e.h/(asset.bounds[3]-asset.bounds[1])/c.actorScale;return{a,e,c,age,ratio,positions};}
root.SolarAttackVFX={...helpers,clipFor,
 async load(loader){if(!enabled())return;images.clear();loaded=false;loadedClips=[];const ids=new Set([root.BATTLE_ASSETS[4].id,...(root.BATTLE_CONFIG.enemyFormation||[]).map(e=>e.spriteAsset?.id)]),paths=new Set(),primitives=new Set();for(const c of Object.values(data.clips))if(ids.has(c.monsterId)){loadedClips.push(c.monsterId+':'+c.action);c.actorFrames.forEach(p=>paths.add(p));c.drawFrames.flat().forEach(r=>primitives.add(r.primitive));}if(!paths.size)return;for(const id of primitives)data.primitives[id].frames.forEach(f=>paths.add(f));for(const p of paths)images.set(p,await loader(p));loaded=true;},
 drawActor(g,id,p,now,pose,enemies,positions){const v=context(now,positions,enemies);if(!v||v.a.id!==id||pose!==v.c.action)return false;const target=positions[v.a.targets[0]];if(!target)return false;const at=geometry(v.c,v.age,v.e,target,v.ratio),im=images.get(v.c.actorFrames[at.frame]),scale=v.c.actorScale*v.ratio;g.drawImage(im,at.x-v.c.actorAnchor[0]*scale,at.y-v.c.actorAnchor[1]*scale,im.width*scale,im.height*scale);return true;},
 draw(g,layer,now,positions,enemies){const v=context(now,positions,enemies);if(!v)return;const records=recordsFor(v);for(const r of records){if((r.layer==='back'?'back':'front')!==layer)continue;const i=v.a.targets[v.c.target==='all'?r.fixture:0],target=positions[i];if(!target)continue;const point=retarget(r,v.c,data.party[r.fixture],v.e,target,v.ratio),fx=data.primitives[r.primitive],im=images.get(fx.frames[r.pose-1]),scale=r.scale*v.ratio;g.drawImage(im,point.x-fx.anchor[0]*scale,point.y-fx.anchor[1]*scale,im.width*scale,im.height*scale);}},
 snapshot(now,positions,enemies){const v=context(now,positions,enemies);if(!v)return null;return{enemyId:v.a.id,clipId:v.c.id,age:v.age,releaseMs:v.c.releaseMs,impactMs:v.a.impact,targets:[...v.a.targets],actor:{...geometry(v.c,v.age,v.e,positions[v.a.targets[0]],v.ratio),path:v.c.actorFrames[geometry(v.c,v.age,v.e,positions[v.a.targets[0]],v.ratio).frame]},effects:recordsFor(v).filter(r=>positions[v.a.targets[v.c.target==='all'?r.fixture:0]]).map(r=>({...retarget(r,v.c,data.party[r.fixture],v.e,positions[v.a.targets[v.c.target==='all'?r.fixture:0]],v.ratio),layer:r.layer,tag:r.tag,target:v.a.targets[v.c.target==='all'?r.fixture:0]}))};},
 loaded(){return {clips:[...loadedClips],images:[...images.keys()]};}
};
// Dungeon adapters share one receiving/timing pipeline.
const adapter=()=>root.ActiveDungeon?.id==='01'?root.GalleonAttackVFX:root.ActiveDungeon?.id==='02'?root.ThornCrownAttackVFX:root.ActiveDungeon?.id==='03'?root.FrostPrisonAttackVFX:root.ActiveDungeon?.id==='05'?root.MoonLibraryAttackVFX:root.ActiveDungeon?.id==='06'?root.SandTombAttackVFX:root.ActiveDungeon?.id==='07'?root.StormCitadelAttackVFX:root.ActiveDungeon?.id==='08'?root.SporeAbyssAttackVFX:root.ActiveDungeon?.id==='09'?root.ClockSpireAttackVFX:root.ActiveDungeon?.id==='10'?root.PalePilgrimageAttackVFX:root.SolarAttackVFX;
const targetPositions=p=>root.DungeonCombatRules?.targetPositions(p,root.PartyTurns?.enemyAction)||p;
const quality=(g,fn)=>root.MonsterRaster?root.MonsterRaster.quality(g,fn):fn();
root.MonsterAttackVFX={...helpers,
 clipFor:(...a)=>root.BossAttackVFX?.clipFor(...a)||adapter()?.clipFor(...a),
 load:(...a)=>Promise.all([root.BossAttackVFX?.load(...a),adapter()?.load(...a),root.MonsterBasicAttackVFX?.load(...a)]),
 drawActor(g,id,p,now,pose,enemies,positions){
  if(root.PartyTurns?.enemyAction?.visual?.adapter==='boss')return false;
  const recipients=targetPositions(positions);
  return quality(g,()=>adapter()?.drawActor(g,id,p,now,pose,enemies,recipients)||root.MonsterBasicAttackVFX?.drawActor(g,id,p,now,pose,enemies,recipients)||false);
 },
 draw(g,layer,now,positions,enemies){
  const recipients=targetPositions(positions);
  quality(g,()=>{(root.PartyTurns?.enemyAction?.visual?.adapter==='boss'?root.BossAttackVFX:adapter())?.draw(g,layer,now,recipients,enemies);root.MonsterBasicAttackVFX?.draw(g,layer,now,recipients,enemies);});
 },
 snapshot(now,positions,enemies){
  const recipients=targetPositions(positions),base=(root.PartyTurns?.enemyAction?.visual?.adapter==='boss'?root.BossAttackVFX:adapter())?.snapshot(now,recipients,enemies),basic=root.MonsterBasicAttackVFX?.snapshot(now,recipients,enemies);
  return base?{...base,effects:[...base.effects,...(basic?.effects||[])]}:basic||null;
 }
};
})(typeof window!=='undefined'?window:globalThis);
