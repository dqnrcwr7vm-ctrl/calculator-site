/* Apply authored player damage; resource-cost mechanics remain owned by each class. */
(()=>{if(!window.PlayerBalance)return;const data=MONSTER_BALANCE_DATA;
const groups={dwarf:DwarfSkills.skills,archer:window.ArcherSkills?.specs,wizard:window.WizardSkills?.specs,priest:window.HealerSkills?.specs,hero:window.PartyHero?.specs,mechanic:window.PartyMechanic?.specs};
for(const [id,r]of Object.entries(data.robots||{})){const unit=window.PartyMechanicData?.robots[id];if(unit)Object.assign(unit,{damage:r.damage,maxHp:r.hp,reduction:r.reduction});}
for(const [role,source]of Object.entries(groups)){if(!source)continue;for(const [id,s]of Array.isArray(source)?source.map(s=>[s.id,s]):Object.entries(source)){const p=data.players[role+':'+id];if(!p)continue;s.name=p.name;if(p.damage!=null)s.damage=p.damage;s.description=p.description;s.element=MonsterBalance.normalize(p.element);}}
for(const [id,s]of Object.entries(PartyBasicActions.specs)){if(id.endsWith('-attack')){const role=id.split('-')[0];s.damage=data.characters[role].attack;s.description='무속성 일반 공격으로 적 하나에게 '+s.damage+' 피해. MP 소모 없음.';}}
if(window.PartyResources?.enabled){for(const [role,source]of Object.entries(groups)){if(!source)continue;for(const [id,s]of Array.isArray(source)?source.map(s=>[s.id,s]):Object.entries(source))s.cost=PartyResources.cost(role,id);}for(const [id,r]of Object.entries(PartyResources.ROBOTS)){const unit=window.PartyMechanicData?.robots[id];if(unit)Object.assign(unit,{maxHp:r.hp,reduction:r.reduction});}}
})();
