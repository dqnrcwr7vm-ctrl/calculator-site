/* Normal expeditions: sustained pressure and a visible two-ally boss ward.
 * Workbook values remain the editable base; standalone skill sandboxes are unchanged. */
(function(root){
'use strict';
const THEMES={
 '01':{name:'침몰한 범선 · 포박과 강타',type:'physical',power:1.3,period:3,hint:'강타 턴에는 견제로 화력을 낮추고 포박을 해제하세요.'},
 '02':{name:'가시왕관 수목탑 · 독과 가시',type:'physical',power:1.05,period:3,status:'poison',hint:'독 공격을 견제로 억제하고 해독과 회복 시점을 나누세요.'},
 '03':{name:'서리심장 감옥 · 물리 철벽',type:'physical',power:1.1,armor:'physical',period:3,hint:'물리 피해 감소. 같은 적을 두 명이 견제하면 이번 턴 방어가 무너집니다.'},
 '04':{name:'몰락한 태양 용광로 · 물리 폭공',type:'physical',power:1.65,period:2,hint:'격턴 강타 후 다음 턴에는 받는 피해가 증가합니다. 방어 후 반격하세요.'},
 '05':{name:'월식의 서고 · 원거리 마법',type:'magic',power:1.35,period:3,area:true,hint:'세 번째 턴마다 광역 마법. 견제와 보호막을 분담하세요.'},
 '06':{name:'유리사막 왕릉 · 장갑과 강타',type:'physical',power:1.3,armor:'physical',period:4,hint:'두 명의 견제로 장갑을 깨거나 마법으로 우회하세요.'},
 '07':{name:'폭풍쇄 성채 · 연쇄 마법',type:'magic',power:1.25,period:2,area:true,hint:'격턴 광역 마법. 한 적을 먼저 쓰러뜨려 동시 공격을 줄이세요.'},
 '08':{name:'포자빛 심연 · 독성 포격',type:'magic',power:1.05,period:3,status:'poison',area:true,hint:'독 포격이 겹칩니다. 견제 두 번으로 독 부여를 차단할 수 있습니다.'},
 '09':{name:'멈춰버린 시계첨탑 · 장갑 과부하',type:'physical',power:1.4,armor:'physical',period:3,hint:'장갑을 견제로 깨고 과부하 다음 턴의 빈틈을 공략하세요.'},
 '10':{name:'백야의 순례계단 · 마법 방벽',type:'magic',power:1.25,armor:'magic',period:3,area:true,hint:'마법 방어가 높습니다. 물리 공격 또는 두 명의 견제로 대응하세요.'}
};
const BALANCE=Object.freeze({normalHp:1.5,strongHp:1.7,midbossHp:1.3*.65,secondMidbossHp:1.2,midbossDamage:1.1,secondMidbossDamage:1.15,finalHp:1.5,normalAttack:1.25,bossAttack:1.25,wardDamage:.35});
class Challenge{
 constructor(enabled=false,dungeon='01'){this.enabled=enabled;this.theme=THEMES[dungeon]||THEMES['01'];this.reset();}
 reset(){this.broken=new Set();this.pressure=0;this.turn=1;this.disruptions=new Map();this.lastBreak=null;}
 beginRound(turn){this.turn=turn;this.disruptions.clear();}
 disrupt(id,actor){if(!this.enabled)return;const set=this.disruptions.get(id)||new Set();set.add(actor);this.disruptions.set(id,set);}
 count(id){return this.disruptions.get(id)?.size||0;}
 failed(){if(this.enabled)this.pressure=Math.min(4,this.pressure+1);}
 stats(m,floor,firstMidboss){
  if(!this.enabled)return m;
  if(m.affixCount===1&&floor===8&&firstMidboss)return {...m,hp:Math.round(firstMidboss.hp*BALANCE.midbossHp*BALANCE.secondMidbossHp)};
  const boss=m.affixCount>0,multiplier=boss?(floor===9?BALANCE.finalHp:BALANCE.midbossHp):floor>=5?BALANCE.strongHp:BALANCE.normalHp;
  return {...m,hp:Math.round(m.hp*multiplier)};
 }
 sync(model){const b=model?.interruptedCharge;if(this.enabled&&b?.allies?.length>=2){this.broken.add(b.enemyId);const key=b.enemyId+':'+b.turn;if(this.lastBreak!==key){this.pressure=Math.max(0,this.pressure-1);this.lastBreak=key;}}}
 warded(id,boss){return this.enabled&&boss&&!this.broken.has(id);}
 incoming(e,n,boss,model,hit={}){this.sync(model);if(!this.enabled)return n;let amount=n;if(this.theme.armor&&this.theme.armor===hit.damageType&&this.count(e.id)<2)amount*=.55;if(this.turn>1&&(this.turn-1)%this.theme.period===0)amount*=1.3;return this.warded(e.id,boss)?Math.min(Math.max(0,e.hp-1),Math.round(amount*BALANCE.wardDamage)):Math.round(amount);}
 outgoing(n,boss,id){return this.enabled?Math.round(n*(boss?BALANCE.bossAttack:BALANCE.normalAttack)*(1+this.pressure*.2)*(this.count(id)>=2?.6:this.count(id)===1?.8:1)):n;}
 plan(p,finalBoss,midboss){
  if(!this.enabled)return p;
  const t=this.theme,burst=this.turn%t.period===0,charge=!!p.charge;if(p.target==='self'&&!charge)return p;
  let damage=Math.max(p.damage||0,charge||p.wipe?320:0);
  if(midboss&&!finalBoss){
   if(midboss.floor===8&&Number.isFinite(midboss.referenceDamage))damage=Math.max(midboss.referenceDamage,charge?320:0)*BALANCE.secondMidbossDamage;
   damage*=BALANCE.midbossDamage;
  }
  return {...p,wipe:false,charge,damage:Math.round(damage*t.power*(burst?1.35:1)),damageType:t.type,target:charge||burst&&t.area?'all':p.target,status:burst&&t.status?t.status:p.status,name:p.name.replace(/ · 전멸기| · 파훼 실패 시 전멸/g,'')+(burst?' · 강공세':'')};
 }
}
const api={BALANCE,THEMES,Challenge};if(typeof module==='object'&&module.exports)module.exports=api;
if(!root.document)return;
const enabled=new URLSearchParams(location.search).get('campaign')==='1';
root.CampaignChallenge=new Challenge(enabled,new URLSearchParams(location.search).get('dungeon')||'01');
root.CampaignChallenge.update=function(){
 this.sync(root.DwarfSkills?.model);
 document.querySelector('#dungeon-tactics')?.remove();
};
})(typeof window!=='undefined'?window:globalThis);
