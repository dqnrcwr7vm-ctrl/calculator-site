/* Audio-only attack identity. Never modifies damage, elements or cast timing. */
(function(root){
  'use strict';
  const cue=(id,level=1)=>({id:'impact-'+id,level});
  const profiles={
    sword:{physical:true,layers:[cue('slash')]},
    hammer:{physical:true,layers:[cue('blunt')]},
    swordBack:{physical:true,layers:[cue('blunt',.9),cue('metal',.22)]},
    shield:{physical:true,layers:[cue('blunt',.95),cue('metal',.38)]},
    spanner:{physical:true,layers:[cue('metal',.9),cue('blunt',.45)]},
    arrow:{physical:true,layers:[cue('pierce')]},
    volley:{physical:true,layers:[cue('pierce',1.08),cue('slash',.28)]},
    snipe:{physical:true,layers:[cue('pierce',1.12),cue('blunt',.35)]},
    stunArrow:{physical:true,layers:[cue('pierce'),cue('lightning',.55)]},
    phoenix:{physical:true,layers:[cue('pierce',.95),cue('fire',.65)]},
    nature:{physical:false,layers:[cue('nature')]},
    bind:{physical:false,layers:[cue('nature',.65)]},
    fire:{physical:false,layers:[cue('fire')]},
    ice:{physical:false,layers:[cue('ice')]},
    iceSpear:{physical:false,layers:[cue('ice'),cue('pierce',.4)]},
    lightning:{physical:false,layers:[cue('lightning')]},
    arcane:{physical:false,layers:[cue('arcane')]},
    holy:{physical:false,layers:[cue('holy')]},
    sanctuary:{physical:false,layers:[cue('holy',.65)]},
    water:{physical:false,layers:[cue('water')]},
    meteor:{physical:false,layers:[cue('explosion'),cue('fire',.5)]},
    blizzard:{physical:false,layers:[cue('ice',1.08)]},
    storm:{physical:false,layers:[cue('lightning'),cue('quake',.24)]},
    blackHole:{physical:false,layers:[cue('arcane'),cue('quake',.45)]},
    quake:{physical:true,layers:[cue('quake')]},
    princess:{physical:true,layers:[cue('quake'),cue('holy',.26)]},
    mjolnir:{physical:true,layers:[cue('blunt'),cue('lightning',.65)]},
    bullet:{physical:true,layers:[cue('bullet')]},
    rivet:{physical:true,layers:[cue('bullet'),cue('fire',.36)]},
    drill:{physical:true,layers:[cue('drill')]},
    beam:{physical:false,layers:[cue('beam')]},
    explosion:{physical:false,layers:[cue('explosion')]},
    metal:{physical:true,layers:[cue('metal')]}
  };
  for(const [id,element]of Object.entries({fireSword:'fire',iceSword:'ice',lightningSword:'lightning',leafSword:'nature',darkSword:'arcane'}))profiles[id]={physical:true,layers:[cue('slash'),cue(element,.6)]};
  const skills={
    hero:{attack:'sword','sword-back':'swordBack','princess-im-coming':'princess','fire-slash':'fireSword','frost-slash':'iceSword','lightning-slash':'lightningSword','leaf-slash':'leafSword','dark-slash':'darkSword'},
    dwarf:{'dwarf-attack':'hammer','dwarf-bash':'shield','dwarf-wake':'hammer','dwarf-quake':'quake','dwarf-mjolnir':'mjolnir'},
    archer:{'archer-attack':'arrow','arrow-rain':'volley','leaf-wind':'nature','leg-bind':'bind','stun-shot':'stunArrow',sniping:'snipe','phoenix-shot':'phoenix'},
    wizard:{fireball:'fire','ice-spear':'iceSpear','thunder-ball':'lightning',void:'arcane',meteor:'meteor',blizzard:'blizzard',thunderstorm:'storm','black-hole':'blackHole'},
    priest:{'holy-light':'holy',sanctuary:'sanctuary'},
    mechanic:{'mechanic-attack':'spanner','mine-explosion':'explosion','combined-gun':'bullet','combined-drill':'drill','combined-fire':'beam','robot-rivet-attack':'rivet','robot-mole-attack':'drill','robot-explosion':'explosion'}
  };
  const basic={hero:'sword',dwarf:'hammer',archer:'arrow',wizard:'arcane',priest:'holy',mechanic:'spanner'};
  const elements={fire:'fire',ice:'ice',lightning:'lightning',light:'holy',water:'water',poison:'water',grass:'nature',wind:'nature',dark:'arcane'};
  function profileFor(hit={},role='',family=''){
    const id=hit.audioSkillId||hit.skillId||'attack';
    // Unique IDs identify delayed impacts even after the acting slot has ended.
    const owner=Object.keys(skills).find(r=>id!=='attack'&&(skills[r][id]||id.startsWith(r+'-')));
    role=hit.role||owner||role;
    let key=skills[role]?.[id];
    if(!key&&hit.damageType==='magic'&&!/^(attack|.*-(attack|common-strike|common-check))$/.test(id))key=elements[hit.element]||'arcane';
    if(!key&&basic[role])key=basic[role];
    if(!key&&hit.damageType==='magic')key=elements[hit.element]||'arcane';
    if(!key)key=family==='construct'?'metal':family==='avian'?'arrow':['beast','insect','undead'].includes(family)?'sword':'hammer';
    const p=profiles[key],scale=hit.dot ? .45 : /common-check$/.test(id) ? .7 : 1;
    return {key,role,skillId:id,physical:p.physical,layers:p.layers.map(c=>({...c,level:c.level*scale}))};
  }
  const api={profiles,skills,basic,profileFor,impactFor:(...args)=>profileFor(...args).layers[0].id};
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.DungeonImpactProfiles=api;
})(typeof window!=='undefined'?window:globalThis);
