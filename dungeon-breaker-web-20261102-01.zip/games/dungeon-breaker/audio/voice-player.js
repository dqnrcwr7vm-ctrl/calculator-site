/* User-approved v6 performances. Speech is scene-local; music/UI keep their own channels. */
(() => {
  'use strict';
  const root = window, catalog = root.DungeonVoiceCatalog || {};
  const base = new URL('voices-approved-v1/', document.currentScript.src);
  const key = 'dungeon-breaker-voice-audio';
  const spellLines = {
    hero: {'princess-im-coming':9,'sword-back':4,magic:10,'hero-roar':7,'fire-slash':8,'frost-slash':8,'lightning-slash':8,'leaf-slash':8,'dark-slash':8},
    dwarf: {'dwarf-taunt':2,'dwarf-bulwark':7,'dwarf-bash':4,'dwarf-wake':8,'dwarf-quake':9,'dwarf-mjolnir':10},
    archer: {'arrow-rain':4,'leaf-wind':7,'leg-bind':8,'stun-shot':9,sniping:10,'sniping-charge':2,'phoenix-shot':10,'natures-cure':7,'eagle-eye':2},
    wizard: {fireball:7,blizzard:8,meteor:9,'black-hole':10,'ice-spear':3,'thunder-ball':3,void:3,thunderstorm:4},
    mechanic: {'mine-explosion':7,'super-combine':9,'combined-beam':4,'combined-fire':6,'combined-gun':3,'combined-drill':6},
    priest: {'living-water':13,recovery:7,healing:7,blessing:8,barrier:9,resurrection:10,'holy-light':3,sanctuary:6}
  };
  const guarding = {hero:7,dwarf:7,archer:6,wizard:6,mechanic:10,priest:4};
  function lineFor(role, id) {
    if (spellLines[role]?.[id]) return spellLines[role][id];
    if (/^install-/.test(id)) return 8;
    if (/guard|brace|bulwark/.test(id)) return guarding[role] || 6;
    if (/item|potion|supply|^reward-/.test(id)) return 6;
    return 3; // Generic exertion; never call an unrelated spell's name.
  }
  let settings = {muted:false,volume:.9}, context, gain, epoch=0, paused=false;
  let seen = new WeakSet(), selectionKey=null, lastSelection=-Infinity, selectionCount={};
  const buffers=new Map(), loading=new Map(), channels=new Map(), tickets=new Map(), pendingChannels=new Set(), hurtAt=new Map();
  function readSettings() {
    try {const s=JSON.parse(localStorage.getItem(key)||'{}');settings.muted=!!s.muted;if(Number.isFinite(s.volume))settings.volume=Math.max(0,Math.min(1,s.volume));} catch {}
    if(gain)gain.gain.value=settings.muted?0:settings.volume;
  }
  readSettings();
  function unlock() {
    if(!context){const AC=root.AudioContext||root.webkitAudioContext;if(!AC)return;context=new AC();gain=context.createGain();gain.gain.value=settings.muted?0:settings.volume;gain.connect(context.destination);}
    if(context.state==='suspended')return context.resume().catch(()=>{});
    return Promise.resolve();
  }
  const extraCues={priest:{13:{text:'핫!',file:'../healer-living-water-v1/priest-exertion.wav',duration_seconds:.47}}};
  function cue(role,line){return extraCues[role]?.[line]||catalog[role]?.cues?.[line-1];}
  function load(role,line) {
    const c=cue(role,line),id=role+':'+line;if(!c||!context)return Promise.resolve(null);
    if(buffers.has(id))return Promise.resolve(buffers.get(id));
    if(!loading.has(id))loading.set(id,fetch(new URL(c.file,base)).then(r=>{if(!r.ok)throw Error(r.status);return r.arrayBuffer();}).then(b=>context.decodeAudioData(b)).then(b=>{buffers.set(id,b);document.documentElement.dataset.voiceLoadedCount=String(buffers.size);return b;}).catch(()=>null).finally(()=>loading.delete(id)));
    return loading.get(id);
  }
  function stopChannel(name) {
    tickets.set(name,(tickets.get(name)||0)+1);
    const a=channels.get(name);if(a?.source){a.source.onended=null;try{a.source.stop();}catch{}}
    channels.delete(name);
    pendingChannels.delete(name);
  }
  function startBuffer(name,a) {
    if(a.offset>=a.buffer.duration){channels.delete(name);return;}
    const source=context.createBufferSource();source.buffer=a.buffer;source.connect(gain);
    a.source=source;a.at=context.currentTime;channels.set(name,a);
    source.onended=()=>{if(channels.get(name)?.source===source)channels.delete(name);};
    source.start(0,a.offset);
  }
  function emit(detail) {
    const d=document.documentElement.dataset;
    d.voiceRole=detail.role;d.voiceLine=String(detail.line);d.voiceKind=detail.kind;
    d.voiceCount=String(+(d.voiceCount||0)+1);
    d.voiceHistory=JSON.stringify([detail,...JSON.parse(d.voiceHistory||'[]')].slice(0,24));
    root.dispatchEvent(new CustomEvent('charactervoiceplayed',{detail}));
  }
  async function play(role,line,kind='action',options={}) {
    const c=cue(role,line);if(!c||settings.muted||!settings.volume||document.hidden||paused&&!options.menu)return false;
    const resumed=unlock();if(!context)return false;
    const name=options.channel||'speech';
    // Turn acknowledgements never cut off the preceding actor's line.
    if(kind==='selection'&&!options.menu&&channels.has(name))return false;
    stopChannel(name);const ticket=tickets.get(name),revision=epoch,requested=performance.now();
    pendingChannels.add(name);
    await resumed;
    if(context.state!=='running'){if(ticket===tickets.get(name))pendingChannels.delete(name);return false;}
    const buffer=await load(role,line);
    if(ticket===tickets.get(name))pendingChannels.delete(name);
    if(!buffer||ticket!==tickets.get(name)||revision!==epoch||settings.muted||!settings.volume||document.hidden||paused&&!options.menu||performance.now()-requested>1200)return false;
    const detail={role,line,text:c.text,kind,action:options.action||null};
    const a={buffer,offset:0,menu:!!options.menu,role,kind};startBuffer(name,a);emit(detail);return true;
  }
  function stop() {epoch++;for(const name of new Set([...channels.keys(),...tickets.keys()]))stopChannel(name);}
  const api=root.DungeonVoices={
    lineFor,unlock,play,
    get settings(){return {...settings};},
    setSettings(next){settings={...settings,...next};settings.volume=Number.isFinite(settings.volume)?Math.max(0,Math.min(1,settings.volume)):.9;if(gain)gain.gain.value=settings.muted?0:settings.volume;if(settings.muted||!settings.volume)stop();try{localStorage.setItem(key,JSON.stringify(settings));}catch{}},
    preload(roles=Object.keys(catalog)){unlock();if(context)for(const role of roles)for(let line=1;line<=(role==='priest'?13:12);line++)load(role,line);},
    selection(role,turnKey=null){
      if(turnKey!==null&&(paused||!context||context.state!=='running'))return;
      if(turnKey!==null){if(selectionKey===turnKey)return;selectionKey=turnKey;}
      const now=performance.now();if(turnKey===null&&now-lastSelection<250)return;lastSelection=now;
      const line=1+((selectionCount[role]||0)%2);selectionCount[role]=(selectionCount[role]||0)+1;
      return play(role,line,'selection',{menu:turnKey===null});
    },
    action(role,id,token){if(paused||!token||seen.has(token))return;seen.add(token);return play(role,lineFor(role,id),'action',{action:id});},
    duration(role,id){return (cue(role,lineFor(role,id))?.duration_seconds||0)*1000;},
    hurt(role,dead=false){
      const now=performance.now();if(!dead&&now-(hurtAt.get(role)??-Infinity)<650)return;hurtAt.set(role,now);
      // At most two simultaneous reactions for area hits, with no delayed chorus.
      const occupied=['reaction-0','reaction-1'].filter(n=>channels.has(n));
      const channel=['reaction-0','reaction-1'].find(n=>!channels.has(n)&&!pendingChannels.has(n));
      if(!channel&&!dead)return;
      const chosen=channel||occupied[0]||'reaction-0';
      if(channels.get('speech')?.role===role)stopChannel('speech');
      return play(role,dead?11:5,dead?'defeat':'hurt',{channel:chosen});
    },
    victory(role){return play(role,12,'victory');},
    setPaused(value){value=!!value;if(value===paused)return;paused=value;epoch++;
      for(const [name,a]of channels){if(a.menu)continue;if(paused&&a.source){a.offset+=context.currentTime-a.at;a.source.onended=null;try{a.source.stop();}catch{}a.source=null;}else if(!paused&&!a.source)startBuffer(name,a);}
    },
    stop,reset(){stop();seen=new WeakSet();selectionKey=null;hurtAt.clear();selectionCount={};},
  };
  const prime=()=>api.preload();
  document.addEventListener('pointerdown',prime,{once:true,capture:true});
  document.addEventListener('keydown',prime,{once:true,capture:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
  root.addEventListener('pagehide',stop);root.addEventListener('gamescreenenter',stop);
  root.addEventListener('storage',e=>{if(e.key===key){readSettings();if(settings.muted||!settings.volume)stop();}});
  // Native roster choices use the same cast as the battle, without hover chatter.
  document.addEventListener('change',e=>{if(e.target.matches('#roster select,#party-setup select'))api.selection(e.target.value);});
  const enabled=document.querySelector('#voices-enabled'),volume=document.querySelector('#voices-volume'),value=document.querySelector('#voices-value');
  if(enabled){enabled.checked=!settings.muted;volume.value=Math.round(settings.volume*100);value.textContent=volume.value+'%';enabled.addEventListener('change',()=>api.setSettings({muted:!enabled.checked}));volume.addEventListener('input',()=>{api.setSettings({volume:+volume.value/100});value.textContent=volume.value+'%';});}
  // Explicit local QA mode: passive evidence only; never changes combat state.
  if(new URLSearchParams(location.search).has('voicecheck')){
    const panel=document.createElement('details');panel.id='voice-check';panel.open=true;
    panel.style.cssText='position:fixed;right:8px;bottom:8px;z-index:2147483646;max-width:380px;max-height:210px;overflow:auto;background:#17121ff2;color:#ffe7a4;border:1px solid #bda062;padding:10px;font:12px/1.6 monospace';
    panel.innerHTML='<summary>음성 재생 확인</summary><ol></ol>';document.body.append(panel);
    root.addEventListener('charactervoiceplayed',e=>{const li=document.createElement('li');li.textContent=catalog[e.detail.role].name+' · '+e.detail.kind+' · '+e.detail.text;li.dataset.event=JSON.stringify(e.detail);panel.querySelector('ol').prepend(li);});
  }
})();
