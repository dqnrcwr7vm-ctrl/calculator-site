/* Authored visual-phase cue timing, in shared battle milliseconds. Audio only. */
(function(root){
 'use strict';
 const cue=(id,at,until,level=.55,channel='magic-bed')=>({id:'magic-'+id,at,until,level,channel});
 const plans={
  wizard:{
   fireball:[cue('fire-flight',820,1300,.6)],
   'ice-spear':[cue('ice-flight',820,1300,.55)],
   'thunder-ball':[cue('lightning-flight',820,1300,.5)],
   void:[cue('arcane-flight',820,1300,.55)],
   meteor:[cue('meteor-fall',820,1700,.75)],
   blizzard:[cue('blizzard',820,4780,.5)],
   thunderstorm:[cue('lightning-flight',820,1310,.25),cue('thunder-strike',1310,2110,.58,'magic-accent'),cue('thunder-strike',2110,2910,.65,'magic-accent'),cue('thunder-strike',2910,3760,.55,'magic-accent')],
   'black-hole':[cue('black-hole-open',0,4160,.5)],
   'black-hole-release':[cue('black-hole-release',0,2100,.5)]
  },
  priest:{
   'living-water':[cue('holy-heal',760,2760,.5),cue('holy-heal',2760,4760,.4)],
   blessing:[cue('holy-blessing',760,3560,.62)],
   barrier:[cue('holy-barrier',760,4560,.6)],
   recovery:[cue('holy-heal',760,2680,.5)],
   healing:[cue('holy-heal',760,2680,.58)],
   resurrection:[cue('holy-resurrection',760,4150,.65)],
   'holy-light':[cue('holy-beam',760,1600,.5)],
   sanctuary:[cue('holy-blessing',760,4160,.52)]
  },
  archer:{
   'leg-bind':[cue('nature-cast',920,2920,.45)],
   'leaf-wind':[cue('nature-cast',920,2920,.55)],
   'natures-cure':[cue('nature-cast',920,2920,.35),cue('holy-heal',1120,2920,.22,'magic-accent')],
   'eagle-eye':[cue('nature-cast',920,2520,.35)],
   'phoenix-shot':[cue('fire-flight',600,1600,.5)],
   'stun-shot':[cue('lightning-flight',840,1560,.3)]
  },
  // These actors pass acting-phase time, excluding advance and return movement.
  hero:{
   'fire-slash':[cue('fire-flight',220,900,.4)],
   'frost-slash':[cue('ice-flight',220,900,.4)],
   'lightning-slash':[cue('lightning-flight',220,900,.35)],
   'leaf-slash':[cue('nature-cast',220,1200,.35)],
   'dark-slash':[cue('arcane-flight',220,900,.4)]
  },
  dwarf:{
   'dwarf-bulwark':[cue('ice-flight',400,1400,.5)],
   'dwarf-mjolnir':[cue('lightning-flight',400,1200,.45)]
  }
 };
 const api={plans,forSkill:(role,id)=>plans[role]?.[id]||[]};
 if(typeof module==='object'&&module.exports)module.exports=api;
 root.DungeonMagicCues=api;
})(typeof window!=='undefined'?window:globalThis);
