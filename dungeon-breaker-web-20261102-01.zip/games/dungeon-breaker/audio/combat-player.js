/* ElevenLabs creature reactions and impacts. Separate from approved speech/UI/music. */
(() => {
  'use strict';
  const root=window, catalog=root.DungeonCombatSfxCatalog||{cues:{},monsters:{}};
  const base=new URL('combat-elevenlabs-v1/',document.currentScript.src), key='dungeon-breaker-combat-audio';
  let settings={muted:false,volume:.75},context,master,epoch=0,paused=false,sequence=0;
  let actions=new WeakSet(),spellEvents=new WeakMap();
  const spellChannels=new Map();
  const buffers=new Map(),loading=new Map(),channels=new Map(),tickets=new Map(),pending=new Set(),cooldowns=new Map();
  function readSettings(){try{const s=JSON.parse(localStorage.getItem(key)||'{}');settings.muted=!!s.muted;if(Number.isFinite(s.volume))settings.volume=Math.max(0,Math.min(1,s.volume));}catch{}if(master)master.gain.value=settings.muted?0:settings.volume;}
  readSettings();
  function prepareContext(){if(!context){const AC=root.AudioContext||root.webkitAudioContext;if(!AC)return;context=new AC();master=context.createGain();master.connect(context.destination);master.gain.value=settings.muted?0:settings.volume;}return context;}
  function unlock(){if(!prepareContext())return;return context.state==='suspended'?context.resume().catch(()=>{}):Promise.resolve();}
  function load(id){if(!context||!catalog.cues[id])return Promise.resolve(null);if(buffers.has(id))return Promise.resolve(buffers.get(id));if(!loading.has(id))loading.set(id,fetch(new URL(catalog.cues[id].file,base)).then(r=>{if(!r.ok)throw Error(r.status);return r.arrayBuffer();}).then(b=>context.decodeAudioData(b)).then(b=>{buffers.set(id,b);document.documentElement.dataset.combatSfxLoaded=String(buffers.size);return b;}).catch(()=>null).finally(()=>loading.delete(id)));return loading.get(id);}
  function stopChannel(name){tickets.set(name,(tickets.get(name)||0)+1);pending.delete(name);spellChannels.delete(name);const a=channels.get(name);if(a?.source){a.source.onended=null;try{a.source.stop();}catch{}a.gain?.disconnect?.();}channels.delete(name);}
  function start(name,a){if(a.offset>=(a.end??a.buffer.duration)){channels.delete(name);return;}const source=context.createBufferSource(),gain=context.createGain();source.buffer=a.buffer;gain.gain.value=a.level;source.connect(gain);gain.connect(master);a.source=source;a.gain=gain;a.at=context.currentTime;channels.set(name,a);source.onended=()=>{if(channels.get(name)?.source===source)channels.delete(name);gain.disconnect?.();};const remaining=(a.end??a.buffer.duration)-a.offset;if(a.end<a.buffer.duration){gain.gain.setValueAtTime?.(a.level,context.currentTime+Math.max(0,remaining-.025));gain.gain.linearRampToValueAtTime?.(0,context.currentTime+remaining);}source.start(0,a.offset,remaining);}
  function emit(detail){const d=document.documentElement.dataset;d.combatSfxCount=String(+(d.combatSfxCount||0)+1);d.combatSfxHistory=JSON.stringify([detail,...JSON.parse(d.combatSfxHistory||'[]')].slice(0,40));root.dispatchEvent(new CustomEvent('combatsfxplayed',{detail}));}
  async function play(id,options={}){
    if(!catalog.cues[id]||paused||settings.muted||!settings.volume||document.hidden)return false;
    const at=performance.now(),throttle=options.throttle||id;if(at-(cooldowns.get(throttle)??-Infinity)<(options.cooldown??60))return false;
    const resumed=unlock();if(!context)return false;const name=options.channel||'impact';
    if(options.keep&&(channels.has(name)||pending.has(name)))return false;
    cooldowns.set(throttle,at);stopChannel(name);const ticket=tickets.get(name),revision=epoch;pending.add(name);
    await resumed;if(context.state!=='running'){if(ticket===tickets.get(name))pending.delete(name);return false;}
    const buffer=await load(id);if(ticket===tickets.get(name))pending.delete(name);
    if(!buffer||ticket!==tickets.get(name)||revision!==epoch||paused||document.hidden||settings.muted||!settings.volume||performance.now()-at>350)return false;
    const offset=Math.max(0,options.offset||0),end=Math.min(buffer.duration,offset+(options.duration??buffer.duration));if(offset>=end)return false;start(name,{buffer,offset,end,level:options.level??.8});emit({id,kind:catalog.cues[id].kind,channel:name,monster:options.monster||null,source:options.source||null,profile:options.profile||null,role:options.role||null,skillId:options.skillId||null,phaseMs:options.phaseMs??null,sequence:++sequence});return true;
  }
  function mapping(enemy){const monster=enemy?.spriteAsset?.id||root.BATTLE_ASSETS?.[4]?.id;const dungeon=root.ActiveDungeon?.id||new URLSearchParams(location.search).get('dungeon')||'01';return {monster,...catalog.monsters[dungeon+':'+monster]};}
  function profileFor(hit={},role='',family=''){
    return root.DungeonImpactProfiles?.profileFor(hit,role,family)||{key:'fallback',role,skillId:hit.audioSkillId||hit.skillId||'attack',physical:true,layers:[{id:'impact-blunt',level:1}]};
  }
  function impactFor(...args){return profileFor(...args).layers[0].id;}
  function impact(profile,options={}){
    if(paused||settings.muted||!settings.volume||document.hidden)return Promise.resolve([]);
    const now=performance.now();
    // Coalesce one simultaneous area-damage batch, but retain both weapon and element.
    if(now-(cooldowns.get('impact-batch')??-Infinity)<45)return Promise.resolve([]);
    cooldowns.set('impact-batch',now);
    const layers=profile.layers.map((layer,i)=>({...layer,channel:i?'impact-detail':'impact'}));
    if(profile.physical&&options.material==='construct'&&!layers.some(l=>l.id==='impact-metal'))layers.push({id:'impact-metal',level:.18,channel:'impact-material'});
    for(const channel of ['impact','impact-detail','impact-material'])stopChannel(channel);
    return Promise.all(layers.map(layer=>play(layer.id,{...options,channel:layer.channel,level:layer.level*.9,cooldown:0,profile:profile.key,role:profile.role,skillId:profile.skillId})));
  }
  function reaction(enemy,dead=false){const m=mapping(enemy);if(!m.hurt)return;const channel=['reaction-0','reaction-1'].find(n=>!channels.has(n)&&!pending.has(n));if(!channel&&!dead)return;
    return play(dead?m.defeat:m.hurt,{channel:channel||'reaction-0',keep:!dead,level:dead ? .65 : .36,monster:m.monster,throttle:'reaction:'+enemy.id,cooldown:220});}
  function stopSpell(owner){for(const [name,lease]of spellChannels)if(lease.owner===owner)stopChannel(name);}
  function spell(role,id,owner,age){
    if(!owner||paused||!Number.isFinite(age))return Promise.resolve([]);
    for(const [name,lease]of spellChannels)if(lease.owner===owner&&age>=lease.until)stopChannel(name);
    const plan=root.DungeonMagicCues?.forSkill(role,id)||[];
    let seen=spellEvents.get(owner);if(!seen){seen=new Set();spellEvents.set(owner,seen);}
    const jobs=[];
    plan.forEach((cue,index)=>{
      if(seen.has(index)||age<cue.at)return;
      seen.add(index);
      if(age>=cue.until||settings.muted||!settings.volume||document.hidden)return;
      const lease={owner,until:cue.until},job=play(cue.id,{channel:cue.channel,level:cue.level,source:'spell',role,skillId:id,phaseMs:age,cooldown:0,offset:(age-cue.at)/1000,duration:(cue.until-age)/1000});
      spellChannels.set(cue.channel,lease);
      jobs.push(job.then(played=>{if(!played&&spellChannels.get(cue.channel)===lease)spellChannels.delete(cue.channel);return played;}));
    });
    return Promise.all(jobs);
  }
  function stop(){epoch++;spellChannels.clear();for(const n of new Set([...channels.keys(),...tickets.keys()]))stopChannel(n);}
  const api=root.DungeonCombatAudio={
    unlock,play,impactFor,profileFor,mapping,
    spell,stopSpell,
    get settings(){return {...settings};},
    setSettings(next){settings={...settings,...next};settings.volume=Number.isFinite(settings.volume)?Math.max(0,Math.min(1,settings.volume)):.75;if(master)master.gain.value=settings.muted?0:settings.volume;if(settings.muted||!settings.volume)stop();try{localStorage.setItem(key,JSON.stringify(settings));}catch{}},
    // Decode during battle loading; playback still unlocks only on user input.
    prepare(){if(!prepareContext())return;const ids=new Set(Object.keys(catalog.cues).filter(id=>id.startsWith('impact-')||id.startsWith('defeat-')||id.startsWith('magic-')));for(const e of [{spriteAsset:root.BATTLE_ASSETS?.[4]},...(root.BATTLE_CONFIG?.enemyFormation||[])]){const m=mapping(e);[m.roar,m.hurt,m.defeat].forEach(id=>{if(id)ids.add(id);});}return Promise.all([...ids].map(load));},
    preload(){unlock();return api.prepare();},
    enemyAction(enemy,action){if(paused||!action||actions.has(action)||action.plan?.clip==='guard'||action.plan?.target==='self'||!(action.plan?.damage>0||action.plan?.wipe))return;actions.add(action);const m=mapping(enemy);return play(m.roar,{channel:'roar',level:enemy.isBoss ? .65 : .4,monster:m.monster,throttle:'roar:'+enemy.id,cooldown:400});},
    enemyImpact(enemy,action){if(!action||!(action.plan?.damage>0||action.plan?.wipe)||action.plan?.target==='self')return;const m=mapping(enemy);return impact(profileFor(action.plan,'',m.family),{source:'monster',monster:m.monster});},
    playerHit(enemy,hit={},amount=0,options={}){if(!(amount>0))return;const actor=root.PartyTurns?.cycle.actor,role=hit.role||root.BATTLE_ASSETS?.[actor]?.id||'',m=mapping(enemy);return Promise.all([impact(profileFor(hit,role),{source:'ally',monster:m.monster,material:m.family}),options.reaction===false?null:reaction(enemy,enemy.hp<=0)]);},
    setPaused(value){value=!!value;if(value===paused)return;paused=value;epoch++;for(const [name,a]of channels){if(paused&&a.source){a.offset+=context.currentTime-a.at;a.source.onended=null;try{a.source.stop();}catch{}a.gain?.disconnect?.();a.source=null;}else if(!paused&&!a.source)start(name,a);}},
    stop,reset(){stop();actions=new WeakSet();spellEvents=new WeakMap();cooldowns.clear();}
  };
  document.addEventListener('pointerdown',()=>api.preload(),{once:true,capture:true});
  document.addEventListener('keydown',()=>api.preload(),{once:true,capture:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});root.addEventListener('pagehide',stop);root.addEventListener('gamescreenenter',stop);
  root.addEventListener('storage',e=>{if(e.key===key){readSettings();if(settings.muted||!settings.volume)stop();}});
  const enabled=document.querySelector('#combat-sfx-enabled'),volume=document.querySelector('#combat-sfx-volume'),value=document.querySelector('#combat-sfx-value');
  if(enabled){enabled.checked=!settings.muted;volume.value=Math.round(settings.volume*100);value.textContent=volume.value+'%';enabled.addEventListener('change',()=>api.setSettings({muted:!enabled.checked}));volume.addEventListener('input',()=>{api.setSettings({volume:+volume.value/100});value.textContent=volume.value+'%';});}
  if(new URLSearchParams(location.search).has('sfxcheck')){
    const panel=document.createElement('details');panel.open=true;panel.id='combat-sfx-check';panel.style.cssText='position:fixed;right:8px;bottom:8px;z-index:2147483646;max-width:360px;max-height:220px;overflow:auto;background:#17121ff2;color:#ffe7a4;border:1px solid #bda062;padding:10px;font:12px/1.6 monospace';panel.innerHTML='<summary>전투 효과음 재생 확인</summary><ol></ol>';document.body.append(panel);
    root.addEventListener('combatsfxplayed',e=>{const li=document.createElement('li');li.textContent=e.detail.sequence+' · '+catalog.cues[e.detail.id].name+' · '+(e.detail.skillId||e.detail.kind);panel.querySelector('ol').prepend(li);while(panel.querySelector('ol').children.length>20)panel.querySelector('ol').lastChild.remove();});
  }
})();
