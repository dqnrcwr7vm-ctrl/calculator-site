/* Kept pure so every dungeon and boss/clear transition can be checked cheaply. */
(function(root){
 const select=({initialDraft=false,cleared=false,boss=false,dungeon='01'})=>initialDraft?'lobby':cleared&&boss?'victory':boss?'boss':'dungeon-'+dungeon;
 if(typeof module==='object')module.exports=select;else root.DungeonMusicTrack=select;
})(typeof window==='object'?window:globalThis);
