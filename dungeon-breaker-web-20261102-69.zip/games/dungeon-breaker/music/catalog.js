window.DungeonMusicCatalog={
  "title": {
    "file": "../opening-adventure-v6-bgm/assets/main-theme.m4a",
    "name": "DUNGEON BREAKER Main Theme",
    "loop": true
  },
  "boss": {
    "file": "boss-common-v2.mp3",
    "name": "DUNGEON BREAKER Boss Theme - Version 2",
    "loop": true
  },
  "victory": {
    "file": "victory.mp3",
    "name": "DUNGEON BREAKER - Crown of Victory",
    "loop": false
  },
  "lobby": {
    "file": "lobby.mp3",
    "name": "DUNGEON BREAKER - Adventurers Map (Lobby)",
    "loop": true
  },
  "town": {
    "file": "town.mp3",
    "name": "DUNGEON BREAKER - Hearth and Steel (Town)",
    "loop": true
  },
  "dungeon-01": {
    "file": "dungeon-01.mp3",
    "name": "DUNGEON BREAKER - Sunken Galleon",
    "loop": true
  },
  "dungeon-02": {
    "file": "dungeon-02.mp3",
    "name": "DUNGEON BREAKER - Thorn Crown Tower",
    "loop": true
  },
  "dungeon-03": {
    "file": "dungeon-03.mp3",
    "name": "DUNGEON BREAKER - Frostheart Prison",
    "loop": true
  },
  "dungeon-04": {
    "file": "dungeon-04.mp3",
    "name": "DUNGEON BREAKER - Fallen Sun Furnace",
    "loop": true
  },
  "dungeon-05": {
    "file": "dungeon-05.mp3",
    "name": "DUNGEON BREAKER - Eclipsed Library",
    "loop": true
  },
  "dungeon-06": {
    "file": "dungeon-06.mp3",
    "name": "DUNGEON BREAKER - Glass Desert Royal Tomb",
    "loop": true
  },
  "dungeon-07": {
    "file": "dungeon-07.mp3",
    "name": "DUNGEON BREAKER - Stormchain Citadel",
    "loop": true
  },
  "dungeon-08": {
    "file": "dungeon-08.mp3",
    "name": "DUNGEON BREAKER - Sporelight Abyss",
    "loop": true
  },
  "dungeon-09": {
    "file": "dungeon-09.mp3",
    "name": "DUNGEON BREAKER - Stopped Clock Spire",
    "loop": true
  },
  "dungeon-10": {
    "file": "dungeon-10.mp3",
    "name": "DUNGEON BREAKER - White Night Pilgrimage",
    "loop": true
  }
};
