import * as crypto from 'node:crypto';
const R=(()=>{
  'use strict';
  const SUITS=['♥','♠','♦','♣'],KINGDOMS=['Solea','Nokheim','Archeon','Verdan'];
  const clone=x=>JSON.parse(JSON.stringify(x));
  const tile=id=>({id,suit:id<104?Math.floor(id/26):-1,rank:id<104?id%13+1:0,joker:id>=104});
  const value=id=>id>=104?30:tile(id).rank;
  const signature=ids=>[...ids].sort((a,b)=>a-b).join(',');
  const flat=board=>board.flatMap(m=>m.tiles);
  function meld(ids){
    const bad=reason=>({valid:false,kind:'',score:0,reason,assignments:[]});
    if(ids.length<3)return bad('조합은 3장 이상이어야 해요.');
    if(ids.length>13)return bad('연속 조합은 최대 13장이에요.');
    if(new Set(ids).size!==ids.length||ids.some(id=>!Number.isInteger(id)||id<0||id>105))return bad('같은 카드가 중복되었어요.');
    const real=ids.map(tile).filter(t=>!t.joker),jokers=ids.filter(id=>id>=104);
    if(real.length===0)return bad('숫자 카드가 필요해요.');
    if(ids.length<=4&&real.every(t=>t.rank===real[0].rank)&&new Set(real.map(t=>t.suit)).size===real.length){
      const missing=[0,1,2,3].filter(s=>!real.some(t=>t.suit===s));
      return{valid:true,kind:'group',score:real[0].rank*ids.length,reason:'같은 숫자',assignments:jokers.map((id,i)=>({id,rank:real[0].rank,suit:missing[i]}))};
    }
    const first=ids.findIndex(id=>id<104),start=tile(ids[first]).rank-first;
    if(start<1||start+ids.length-1>13)return bad('A는 1이에요. K 다음에 A를 이을 수 없어요.');
    const suit=real[0].suit;
    if(ids.some((id,i)=>id<104&&(tile(id).suit!==suit||tile(id).rank!==start+i)))return bad('같은 문양의 연속 숫자 또는 서로 다른 문양의 같은 숫자로 연결하세요.');
    return{valid:true,kind:'run',score:ids.length*(2*start+ids.length-1)/2,reason:'연속 숫자',assignments:ids.flatMap((id,i)=>id>=104?[{id,rank:start+i,suit}]:[])};
  }
  function arrange(ids){
    if(meld(ids).valid)return [...ids];
    const real=ids.filter(id=>id<104),jokers=ids.filter(id=>id>=104);
    if(!real.length)return [...ids];
    const group=[...real].sort((a,b)=>tile(a).suit-tile(b).suit).concat(jokers);
    if(meld(group).valid)return group;
    if(real.every(id=>tile(id).suit===tile(real[0]).suit)&&new Set(real.map(id=>tile(id).rank)).size===real.length){
      for(let start=14-ids.length;start>=1;start--){
        if(real.some(id=>tile(id).rank<start||tile(id).rank>=start+ids.length))continue;
        const unused=[...jokers],run=[];
        for(let rank=start;rank<start+ids.length;rank++)run.push(real.find(id=>tile(id).rank===rank)??unused.shift());
        if(run.every(id=>id!==undefined)&&meld(run).valid)return run;
      }
    }
    return [...ids];
  }
  function create(seed=Date.now()>>>0,playerCount=4){
    if(!Number.isInteger(playerCount)||playerCount<2||playerCount>4)throw Error("2–4 players required");
    let x=(seed>>>0)||1;const next=n=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)%n;};
    let starterDraw;do{starterDraw=Array.from({length:playerCount},()=>next(13)+1);}while(new Set(starterDraw).size!==playerCount);
    const pool=Array.from({length:106},(_,i)=>i);
    for(let i=pool.length-1;i>0;i--){const j=next(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}
    const players=Array.from({length:playerCount},(_,i)=>i).map(()=>({tiles:pool.splice(pool.length-14,14),opened:false}));
    return{version:1,seed:seed>>>0,players,pool,board:[],current:starterDraw.indexOf(Math.max(...starterDraw)),turn:1,passes:0,phase:'playing',winner:-1,scores:Array(playerCount).fill(0),starterDraw,lastPlayed:[],lastAction:'start',lastActor:-1};
  }
  const draft=state=>({board:clone(state.board),rack:[...state.players[state.current].tiles]});
  function validate(state,work){
    const fail=(code,message)=>({valid:false,code,message,played:[],points:0,sets:0});
    if(state.phase!=='playing')return fail('finished','이미 끝난 대전이에요.');
    const original=state.players[state.current].tiles,old=flat(state.board),now=flat(work.board),all=now.concat(work.rack),expected=old.concat(original);
    if(all.length!==expected.length||new Set(all).size!==all.length||signature(all)!==signature(expected))return fail('inventory','카드가 빠졌거나 중복되었어요. 턴을 되돌려 주세요.');
    if(old.some(id=>work.rack.includes(id)))return fail('table_to_rack','이미 등록된 카드를 손패로 가져올 수 없어요.');
    const played=original.filter(id=>!work.rack.includes(id));
    if(played.length===0)return fail('no_play','자기 카드를 1장 이상 놓거나 1장을 뽑으세요.');
    const sets=work.board.filter(m=>m.tiles.length);
    for(let i=0;i<sets.length;i++){const check=meld(sets[i].tiles);if(!check.valid)return fail('invalid_meld',(i+1)+'번 조합: '+check.reason);}
    let points=played.reduce((s,id)=>s+(id<104?value(id):0),0);
    if(!state.players[state.current].opened){
      const oldKeys=state.board.map(m=>signature(m.tiles));
      if(oldKeys.some(key=>!sets.some(m=>signature(m.tiles)===key)))return fail('initial_table','첫 등록에서는 기존 보드를 바꿀 수 없어요.');
      const fresh=sets.filter(m=>!oldKeys.includes(signature(m.tiles)));
      if(fresh.some(m=>m.tiles.some(id=>!original.includes(id))))return fail('initial_table','첫 등록은 자기 손패만으로 만들어야 해요.');
      points=fresh.reduce((sum,m)=>sum+meld(m.tiles).score,0);
      if(points<30)return fail('initial_points','첫 등록은 합계 30점 이상이에요. 지금은 '+points+'점이에요.');
    }
    return{valid:true,code:'ok',message:played.length+'장 연결 가능',played,points,sets:sets.filter(m=>m.tiles.some(id=>played.includes(id))).length};
  }
  function invariant(state){
    if(!state||!Array.isArray(state.players)||state.players.length<2||state.players.length>4||!Number.isInteger(state.current)||state.current<0||state.current>=state.players.length)return false;
    const ids=state.pool.concat(...state.players.map(p=>p.tiles),flat(state.board));
    return ids.length===106&&new Set(ids).size===106&&ids.every(id=>Number.isInteger(id)&&id>=0&&id<106)&&state.board.every(m=>meld(m.tiles).valid);
  }
  function finish(state,winner,blocked=false){
    state.phase=blocked?'blocked':'won';state.winner=winner;
    const sums=state.players.map(p=>p.tiles.reduce((a,id)=>a+value(id),0));
    state.scores=Array(sums.length).fill(0);
    if(winner>=0){for(let i=0;i<sums.length;i++)if(i!==winner){const loss=blocked?sums[i]-sums[winner]:sums[i];state.scores[i]=-loss;state.scores[winner]+=loss;}}
  }
  function commit(state,work){
    const result=validate(state,work);if(!result.valid)return result;
    const actor=state.current;state.board=clone(work.board.filter(m=>m.tiles.length));state.players[actor].tiles=[...work.rack];state.players[actor].opened=true;
    state.lastPlayed=[...result.played];state.lastAction='play';state.lastActor=actor;state.passes=0;
    if(work.rack.length===0)finish(state,actor);else{state.current=(actor+1)%state.players.length;state.turn++;}
    return result;
  }
  function draw(state,count=1,reason='draw'){
    if(state.phase!=='playing')return[];
    const actor=state.current,drawn=[];
    for(let i=0;i<count&&state.pool.length;i++)drawn.push(state.pool.pop());
    state.players[actor].tiles.push(...drawn);state.lastPlayed=[];state.lastAction=drawn.length?reason:'pass';state.lastActor=actor;
    state.passes=drawn.length?0:state.passes+1;
    if(state.passes>=state.players.length){const sums=state.players.map(p=>p.tiles.reduce((s,id)=>s+value(id),0)),min=Math.min(...sums),winners=sums.map((n,i)=>n===min?i:-1).filter(i=>i>=0);finish(state,winners.length===1?winners[0]:-1,true);}
    else{state.current=(actor+1)%state.players.length;state.turn++;}
    return drawn;
  }
  const dirty=(state,work)=>JSON.stringify(state.board)!==JSON.stringify(work.board)||signature(state.players[state.current].tiles)!==signature(work.rack);
  function timeout(state,work){const count=dirty(state,work)&&!validate(state,work).valid?3:1;return{count,drawn:draw(state,count,count===3?'penalty':'timeout')};}
  function move(state,work,ids,target,index=-1){
    if(state.phase!=='playing')return{valid:false,message:'이미 끝난 대전이에요.'};
    if(target!=='rack'&&target!=='new'&&(!Number.isInteger(target)||target<0||target>=work.board.length))return{valid:false,message:'조합을 다시 선택하세요.'};
    ids=[...new Set(ids)];if(!ids.length)return{valid:false,message:'옮길 카드를 선택하세요.'};
    const originalRack=state.players[state.current].tiles;
    if(ids.some(id=>!work.rack.includes(id)&&!flat(work.board).includes(id)))return{valid:false,message:'현재 턴의 카드가 아니에요.'};
    if(!state.players[state.current].opened&&ids.some(id=>!originalRack.includes(id)))return{valid:false,message:'첫 등록 후에 보드를 재배치할 수 있어요.'};
    if(target==='rack'&&ids.some(id=>!originalRack.includes(id)))return{valid:false,message:'등록된 카드는 손패로 가져올 수 없어요.'};
    if(typeof target==='number'&&(target<0||target>=work.board.length))return{valid:false,message:'조합을 다시 선택하세요.'};
    if(typeof target==='number'&&!state.players[state.current].opened&&work.board[target].tiles.some(id=>!originalRack.includes(id)))return{valid:false,message:'첫 등록은 새로운 조합으로 만드세요.'};
    let at=index;
    if(typeof target==='number'&&at>=0)at-=work.board[target].tiles.slice(0,at).filter(id=>ids.includes(id)).length;
    work.rack=work.rack.filter(id=>!ids.includes(id));for(const m of work.board)m.tiles=m.tiles.filter(id=>!ids.includes(id));
    if(target==='rack')work.rack.push(...ids);
    else if(target==='new')work.board.push({tiles:arrange(ids)});
    else{const list=work.board[target].tiles;list.splice(at<0?list.length:Math.min(at,list.length),0,...ids);}
    // Empty trays are only temporary drop targets; no tile is discarded.
    return{valid:true,message:'배치했어요.'};
  }
  function autoConnect(state,work,ids){
    ids=[...new Set(ids)];
    if(!ids.length||ids.some(id=>!work.rack.includes(id)))return null;
    // Only the explicitly selected cards are moved; never search the rest of the hand.
    const original=state.players[state.current];
    const fresh=arrange(ids);
    if(meld(fresh).valid){const next=clone(work);if(move(state,next,ids,'new').valid)return next;}
    for(let i=0;i<work.board.length;i++){
      const base=work.board[i].tiles;if(!base.length||!meld(base).valid)continue;
      if(!original.opened&&base.some(id=>!original.tiles.includes(id)))continue;
      const joined=arrange(base.concat(ids));if(!meld(joined).valid)continue;
      const next=clone(work);if(!move(state,next,ids,i).valid)continue;
      next.board[i].tiles=joined;return next;
    }
    return null;
  }
  function candidates(rack){
    const result=[],seen=new Set(),jokers=rack.filter(id=>id>=104),by=Array.from({length:4},()=>Array.from({length:14},()=>[]));
    for(const id of rack)if(id<104){const t=tile(id);by[t.suit][t.rank].push(id);}
    const add=ids=>{const key=ids.join(',');if(!seen.has(key)&&meld(ids).valid){seen.add(key);result.push(ids);}};
    for(let rank=1;rank<=13;rank++){
      const present=[0,1,2,3].filter(s=>by[s][rank].length);
      for(let mask=1;mask<(1<<present.length);mask++){
        const ids=present.filter((_,i)=>mask&(1<<i)).map(s=>by[s][rank][0]);
        for(let j=0;j<=jokers.length;j++)if(ids.length+j>=3&&ids.length+j<=4)add(ids.concat(jokers.slice(0,j)));
      }
    }
    for(let suit=0;suit<4;suit++)for(let start=1;start<=11;start++)for(let end=start+2;end<=13;end++){
      const ids=[],unused=[...jokers];let ok=true;
      for(let rank=start;rank<=end;rank++){if(by[suit][rank].length)ids.push(by[suit][rank][0]);else if(unused.length)ids.push(unused.shift());else{ok=false;break;}}
      if(ok)add(ids);
    }
    return result.sort((a,b)=>b.length-a.length||meld(b).score-meld(a).score||signature(a).localeCompare(signature(b)));
  }
  function pack(rack,minimum=0,budget=700){
    let best=[],bestWeight=-1,nodes=0;const visited=new Set();
    function visit(left,sets,points){
      if(++nodes>budget)return;
      const played=rack.length-left.length,weight=played*100+points;
      if(points>=minimum&&played&&weight>bestWeight){best=clone(sets);bestWeight=weight;}
      const key=signature(left)+':'+Math.min(points,minimum);if(visited.has(key))return;visited.add(key);
      for(const ids of candidates(left).slice(0,18))visit(left.filter(id=>!ids.includes(id)),sets.concat([{tiles:ids}]),points+meld(ids).score);
    }
    visit([...rack],[],0);return best;
  }
  function plan(state,difficulty='advanced'){
    const beginner=difficulty==='beginner',advanced=difficulty==='advanced';
    if(state.phase!=='playing')return null;
    const player=state.players[state.current];
    if(!player.opened){const sets=pack(player.tiles,30,beginner?80:advanced?700:250);if(!sets.length)return null;const used=flat(sets),work={board:clone(state.board).concat(sets),rack:player.tiles.filter(id=>!used.includes(id))};return validate(state,work).valid?work:null;}
    function solve(rackFirst){
      const work=draft(state);
      function addPack(){const sets=beginner?candidates(work.rack).slice(0,1).map(tiles=>({tiles})):pack(work.rack,0,advanced?250:120);if(!sets.length)return false;const used=flat(sets);work.rack=work.rack.filter(id=>!used.includes(id));work.board.push(...sets);return true;}
      function extend(){for(const id of work.rack)for(const m of work.board)for(let at=0;at<=m.tiles.length;at++){const ids=[...m.tiles];ids.splice(at,0,id);if(meld(ids).valid){m.tiles=ids;work.rack=work.rack.filter(x=>x!==id);return true;}}return false;}
      function split(){for(let mi=0;mi<work.board.length;mi++){const m=work.board[mi];if(meld(m.tiles).kind!=='run'||m.tiles.length<5)continue;for(let cut=2;cut<=m.tiles.length-2;cut++)for(const id of work.rack)for(let side=0;side<2;side++){
        const parts=[m.tiles.slice(0,cut),m.tiles.slice(cut)];parts[side]=arrange(parts[side].concat(id));
        if(parts.every(p=>meld(p).valid)){work.board.splice(mi,1,...parts.map(tiles=>({tiles})));work.rack=work.rack.filter(x=>x!==id);return true;}
      }}return false;}
      function borrow(){for(const m of work.board)for(const loan of m.tiles){const rest=m.tiles.filter(x=>x!==loan);if(!meld(rest).valid)continue;const set=candidates(work.rack.concat(loan)).find(ids=>ids.includes(loan)&&ids.filter(id=>work.rack.includes(id)).length>=2);if(set){m.tiles=rest;work.rack=work.rack.filter(id=>!set.includes(id));work.board.push({tiles:set});return true;}}return false;}
      function freeJoker(){for(const m of work.board)for(let at=0;at<m.tiles.length;at++)if(m.tiles[at]>=104)for(const replacement of work.rack.filter(id=>id<104)){
        const copy=[...m.tiles],joker=copy[at];copy[at]=replacement;if(!meld(copy).valid)continue;
        const available=work.rack.filter(id=>id!==replacement).concat(joker),set=candidates(available).find(ids=>ids.includes(joker));
        if(set){m.tiles=copy;work.rack=work.rack.filter(id=>id!==replacement&&!set.includes(id));work.board.push({tiles:set});return true;}
      }return false;}
      if(rackFirst&&addPack()&&beginner)return validate(state,work).valid?work:null;
      for(let step=0;step<(beginner?1:55)&&work.rack.length;step++){if(extend()||(advanced&&(split()||freeJoker()||borrow())))continue;if(addPack())continue;break;}
      return validate(state,work).valid?work:null;
    }
    const a=solve(true),b=solve(false);if(!a)return b;if(!b)return a;
    return a.rack.length<=b.rack.length?a:b;
  }
  return{SUITS,KINGDOMS,tile,value,clone,flat,meld,arrange,create,draft,validate,invariant,commit,draw,timeout,dirty,move,autoConnect,candidates,pack,plan};

})();
const hash=t=>crypto.createHash('sha256').update(t).digest('hex');
class GameError extends Error {constructor(message,status=400){super(message);this.status=status;}}
function check(v,msg,status){if(!v)throw new GameError(msg,status);}
const realms=['Solea','Nokheim','Archeon','Verdan'];
function profile(input){check(input&&typeof input.name==='string','닉네임을 입력해 주세요.');const name=input.name.trim().replace(/[\u0000-\u001f\u007f]/g,'');check(name.length>=1&&name.length<=16,'닉네임은 1~16자로 입력해 주세요.');check(realms.includes(input.realm),'왕국을 선택해 주세요.');return{name,realm:input.realm};}
function freshGame(n){const s=R.create(1,n);delete s.seed;const pool=Array.from({length:106},(_,i)=>i);for(let i=105;i>0;i--){const j=crypto.randomInt(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}s.players=Array.from({length:n},()=>({tiles:pool.splice(-14),opened:false}));s.pool=pool;const ranks=Array.from({length:13},(_,i)=>i+1);s.starterDraw=Array.from({length:n},()=>ranks.splice(crypto.randomInt(ranks.length),1)[0]);s.current=s.starterDraw.indexOf(Math.max(...s.starterDraw));return s;}
class Rooms {
 constructor({now=()=>Date.now(),turnMs=60000,maxRooms=300}={}){this.rooms=new Map();this.now=now;this.turnMs=turnMs;this.maxRooms=maxRooms;}
 save(){}
 transaction(r,fn){const old=structuredClone(r);try{const result=fn();r.updated=this.now();this.save();return result;}catch(e){this.rooms.set(r.code,old);throw e;}}
 member(input){return{...profile(input),id:crypto.randomUUID(),tokenHash:'',ready:false,lastSeen:this.now()};}
 create(input){check(this.rooms.size<this.maxRooms,'현재 방이 가득 찼어요. 잠시 후 다시 시도하세요.',503);const m=this.member(input),token=crypto.randomBytes(32).toString('hex');m.tokenHash=hash(token);let code;do{code=crypto.randomBytes(4).toString('hex').toUpperCase();}while(this.rooms.has(code));const r={code,members:[m],host:m.id,revision:1,state:null,deadline:null,updated:this.now(),requests:[],events:['초대 방을 만들었어요.']};this.rooms.set(code,r);try{this.save();}catch(e){this.rooms.delete(code);throw e;}return{token,...this.snapshot(r,m)};}
 room(code){const r=this.rooms.get(code);check(r,'방을 찾을 수 없어요. 초대 코드를 확인해 주세요.',404);return r;}
 join(code,input){const r=this.room(code);check(!r.state,'이미 시작한 방이에요. 기존 참가자는 저장된 세션으로 복귀하세요.',409);check(r.members.length<4,'방이 가득 찼어요.',409);const m=this.member(input),token=crypto.randomBytes(32).toString('hex');m.tokenHash=hash(token);return this.transaction(r,()=>{r.members.push(m);r.revision++;r.events.unshift(m.name+' 님이 입장했어요.');return{token,...this.snapshot(r,m)};});}
 auth(code,token){check(typeof token==='string'&&/^[a-f0-9]{64}$/.test(token),'입장 정보가 없어요. 초대 링크로 다시 입장해 주세요.',401);const r=this.room(code),m=r.members.find(m=>m.tokenHash===hash(token));check(m,'이 방의 입장 정보가 아니에요.',401);if(this.now()-m.lastSeen>5000)m.lastSeen=this.now();return[r,m];}
 snapshot(r,m){const s=r.state;return{code:r.code,you:m.id,host:r.host,revision:r.revision,serverTime:this.now(),deadline:r.deadline,members:r.members.map(p=>({id:p.id,name:p.name,realm:p.realm,ready:p.ready,online:this.now()-p.lastSeen<12000})),events:r.events.slice(0,8),match:s?{phase:s.phase,current:s.current,turn:s.turn,board:structuredClone(s.board),poolCount:s.pool.length,players:s.players.map(p=>({count:p.tiles.length,opened:p.opened})),rack:[...s.players[r.members.indexOf(m)].tiles],winner:s.winner,scores:[...s.scores],lastPlayed:[...s.lastPlayed],starterDraw:[...s.starterDraw],lastAction:s.lastAction}:null};}
 action(code,token,input){const[r,m]=this.auth(code,token);check(input&&typeof input.requestId==='string'&&/^[a-zA-Z0-9-]{8,80}$/.test(input.requestId),'유효한 요청 ID가 필요해요.');const key=m.id+':'+input.requestId;if(r.requests.includes(key))return this.snapshot(r,m);check(Number.isInteger(input.revision),'유효한 상태 번호가 필요해요.');if(['commit','draw'].includes(input.type))check(input.revision===r.revision,'상태가 바뀌었어요. 최신 화면에서 다시 시도하세요.',409);
 return this.transaction(r,()=>{const type=input.type;
 if(type==='ready'){check(!r.state,'대전 중에는 준비 상태를 바꿀 수 없어요.',409);m.ready=!!input.ready;}
 else if(type==='start'){check(m.id===r.host,'방장만 시작할 수 있어요.',403);check(!r.state&&r.members.length>=2&&r.members.every(m=>m.ready),'두 명 이상 모두 준비해야 시작할 수 있어요.',409);r.state=freshGame(r.members.length);r.deadline=this.now()+this.turnMs;r.events.unshift('대전 시작 · '+r.members[r.state.current].name+' 님부터 시작해요.');}
 else if(type==='rematch'){check(m.id===r.host,'방장만 재대전을 준비할 수 있어요.',403);check(r.state&&r.state.phase!=='playing','대전 종료 후 다시 시작할 수 있어요.',409);r.state=null;r.deadline=null;r.members.forEach(p=>p.ready=false);r.events=['다시 준비하고 새 서약을 시작하세요.'];}
 else if(type==='leave'){check(!r.state,'대전 중에는 자리를 보존해요. 창을 닫아도 다시 접속할 수 있어요.',409);r.members=r.members.filter(p=>p.id!==m.id);if(r.host===m.id)r.host=r.members[0]?.id||null;}
 else {check(r.state?.phase==='playing','진행 중인 대전이 없어요.',409);check(r.members[r.state.current].id===m.id,'지금은 다른 플레이어의 턴이에요.',403);check(this.now()<r.deadline,'턴 시간이 끝났어요. 최신 상태를 확인해 주세요.',409);
 if(type==='commit'){const w=input.work;check(w&&Array.isArray(w.board)&&w.board.length<=106&&Array.isArray(w.rack)&&w.rack.length<=106&&w.rack.every(Number.isInteger)&&w.board.every(x=>x&&Array.isArray(x.tiles)&&x.tiles.length<=106&&x.tiles.every(Number.isInteger)),'카드 배치 형식이 올바르지 않아요.');const clean={board:w.board.map(x=>({tiles:x.tiles})),rack:w.rack};const result=R.commit(r.state,clean);check(result.valid,result.message);r.events.unshift(m.name+' · '+result.played.length+'장 연결');}
 else if(type==='draw'){R.draw(r.state);r.events.unshift(m.name+' · 카드 뽑기 / 패스');}
 else throw new GameError('지원하지 않는 요청이에요.');
 check(R.invariant(r.state),'카드 상태 검증에 실패했어요.',500);r.deadline=r.state.phase==='playing'?this.now()+this.turnMs:null;
 }
 r.events=r.events.slice(0,20);r.revision++;r.requests.push(key);r.requests=r.requests.slice(-512);return this.snapshot(r,m);
 });}
 tick(){let changed=false;for(const r of this.rooms.values()){
 if(r.updated<this.now()-86400000||!r.members.length){this.rooms.delete(r.code);changed=true;continue;}
 if(r.state?.phase==='playing'&&this.now()>=r.deadline){this.transaction(r,()=>{const name=r.members[r.state.current].name;R.draw(r.state,1,'timeout');r.events.unshift(name+' · 시간 만료, 카드 1장 뽑기');r.events=r.events.slice(0,20);r.revision++;r.deadline=r.state.phase==='playing'?this.now()+this.turnMs:null;});}
 }if(changed)this.save();}
}

function makeHandler(Rooms,GameError){
const reply=(status,data)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
return async function(request,env){
 const url=new URL(request.url);
 if(!url.pathname.startsWith('/api/'))return env.ASSETS.fetch(request);
 try{
  if(request.headers.get('Origin')&&request.headers.get('Origin')!==url.origin)throw new GameError('허용되지 않은 접속 주소예요.',403);
  if(!env.GAME_DB)throw new GameError('대전 서버를 준비 중입니다.',503);
  const db=env.GAME_DB;
  if(url.pathname==='/api/health')return reply(200,{ok:true,version:'0.21.0',multiplayer:true});
  const match=/^\/api\/rooms\/([A-F0-9]{8})(?:\/(join|action))?$/.exec(url.pathname);
  const create=request.method==='POST'&&url.pathname==='/api/rooms';
  if(!create&&!match)throw new GameError('주소를 찾을 수 없어요.',404);
  if(!['GET','POST'].includes(request.method)||(!create&&request.method==='POST'&&!match[2])||request.method==='GET'&&match?.[2])throw new GameError('허용되지 않은 요청이에요.',405);
  let input;
  if(request.method==='POST'){
   if(!request.headers.get('Content-Type')?.startsWith('application/json'))throw new GameError('JSON 요청이 필요해요.',415);
   const reader=request.body?.getReader();let size=0,chunks=[];if(!reader)throw new GameError('요청이 비어 있어요.');
   while(true){const{done,value}=await reader.read();if(done)break;size+=value.length;if(size>32768){await reader.cancel();throw new GameError('요청이 너무 커요.',413);}chunks.push(value);}
   const all=new Uint8Array(size);let at=0;for(const c of chunks){all.set(c,at);at+=c.length;}try{input=JSON.parse(new TextDecoder().decode(all));}catch{throw new GameError('요청을 읽을 수 없어요.');}
   const window=Math.floor(Date.now()/60000),key=(request.headers.get('CF-Connecting-IP')||'unknown')+':'+window;
   const rate=await db.prepare('INSERT INTO request_limits (key,n,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET n=n+1 RETURNING n').bind(key,Date.now()+120000).first();
   if(rate.n>90)throw new GameError('요청이 너무 많아요. 잠시 후 다시 시도하세요.',429);
  }
  if(create){
   await db.batch([db.prepare('DELETE FROM rooms WHERE expires < ?').bind(Date.now()),db.prepare('DELETE FROM request_limits WHERE expires < ?').bind(Date.now())]);
   if((await db.prepare('SELECT COUNT(*) AS n FROM rooms').first()).n>=300)throw new GameError('현재 방이 가득 찼어요.',503);
   for(let tries=0;tries<5;tries++){
    const rooms=new Rooms(),result=rooms.create(input),r=rooms.room(result.code);
    const saved=await db.prepare('INSERT OR IGNORE INTO rooms (code,body,version,expires) VALUES (?,?,1,?)').bind(r.code,JSON.stringify(r),r.updated+86400000).run();
    if(saved.meta.changes)return reply(201,result);
   }
   throw new GameError('방을 만들지 못했어요. 다시 시도해 주세요.',503);
  }
  const code=match[1],token=(request.headers.get('Authorization')||'').replace(/^Bearer /,'');
  for(let tries=0;tries<6;tries++){
   const row=await db.prepare('SELECT body,version,expires FROM rooms WHERE code=?').bind(code).first();
   if(!row||row.expires<Date.now())throw new GameError('방을 찾을 수 없어요.',404);
   const rooms=new Rooms();rooms.rooms.set(code,JSON.parse(row.body));rooms.tick();let result,error;
   try{if(match[2]==='join')result=rooms.join(code,input);else if(match[2]==='action')result=rooms.action(code,token,input);else{const[r,m]=rooms.auth(code,token);result=rooms.snapshot(r,m);}}catch(e){error=e;}
   const r=rooms.rooms.get(code);if(!r)throw new GameError('방이 종료됐어요.',404);
   const serialized=JSON.stringify(r);
   // Every accepted change, including presence, is committed against the read version.
   if(serialized!==row.body){const saved=await db.prepare('UPDATE rooms SET body=?,version=version+1,expires=? WHERE code=? AND version=?').bind(serialized,r.updated+86400000,code,row.version).run();if(!saved.meta.changes)continue;}
   if(error)throw error;return reply(200,result);
  }
  throw new GameError('동시에 요청이 도착했어요. 다시 시도해 주세요.',409);
 }catch(e){return reply(e.status||500,{error:e.status?e.message:'서버 처리에 실패했어요. 잠시 후 다시 시도하세요.'});}
};}

const handle=makeHandler(Rooms,GameError);
export default {fetch:handle};
