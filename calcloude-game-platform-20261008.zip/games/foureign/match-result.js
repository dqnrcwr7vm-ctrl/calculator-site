/* Pure result view shared by the game and local design preview. */
(function(root){
'use strict';
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function render({members,scores,winner,me,host,turn,mode,realmIcon=()=>''}){
 const outcome=winner<0?'draw':winner===me?'victory':'defeat';
 const realms={Solea:'솔레아',Nokheim:'노크하임',Archeon:'아르케온',Verdan:'베르단'};
 const mine=members[me],realm=realms[mine.realm]||'왕국';
 const title={victory:'승리',defeat:'패배',draw:'무승부'}[outcome];
 const message={victory:'당신의 선택이 왕국의 운명을 바꿨습니다.',defeat:'서약은 끝나지 않았습니다. 다음 승리를 준비하세요.',draw:'팽팽한 서약, 아직 끝나지 않은 이야기.'}[outcome];
 const emblem=outcome==='victory'?'<path d="M20 36 34 49 50 20 66 49 80 36 72 73H28Z"/><path d="M28 81H72M50 5V12M13 20 19 26M87 20 81 26"/>':'<path d="M50 12 79 24V49Q78 71 50 88Q22 71 21 49V24Z"/><path d="M50 28 62 49 50 70 38 49Z"/>';
 const order=members.map((member,i)=>({member,i,score:scores[i]??0})).sort((a,b)=>(b.i===winner)-(a.i===winner)||b.score-a.score);
 return `<div class="match-result ${outcome}" role="dialog" aria-modal="true" aria-labelledby="match-result-title" tabindex="-1"><div class="result-atmosphere" aria-hidden="true"></div><section class="result-panel"><div class="result-emblem" aria-hidden="true"><svg viewBox="0 0 100 100">${emblem}</svg></div><p class="result-eyebrow">${escape(realm)}의 서약 · ${mode==='practice'?'싱글 플레이':'멀티 플레이'}</p><h2 id="match-result-title">${title}</h2><p class="result-message">${message}</p><div class="result-divider" aria-hidden="true">◆</div><div class="result-summary"><h3>대전 결과</h3><span>${Number(turn)||0}번째 턴</span></div><ol class="result-scores">${order.map(({member,i,score})=>`<li class="${i===me?'is-me':''} ${i===winner?'is-winner':''}"><span class="result-realm" aria-hidden="true">${realmIcon(member.realm)}</span><span class="result-player"><strong>${escape(member.name)}${i===me?'<small>나</small>':''}</strong><span>${escape(realms[member.realm]||'왕국')}${i===winner?' · 승리':''}</span></span><strong class="result-score">${score>0?'+':''}${score}<small>점</small></strong></li>`).join('')}</ol><div class="result-actions">${host?`<button id="rematch" class="primary">${mode==='practice'?'다시 도전하기':'다시 함께하기'}</button>`:'<p class="result-wait" role="status">방장이 다음 대전을 준비하고 있어요.</p>'}<button id="result-menu" class="quiet">메인 메뉴로</button></div></section></div>`;
}
root.FoureignResult={render};
if(typeof module!=='undefined')module.exports={render};
})(typeof window!=='undefined'?window:globalThis);
