/* One speaking character at a time; fast combos retain only the newest request. */
(()=>{'use strict';
class FoureignCharacterVoices{
 constructor(catalog,{audio=new Audio(),now=()=>performance.now(),onStart=()=>{}}={}){this.audio=audio;this.now=now;this.onStart=onStart;this.cards=new Map((catalog?.cards||[]).map(c=>[c.id,c]));this.groups=new Map((catalog?.voiceGroups||[]).map(g=>[g.id,g]));this.next=new Map();this.lastFile='';this.pending=null;this.active=false;this.enabled=false;this.volume=.72;this.serial=0;this.events=0;this.lastCharacter='';this.lastLine='';this.error='';audio.preload='none';audio.onended=()=>this.finish();audio.onerror=()=>{this.error='캐릭터 음성을 불러오지 못했어요.';this.finish();};}
 configure(enabled,volume){this.enabled=enabled;this.volume=Math.max(0,Math.min(1,volume));this.audio.volume=this.volume;if(!enabled||this.volume===0)this.cancel();}
 options(id){const c=this.cards.get(id);if(!c)return[];return [c,...(this.groups.get(c.voiceGroup)?.sharedLines||[])].filter(l=>l.audio);}
 request(id){if(!this.enabled||!this.volume||!this.options(id).length)return false;if(this.active){this.pending={id,at:this.now()};return true;}this.begin(id);return true;}
 begin(id){const options=this.options(id);let index=(this.next.get(id)||0)%options.length;if(options.length>1&&options[index].audio===this.lastFile)index=(index+1)%options.length;const line=options[index];this.next.set(id,index+1);this.lastFile=line.audio;this.lastCharacter=id;this.lastLine=line.line;this.events++;this.error='';this.active=true;const token=++this.serial;this.audio.src=line.audio;this.audio.volume=this.volume;this.onStart(line.durationSeconds||2);Promise.resolve(this.audio.play()).catch(()=>{if(token===this.serial){this.error='캐릭터 음성을 재생하지 못했어요.';this.finish();}});}
 finish(){this.active=false;const pending=this.pending;this.pending=null;if(this.enabled&&pending&&this.now()-pending.at<=1400)this.begin(pending.id);}
 cancel(){this.serial++;this.pending=null;this.active=false;this.audio.pause();if(this.audio.readyState>0)this.audio.currentTime=0;}
 snapshot(){return{active:this.active,pending:this.pending?.id||null,character:this.lastCharacter,line:this.lastLine,events:this.events,error:this.error};}
}
window.FoureignCharacterVoices=FoureignCharacterVoices;
})();
