(function(root){
'use strict';
// Only legal, complete placements are highlighted; this never changes a hand.
function available(R,state,work){
 const result=new Set(),player=state.players[state.current];
 const check=next=>{
  if(!player.opened&&!R.validate(state,next).valid){
   const score=next.board.filter(m=>m.tiles.every(id=>player.tiles.includes(id))).reduce((n,m)=>n+R.meld(m.tiles).score,0);
   const extra=R.pack(next.rack,Math.max(0,30-score),120);
   next={board:next.board.concat(extra),rack:next.rack.filter(id=>!R.flat(extra).includes(id))};
  }
  return R.validate(state,next).valid;
 };
 for(const ids of R.candidates(work.rack)){
  const next=R.clone(work);if(R.move(state,next,ids,'new').valid&&check(next))ids.forEach(id=>result.add(id));
 }
 for(const id of work.rack){const next=R.autoConnect(state,work,[id]);if(next&&check(next))result.add(id);}
 // Both physical copies of the same card are interchangeable choices.
 const types=new Set([...result].map(id=>{const t=R.tile(id);return t.suit+':'+t.rank;}));
 for(const id of work.rack){const t=R.tile(id);if(types.has(t.suit+':'+t.rank))result.add(id);}
 return result;
}
class Feedback{
 constructor(){
  const layer=document.createElement('div');layer.id='fx-layer';layer.setAttribute('aria-hidden','true');const banner=document.createElement('div');banner.id='combo';banner.setAttribute('aria-hidden','true');document.body.append(layer,banner);
  this.sound=new root.TrumiSound();if(this.sound.characters){this.sound.characters.audio.id="character-voice";document.body.append(this.sound.characters.audio);}this.fx=new root.TrumiEffects(this.sound);this.focus=new root.TrumiBoardFocus();this.presenting=false;this.revision=0;this.done=Promise.resolve();
 }
 unlock(volume){this.sound.effectsVolume=volume;this.sound.sound=volume>0;this.sound.characters?.configure(volume>0,volume);if(this.sound.master)this.sound.master.gain.setTargetAtTime(volume,this.sound.ctx.currentTime,.02);this.sound.unlock();}
 clear(){this.revision++;this.presenting=false;this.focus.cancel();this.fx.cancel();this.sound.cancel();}
 play(ids,board,cards,actor,confirmed,chain=1){
  if(!ids.length)return Promise.resolve();this.clear();const revision=this.revision;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;this.fx.reduced=reduced;this.presenting=true;
  this.done=this.focus.show(ids,{reduced,onMove:()=>this.fx.cancel(),onGroup:(groupIds,index)=>{
   const n=confirmed?index:chain;this.fx.play(groupIds,n>1?'combo':'connect',n);
   if(confirmed)this.sound.characterTile(groupIds.at(-1));else this.fx.showcase(groupIds.at(-1),n);
  }}).finally(()=>{if(revision===this.revision)this.presenting=false;});return this.done;
 }
}
Feedback.available=available;root.FoureignFeedback=Feedback;
if(typeof module==='object')module.exports={available};
})(typeof window==='undefined'?globalThis:window);
