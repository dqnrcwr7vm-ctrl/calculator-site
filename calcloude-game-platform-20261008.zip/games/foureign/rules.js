(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.TrumiRules=api;})(typeof globalThis!=='undefined'?globalThis:this,()=>{
  'use strict';
  const SUITS=['♥','♠','♦','♣'],KINGDOMS=['Solea','Nokheim','Archeon','Verdan'];
  const clone=x=>JSON.parse(JSON.stringify(x));
  const tile=id=>({id,suit:id<104?Math.floor(id/26):-1,rank:id<104?id%13+1:0,joker:id>=104});
  const value=id=>id>=104?30:tile(id).rank;
  const signature=ids=>[...ids].sort((a,b)=>a-b).join(',');
  const flat=board=>board.flatMap(m=>m.tiles);
  function meld(ids){
    const bad=reason=>({valid:false,kind:'',score:0,reason,assignments:[]});
    if(ids.length<3)return bad('조합은 3장 이상이어야 해요.');
    if(ids.length>13)return bad('연속 조합은 최대 13장이에요.');
    if(new Set(ids).size!==ids.length||ids.some(id=>!Number.isInteger(id)||id<0||id>105))return bad('같은 카드가 중복되었어요.');
    const real=ids.map(tile).filter(t=>!t.joker),jokers=ids.filter(id=>id>=104);
    if(real.length===0)return bad('숫자 카드가 필요해요.');
    if(ids.length<=4&&real.every(t=>t.rank===real[0].rank)&&new Set(real.map(t=>t.suit)).size===real.length){
      const missing=[0,1,2,3].filter(s=>!real.some(t=>t.suit===s));
      return{valid:true,kind:'group',score:real[0].rank*ids.length,reason:'같은 숫자',assignments:jokers.map((id,i)=>({id,rank:real[0].rank,suit:missing[i]}))};
    }
    const first=ids.findIndex(id=>id<104),start=tile(ids[first]).rank-first;
    if(start<1||start+ids.length-1>13)return bad('A는 1이에요. K 다음에 A를 이을 수 없어요.');
    const suit=real[0].suit;
    if(ids.some((id,i)=>id<104&&(tile(id).suit!==suit||tile(id).rank!==start+i)))return bad('같은 문양의 연속 숫자 또는 서로 다른 문양의 같은 숫자로 연결하세요.');
    return{valid:true,kind:'run',score:ids.length*(2*start+ids.length-1)/2,reason:'연속 숫자',assignments:ids.flatMap((id,i)=>id>=104?[{id,rank:start+i,suit}]:[])};
  }
  function arrange(ids){
    if(meld(ids).valid)return [...ids];
    const real=ids.filter(id=>id<104),jokers=ids.filter(id=>id>=104);
    if(!real.length)return [...ids];
    const group=[...real].sort((a,b)=>tile(a).suit-tile(b).suit).concat(jokers);
    if(meld(group).valid)return group;
    if(real.every(id=>tile(id).suit===tile(real[0]).suit)&&new Set(real.map(id=>tile(id).rank)).size===real.length){
      for(let start=14-ids.length;start>=1;start--){
        if(real.some(id=>tile(id).rank<start||tile(id).rank>=start+ids.length))continue;
        const unused=[...jokers],run=[];
        for(let rank=start;rank<start+ids.length;rank++)run.push(real.find(id=>tile(id).rank===rank)??unused.shift());
        if(run.every(id=>id!==undefined)&&meld(run).valid)return run;
      }
    }
    return [...ids];
  }
  function create(seed=Date.now()>>>0,playerCount=4){
    if(!Number.isInteger(playerCount)||playerCount<2||playerCount>4)throw Error("2–4 players required");
    let x=(seed>>>0)||1;const next=n=>{x^=x<<13;x^=x>>>17;x^=x<<5;return(x>>>0)%n;};
    let starterDraw;do{starterDraw=Array.from({length:playerCount},()=>next(13)+1);}while(new Set(starterDraw).size!==playerCount);
    const pool=Array.from({length:106},(_,i)=>i);
    for(let i=pool.length-1;i>0;i--){const j=next(i+1);[pool[i],pool[j]]=[pool[j],pool[i]];}
    const players=Array.from({length:playerCount},(_,i)=>i).map(()=>({tiles:pool.splice(pool.length-14,14),opened:false}));
    return{version:1,seed:seed>>>0,players,pool,board:[],current:starterDraw.indexOf(Math.max(...starterDraw)),turn:1,passes:0,phase:'playing',winner:-1,scores:Array(playerCount).fill(0),starterDraw,lastPlayed:[],lastAction:'start',lastActor:-1};
  }
  const draft=state=>({board:clone(state.board),rack:[...state.players[state.current].tiles]});
  function validate(state,work){
    const fail=(code,message)=>({valid:false,code,message,played:[],points:0,sets:0});
    if(state.phase!=='playing')return fail('finished','이미 끝난 대전이에요.');
    const original=state.players[state.current].tiles,old=flat(state.board),now=flat(work.board),all=now.concat(work.rack),expected=old.concat(original);
    if(all.length!==expected.length||new Set(all).size!==all.length||signature(all)!==signature(expected))return fail('inventory','카드가 빠졌거나 중복되었어요. 턴을 되돌려 주세요.');
    if(old.some(id=>work.rack.includes(id)))return fail('table_to_rack','이미 등록된 카드를 손패로 가져올 수 없어요.');
    const played=original.filter(id=>!work.rack.includes(id));
    if(played.length===0)return fail('no_play','자기 카드를 1장 이상 놓거나 1장을 뽑으세요.');
    const sets=work.board.filter(m=>m.tiles.length);
    for(let i=0;i<sets.length;i++){const check=meld(sets[i].tiles);if(!check.valid)return fail('invalid_meld',(i+1)+'번 조합: '+check.reason);}
    let points=played.reduce((s,id)=>s+(id<104?value(id):0),0);
    if(!state.players[state.current].opened){
      const oldKeys=state.board.map(m=>signature(m.tiles));
      if(oldKeys.some(key=>!sets.some(m=>signature(m.tiles)===key)))return fail('initial_table','첫 등록에서는 기존 보드를 바꿀 수 없어요.');
      const fresh=sets.filter(m=>!oldKeys.includes(signature(m.tiles)));
      if(fresh.some(m=>m.tiles.some(id=>!original.includes(id))))return fail('initial_table','첫 등록은 자기 손패만으로 만들어야 해요.');
      points=fresh.reduce((sum,m)=>sum+meld(m.tiles).score,0);
      if(points<30)return fail('initial_points','첫 등록은 합계 30점 이상이에요. 지금은 '+points+'점이에요.');
    }
    return{valid:true,code:'ok',message:played.length+'장 연결 가능',played,points,sets:sets.filter(m=>m.tiles.some(id=>played.includes(id))).length};
  }
  function invariant(state){
    if(!state||!Array.isArray(state.players)||state.players.length<2||state.players.length>4||!Number.isInteger(state.current)||state.current<0||state.current>=state.players.length)return false;
    const ids=state.pool.concat(...state.players.map(p=>p.tiles),flat(state.board));
    return ids.length===106&&new Set(ids).size===106&&ids.every(id=>Number.isInteger(id)&&id>=0&&id<106)&&state.board.every(m=>meld(m.tiles).valid);
  }
  function finish(state,winner,blocked=false){
    state.phase=blocked?'blocked':'won';state.winner=winner;
    const sums=state.players.map(p=>p.tiles.reduce((a,id)=>a+value(id),0));
    state.scores=Array(sums.length).fill(0);
    if(winner>=0){for(let i=0;i<sums.length;i++)if(i!==winner){const loss=blocked?sums[i]-sums[winner]:sums[i];state.scores[i]=-loss;state.scores[winner]+=loss;}}
  }
  function commit(state,work){
    const result=validate(state,work);if(!result.valid)return result;
    const actor=state.current;state.board=clone(work.board.filter(m=>m.tiles.length));state.players[actor].tiles=[...work.rack];state.players[actor].opened=true;
    state.lastPlayed=[...result.played];state.lastAction='play';state.lastActor=actor;state.passes=0;
    if(work.rack.length===0)finish(state,actor);else{state.current=(actor+1)%state.players.length;state.turn++;}
    return result;
  }
  function draw(state,count=1,reason='draw'){
    if(state.phase!=='playing')return[];
    const actor=state.current,drawn=[];
    for(let i=0;i<count&&state.pool.length;i++)drawn.push(state.pool.pop());
    state.players[actor].tiles.push(...drawn);state.lastPlayed=[];state.lastAction=drawn.length?reason:'pass';state.lastActor=actor;
    state.passes=drawn.length?0:state.passes+1;
    if(state.passes>=state.players.length){const sums=state.players.map(p=>p.tiles.reduce((s,id)=>s+value(id),0)),min=Math.min(...sums),winners=sums.map((n,i)=>n===min?i:-1).filter(i=>i>=0);finish(state,winners.length===1?winners[0]:-1,true);}
    else{state.current=(actor+1)%state.players.length;state.turn++;}
    return drawn;
  }
  const dirty=(state,work)=>JSON.stringify(state.board)!==JSON.stringify(work.board)||signature(state.players[state.current].tiles)!==signature(work.rack);
  function timeout(state,work){const count=dirty(state,work)&&!validate(state,work).valid?3:1;return{count,drawn:draw(state,count,count===3?'penalty':'timeout')};}
  function move(state,work,ids,target,index=-1){
    if(state.phase!=='playing')return{valid:false,message:'이미 끝난 대전이에요.'};
    if(target!=='rack'&&target!=='new'&&(!Number.isInteger(target)||target<0||target>=work.board.length))return{valid:false,message:'조합을 다시 선택하세요.'};
    ids=[...new Set(ids)];if(!ids.length)return{valid:false,message:'옮길 카드를 선택하세요.'};
    const originalRack=state.players[state.current].tiles;
    if(ids.some(id=>!work.rack.includes(id)&&!flat(work.board).includes(id)))return{valid:false,message:'현재 턴의 카드가 아니에요.'};
    if(!state.players[state.current].opened&&ids.some(id=>!originalRack.includes(id)))return{valid:false,message:'첫 등록 후에 보드를 재배치할 수 있어요.'};
    if(target==='rack'&&ids.some(id=>!originalRack.includes(id)))return{valid:false,message:'등록된 카드는 손패로 가져올 수 없어요.'};
    if(typeof target==='number'&&(target<0||target>=work.board.length))return{valid:false,message:'조합을 다시 선택하세요.'};
    if(typeof target==='number'&&!state.players[state.current].opened&&work.board[target].tiles.some(id=>!originalRack.includes(id)))return{valid:false,message:'첫 등록은 새로운 조합으로 만드세요.'};
    let at=index;
    if(typeof target==='number'&&at>=0)at-=work.board[target].tiles.slice(0,at).filter(id=>ids.includes(id)).length;
    work.rack=work.rack.filter(id=>!ids.includes(id));for(const m of work.board)m.tiles=m.tiles.filter(id=>!ids.includes(id));
    if(target==='rack')work.rack.push(...ids);
    else if(target==='new')work.board.push({tiles:arrange(ids)});
    else{const list=work.board[target].tiles;list.splice(at<0?list.length:Math.min(at,list.length),0,...ids);}
    // Empty trays are only temporary drop targets; no tile is discarded.
    return{valid:true,message:'배치했어요.'};
  }
  function autoConnect(state,work,ids){
    ids=[...new Set(ids)];
    if(!ids.length||ids.some(id=>!work.rack.includes(id)))return null;
    // Only the explicitly selected cards are moved; never search the rest of the hand.
    const original=state.players[state.current];
    const fresh=arrange(ids);
    if(meld(fresh).valid){const next=clone(work);if(move(state,next,ids,'new').valid)return next;}
    for(let i=0;i<work.board.length;i++){
      const base=work.board[i].tiles;if(!base.length||!meld(base).valid)continue;
      if(!original.opened&&base.some(id=>!original.tiles.includes(id)))continue;
      const joined=arrange(base.concat(ids));if(!meld(joined).valid)continue;
      const next=clone(work);if(!move(state,next,ids,i).valid)continue;
      next.board[i].tiles=joined;return next;
    }
    return null;
  }
  function candidates(rack){
    const result=[],seen=new Set(),jokers=rack.filter(id=>id>=104),by=Array.from({length:4},()=>Array.from({length:14},()=>[]));
    for(const id of rack)if(id<104){const t=tile(id);by[t.suit][t.rank].push(id);}
    const add=ids=>{const key=ids.join(',');if(!seen.has(key)&&meld(ids).valid){seen.add(key);result.push(ids);}};
    for(let rank=1;rank<=13;rank++){
      const present=[0,1,2,3].filter(s=>by[s][rank].length);
      for(let mask=1;mask<(1<<present.length);mask++){
        const ids=present.filter((_,i)=>mask&(1<<i)).map(s=>by[s][rank][0]);
        for(let j=0;j<=jokers.length;j++)if(ids.length+j>=3&&ids.length+j<=4)add(ids.concat(jokers.slice(0,j)));
      }
    }
    for(let suit=0;suit<4;suit++)for(let start=1;start<=11;start++)for(let end=start+2;end<=13;end++){
      const ids=[],unused=[...jokers];let ok=true;
      for(let rank=start;rank<=end;rank++){if(by[suit][rank].length)ids.push(by[suit][rank][0]);else if(unused.length)ids.push(unused.shift());else{ok=false;break;}}
      if(ok)add(ids);
    }
    return result.sort((a,b)=>b.length-a.length||meld(b).score-meld(a).score||signature(a).localeCompare(signature(b)));
  }
  function pack(rack,minimum=0,budget=700){
    let best=[],bestWeight=-1,nodes=0;const visited=new Set();
    function visit(left,sets,points){
      if(++nodes>budget)return;
      const played=rack.length-left.length,weight=played*100+points;
      if(points>=minimum&&played&&weight>bestWeight){best=clone(sets);bestWeight=weight;}
      const key=signature(left)+':'+Math.min(points,minimum);if(visited.has(key))return;visited.add(key);
      for(const ids of candidates(left).slice(0,18))visit(left.filter(id=>!ids.includes(id)),sets.concat([{tiles:ids}]),points+meld(ids).score);
    }
    visit([...rack],[],0);return best;
  }
  function plan(state,difficulty='advanced'){
    const beginner=difficulty==='beginner',advanced=difficulty==='advanced';
    if(state.phase!=='playing')return null;
    const player=state.players[state.current];
    if(!player.opened){const sets=pack(player.tiles,30,beginner?80:advanced?700:250);if(!sets.length)return null;const used=flat(sets),work={board:clone(state.board).concat(sets),rack:player.tiles.filter(id=>!used.includes(id))};return validate(state,work).valid?work:null;}
    function solve(rackFirst){
      const work=draft(state);
      function addPack(){const sets=beginner?candidates(work.rack).slice(0,1).map(tiles=>({tiles})):pack(work.rack,0,advanced?250:120);if(!sets.length)return false;const used=flat(sets);work.rack=work.rack.filter(id=>!used.includes(id));work.board.push(...sets);return true;}
      function extend(){for(const id of work.rack)for(const m of work.board)for(let at=0;at<=m.tiles.length;at++){const ids=[...m.tiles];ids.splice(at,0,id);if(meld(ids).valid){m.tiles=ids;work.rack=work.rack.filter(x=>x!==id);return true;}}return false;}
      function split(){for(let mi=0;mi<work.board.length;mi++){const m=work.board[mi];if(meld(m.tiles).kind!=='run'||m.tiles.length<5)continue;for(let cut=2;cut<=m.tiles.length-2;cut++)for(const id of work.rack)for(let side=0;side<2;side++){
        const parts=[m.tiles.slice(0,cut),m.tiles.slice(cut)];parts[side]=arrange(parts[side].concat(id));
        if(parts.every(p=>meld(p).valid)){work.board.splice(mi,1,...parts.map(tiles=>({tiles})));work.rack=work.rack.filter(x=>x!==id);return true;}
      }}return false;}
      function borrow(){for(const m of work.board)for(const loan of m.tiles){const rest=m.tiles.filter(x=>x!==loan);if(!meld(rest).valid)continue;const set=candidates(work.rack.concat(loan)).find(ids=>ids.includes(loan)&&ids.filter(id=>work.rack.includes(id)).length>=2);if(set){m.tiles=rest;work.rack=work.rack.filter(id=>!set.includes(id));work.board.push({tiles:set});return true;}}return false;}
      function freeJoker(){for(const m of work.board)for(let at=0;at<m.tiles.length;at++)if(m.tiles[at]>=104)for(const replacement of work.rack.filter(id=>id<104)){
        const copy=[...m.tiles],joker=copy[at];copy[at]=replacement;if(!meld(copy).valid)continue;
        const available=work.rack.filter(id=>id!==replacement).concat(joker),set=candidates(available).find(ids=>ids.includes(joker));
        if(set){m.tiles=copy;work.rack=work.rack.filter(id=>id!==replacement&&!set.includes(id));work.board.push({tiles:set});return true;}
      }return false;}
      if(rackFirst&&addPack()&&beginner)return validate(state,work).valid?work:null;
      for(let step=0;step<(beginner?1:55)&&work.rack.length;step++){if(extend()||(advanced&&(split()||freeJoker()||borrow())))continue;if(addPack())continue;break;}
      return validate(state,work).valid?work:null;
    }
    const a=solve(true),b=solve(false);if(!a)return b;if(!b)return a;
    return a.rack.length<=b.rack.length?a:b;
  }
  return{SUITS,KINGDOMS,tile,value,clone,flat,meld,arrange,create,draft,validate,invariant,commit,draw,timeout,dirty,move,autoConnect,candidates,pack,plan};
});
