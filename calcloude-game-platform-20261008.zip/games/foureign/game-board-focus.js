/* One presentation at a time; pause/new match invalidate the whole sequence. */
(() => {
 class TrumiBoardFocus {
  constructor(){this.revision=0;this.visited=[];this.current=-1;}
  cancel(){this.revision++;this.current=-1;document.querySelectorAll('.meld.followed').forEach(e=>e.classList.remove('followed'));}
  wait(ms,revision){return new Promise(resolve=>{const start=performance.now();const tick=()=>{if(revision!==this.revision)return resolve(false);if(performance.now()-start>=ms)return resolve(true);requestAnimationFrame(tick);};tick();});}
  pan(jobs,reduced,revision){return new Promise(resolve=>{const start=performance.now(),duration=reduced?0:320;const tick=()=>{if(revision!==this.revision)return resolve(false);const t=duration?Math.min(1,(performance.now()-start)/duration):1,u=1-Math.pow(1-t,3);for(const job of jobs)job.set(job.from+(job.to-job.from)*u);if(t<1)requestAnimationFrame(tick);else resolve(true);};tick();});}
  async show(ids,{reduced,onGroup,onMove}){
   this.cancel();const revision=this.revision;this.visited=[];
   const board=document.getElementById('field'),groups=[...board.querySelectorAll('.meld')].filter(g=>ids.some(id=>g.querySelector(`[data-id="${id}"]`))).map(g=>g.dataset.drop);
   for(let i=0;i<groups.length;i++){
    if(revision!==this.revision)return false;onMove?.();
    const group=board.querySelector(`.meld[data-drop="${groups[i]}"]`),cards=ids.filter(id=>group.querySelector(`[data-id="${id}"]`)),row=group.querySelector('.meld-cards');
    document.querySelectorAll('.meld.followed').forEach(e=>e.classList.remove('followed'));group.classList.add('followed');this.current=Number(group.dataset.drop);
    const b=board.getBoundingClientRect(),g=group.getBoundingClientRect(),target=Math.max(0,Math.min(board.scrollHeight-board.clientHeight,board.scrollTop+g.top-b.top-(board.clientHeight-g.height)/2));
    const jobs=[{from:board.scrollTop,to:target,set:v=>board.scrollTop=v}];
    const touched=cards.map(id=>row.querySelector(`[data-id="${id}"]`).getBoundingClientRect()),r=row.getBoundingClientRect(),left=Math.min(...touched.map(x=>x.left)),right=Math.max(...touched.map(x=>x.right));
    if(left<r.left+6||right>r.right-6)jobs.push({from:row.scrollLeft,to:Math.max(0,Math.min(row.scrollWidth-row.clientWidth,row.scrollLeft+(left+right)/2-r.left-row.clientWidth/2)),set:v=>row.scrollLeft=v});
    if(b.top<25||b.bottom>innerHeight-30){const pageY=Math.max(0,Math.min(document.documentElement.scrollHeight-innerHeight,scrollY+b.top-(innerHeight-b.height)/2));jobs.push({from:scrollY,to:pageY,set:v=>window.scrollTo(0,v)});}
    if(!await this.pan(jobs,reduced,revision))return false;
    this.visited.push(this.current);onGroup(cards,i+1,groups.length);
    if(!await this.wait(reduced?550:i?1200:1000,revision))return false;
   }
   if(revision!==this.revision)return false;this.current=-1;document.querySelectorAll('.meld.followed').forEach(e=>e.classList.remove('followed'));return true;
  }
 }
 window.TrumiBoardFocus=TrumiBoardFocus;
})();
