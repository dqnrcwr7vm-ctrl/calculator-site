(()=>{'use strict';
const mobile=location.pathname.includes('/mobile/');
if(!mobile)return;
document.body.classList.add('mobile-game');
let hold=null,suppressUntil=0,start=null,detail=null,zoomed=false;
const clear=()=>{clearTimeout(hold);hold=null;};
document.addEventListener('pointerdown',e=>{
 const card=e.target.closest('.match [data-card]');if(!card||e.button!==0)return;
 start={x:e.clientX,y:e.clientY};clear();
 hold=setTimeout(()=>{suppressUntil=Date.now()+800;detail?.(Number(card.dataset.card));},550);
},{passive:true});
document.addEventListener('pointermove',e=>{if(start&&Math.hypot(e.clientX-start.x,e.clientY-start.y)>10)clear();},{passive:true});
for(const type of ['pointerup','pointercancel'])document.addEventListener(type,clear,{passive:true});
document.addEventListener('click',e=>{if(Date.now()<suppressUntil&&e.target.closest('[data-card]')){e.preventDefault();e.stopImmediatePropagation();}},true);
document.addEventListener('contextmenu',e=>{if(e.target.closest('.match [data-card]'))e.preventDefault();});
window.FoureignMobile={
 enhance({move,showDetail,selected,canPlay,autoConnect}){
  clear();detail=showDetail;
  const field=document.getElementById('field'),rack=document.getElementById('rack');
  document.querySelectorAll('[data-card]').forEach(card=>{card.draggable=false;});
  // Tap a group to place selected cards; its header also remains a keyboard target.
  field.onclick=e=>{
   if(!canPlay||!selected||e.target.closest('button'))return;
   const group=e.target.closest('[data-drop]');if(group)move(group.dataset.drop);
  };
  document.querySelectorAll('.meld .card').forEach(card=>{
   card.addEventListener('click',e=>{if(selected&&canPlay){e.stopImmediatePropagation();move(card.closest('.meld').dataset.drop);}},true);
  });
  const tools=document.querySelector('.board-tools');
  const tip=tools.querySelector('span');tip.textContent=selected?`${selected}장 선택 · 조합을 누르거나 새 조합`:'카드 선택 → 조합 터치 · 길게 눌러 상세';
  tip.setAttribute('role','status');
  const connect=document.createElement('button');connect.id='mobile-connect';connect.textContent='자동 연결';connect.disabled=!canPlay||!selected;connect.onclick=autoConnect;tools.prepend(connect);
  field.classList.toggle('mobile-field-large',zoomed);
  const zoom=document.createElement('button');zoom.id='mobile-field-size';zoom.className='quiet';zoom.textContent=zoomed?'필드 축소':'필드 확대';zoom.setAttribute('aria-pressed',String(zoomed));
  zoom.onclick=()=>{const large=field.classList.toggle('mobile-field-large');zoomed=large;zoom.textContent=large?'필드 축소':'필드 확대';zoom.setAttribute('aria-pressed',String(large));};
  document.querySelector('.match-info').append(zoom);
  rack.setAttribute('aria-label','손패 · 좌우로 넘기기 · 카드를 길게 누르면 상세');
 }
};
})();
