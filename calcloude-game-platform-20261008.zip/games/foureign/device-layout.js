/* Shared routing for the platform launcher and direct game links. */
(function(root){
 'use strict';
 function choose({override,saved,width,coarse,mobileUA}){
  if(override==='mobile'||override==='desktop')return override;
  if(saved==='mobile'||saved==='desktop')return saved;
  return mobileUA||(coarse&&width<=1100)?'mobile':'desktop';
 }
 const base='/games/foureign/';
 function path(layout){return base+(layout==='mobile'?'mobile/':'');}
 if(typeof module==='object'&&module.exports){module.exports={choose,path};return;}
 const url=new URL(location.href);let saved;
 try{saved=localStorage.getItem('foureign.layout');}catch{}
 const override=url.searchParams.get('view');
 const current=choose({override,saved,width:innerWidth,coarse:matchMedia('(pointer:coarse)').matches,mobileUA:/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)});
 if(override==='mobile'||override==='desktop'){try{localStorage.setItem('foureign.layout',override);}catch{}}
 root.FoureignLayout={current,path,choose};
 // A direct mobile URL explicitly requests that interface. Shared invitations retain their query.
 if(url.pathname===base||url.pathname===base+'index.html'){
  if(current==='mobile')location.replace(path('mobile')+url.search+url.hash);
 }else if(url.pathname.startsWith(base+'mobile/')&&override==='desktop')location.replace(path('desktop')+url.search+url.hash);
})(typeof window!=='undefined'?window:globalThis);
