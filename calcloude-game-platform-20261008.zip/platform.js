'use strict';
const details=document.getElementById('details');
document.getElementById('details-open').onclick=()=>details.showModal();
document.getElementById('details-close').onclick=()=>details.close();
