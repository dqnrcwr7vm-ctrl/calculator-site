const regions={
 village:{title:'마을',type:'',report:'장비를 강화하고 외관을 업그레이드 하세요. 랭킹을 확인하고 길드 업무를 진행 할 수 있습니다.',note:''},
 infinite:{title:'무한던전',type:'',report:'끝없이 이어지는 층계를 오르며 한계에 도전하세요. 시즌 진행 시 입장할 수 있습니다.',note:''},
 contract:{title:'의뢰 던전',type:'',report:'동료와 던전을 클리어하고 마을을 지키세요',note:'입장 후 파티를 생성하거나 참가합니다.'},
 normal:{title:'일반 던전',type:'',report:'혼자 던전을 탐험하고 전투와 전리품 선택을 진행하세요.',note:''}
};
const panel=document.querySelector('.dossier');
const lobby=document.querySelector('.lobby');
const map=document.querySelector('.map');
const markers=[...map.querySelectorAll('.marker')];
const heading=document.getElementById('destination-name');
let selectedMarker=markers[0],hoveredMarker=null,keyboardMode=false;
let reportTrigger=null;
function updateDestination(){
 const marker=keyboardMode?selectedMarker:hoveredMarker||selectedMarker;
 heading.textContent=marker?regions[marker.dataset.region].title.replace(' ',''):'';
 heading.dataset.visible=String(!!marker);
}
function selectRegion(marker,focus=false){
 if(!markers.includes(marker))return;
 selectedMarker=marker;
 for(const item of markers){
  item.classList.toggle('selected',item===marker);
  item.classList.toggle('keyboard-current',item===marker&&keyboardMode);
  item.setAttribute('aria-pressed',String(item===marker));
 }
 updateDestination();
 if(focus)marker.focus({preventScroll:true});
}
function closeReport(){panel.hidden=true;(reportTrigger||selectedMarker)?.focus({preventScroll:true});}
function showReport(){
 panel.hidden=false;
 const entry=document.getElementById('enter');
 (keyboardMode&&!entry.hidden?entry:panel.querySelector('.dossier-close')).focus({preventScroll:true});
}
for(const marker of markers)marker.addEventListener('click',()=>{
 reportTrigger=marker;
 const key=marker.dataset.region,r=regions[key];
 selectRegion(marker);
 document.getElementById('region-title').textContent=r.title;document.getElementById('region-type').textContent=r.type;document.getElementById('report').textContent=r.report;document.getElementById('entry-note').textContent=r.note;panel.classList.toggle('contract-report',key==='contract');
 const entry=document.getElementById('enter');entry.hidden=key==='infinite';entry.href=key==='village'?'town.html':key==='contract'?'../contract-dungeon/index.html':'../battle/normal-entry.html?v=portraits-20261030';entry.textContent=key==='village'?'마을 입장 →':key==='contract'?'입장하기 →':'던전 입장 →';
 document.getElementById('region-type').hidden=!r.type;
 document.getElementById('entry-note').hidden=!r.note;
 document.getElementById('report').hidden=!r.report;
 const extra=document.getElementById('region-extra');extra.replaceChildren();
 if(key==='infinite'){const badge=document.createElement('p');badge.className='locked-badge';badge.textContent='◇ 시즌 진행 시 오픈';extra.append(badge);}
 if(key==='contract'){extra.innerHTML='<p class="contract-description">파티를 만들거나 초대코드로 합류해<br>강력한 마물을 함께 토벌하세요.</p><p class="contract-capacity">최대 4인 · 협동 플레이</p>';}
 showReport();
});
document.querySelector('.dossier-close').addEventListener('click',closeReport);

markers.forEach(marker=>{
 marker.addEventListener('pointerdown',()=>{keyboardMode=false;selectRegion(marker);});
 marker.addEventListener('pointerenter',event=>{
  if(event.pointerType!=='touch'){hoveredMarker=marker;keyboardMode=false;selectRegion(selectedMarker);}
 });
 marker.addEventListener('pointerleave',()=>{if(hoveredMarker===marker)hoveredMarker=null;updateDestination();});
 marker.addEventListener('focus',()=>selectRegion(marker));
});

// Follow the map's actual screen geometry, rather than the HTML source order.
function regionInDirection(key){
 const horizontal=key==='ArrowLeft'||key==='ArrowRight';
 const sign=key==='ArrowLeft'||key==='ArrowUp'?-1:1;
 const origin=selectedMarker.getBoundingClientRect();
 let best=selectedMarker,score=Infinity;
 for(const marker of markers){
  if(marker===selectedMarker||marker.disabled||!marker.getClientRects().length)continue;
  const rect=marker.getBoundingClientRect();
  const dx=rect.x+rect.width/2-origin.x-origin.width/2;
  const dy=rect.y+rect.height/2-origin.y-origin.height/2;
  const forward=(horizontal?dx:dy)*sign,side=Math.abs(horizontal?dy:dx);
  if(forward<=1||forward<side)continue;
  const distance=forward+side*3;
  if(distance<score){score=distance;best=marker;}
 }
 return best;
}
document.addEventListener('keydown',event=>{
 if(event.defaultPrevented||event.isComposing||event.altKey||event.ctrlKey||event.metaKey||event.shiftKey)return;
 if(lobby.inert||map.inert||lobby.dataset.phase!=='ready'||document.querySelector('dialog[open]'))return;
 if(event.target.closest('input,textarea,select,[contenteditable="true"]'))return;
 const direction={ArrowUp:-1,ArrowLeft:-1,ArrowDown:1,ArrowRight:1}[event.key];
 if(!panel.hidden){
  if(event.key==='Escape'){
   event.preventDefault();keyboardMode=true;closeReport();return;
  }
  const controls=[...panel.querySelectorAll('button:not(:disabled),a[href]')].filter(item=>!item.hidden&&item.getClientRects().length);
  if(direction&&controls.length){
   event.preventDefault();keyboardMode=true;
   const index=controls.indexOf(document.activeElement);
   controls[(index+direction+controls.length)%controls.length].focus();
  }else if(event.key==='Enter'&&event.repeat)event.preventDefault();
  return;
 }
 if(direction){
  event.preventDefault();keyboardMode=true;selectRegion(regionInDirection(event.key),true);
 }else if(event.key==='Enter'&&(markers.includes(document.activeElement)||document.activeElement===document.body)){
  event.preventDefault();
  if(!event.repeat){keyboardMode=true;selectRegion(selectedMarker);selectedMarker.click();}
 }
});
lobby.addEventListener('lobbymapready',()=>{
 if(lobby.inert||!panel.hidden)return;
 keyboardMode=true;selectRegion(selectedMarker,true);
});

// Confirm the logo's existing return navigation using the shared popup.
document.querySelector('.game-brand').addEventListener('click',event=>{
 if(event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
 event.preventDefault();
 reportTrigger=event.currentTarget;
 panel.classList.remove('contract-report');
 document.getElementById('region-title').textContent='로비로';
 document.getElementById('region-type').hidden=true;
 const report=document.getElementById('report');report.hidden=false;report.textContent='시작 화면으로 돌아가시겠습니까?';
 document.getElementById('region-extra').replaceChildren();
 document.getElementById('entry-note').hidden=true;
 const entry=document.getElementById('enter');entry.hidden=false;entry.href=event.currentTarget.href;entry.textContent='로비로 →';
 showReport();
});
