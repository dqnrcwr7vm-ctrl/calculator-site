(() => {
  const W=1672,H=941,canvas=document.getElementById('map-canvas'),ctx=canvas.getContext('2d');
  const root=document.querySelector('.lobby'),map=document.querySelector('.map'),markers=[...map.querySelectorAll('.marker')];
  const status=document.getElementById('intro-status'),skip=document.getElementById('skip-intro');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let desk,paper,paperBounds,raf=0,start=0,ready=false;
  const bounds={x:232,y:92,w:1210,h:710};
  const clamp=x=>Math.max(0,Math.min(1,x));
  const ease=x=>1-Math.pow(1-clamp(x),3);
  async function load(src){const im=new Image();im.src=src;await im.decode();return im;}
  function alphaBounds(im){
    const c=document.createElement('canvas');c.width=im.width;c.height=im.height;const g=c.getContext('2d',{willReadFrequently:true});g.drawImage(im,0,0);
    const pixels=g.getImageData(0,0,c.width,c.height).data;let x0=c.width,y0=c.height,x1=0,y1=0;
    for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(pixels[(y*c.width+x)*4+3]>30){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);}
    return{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
  }
  function drawMap(){
    ctx.clearRect(0,0,W,H);ctx.imageSmoothingEnabled=false;ctx.drawImage(desk,0,0,W,H);
    ctx.save();
    ctx.shadowColor='#140d08aa';ctx.shadowBlur=12;ctx.shadowOffsetY=8;
    ctx.drawImage(paper,paperBounds.x,paperBounds.y,paperBounds.w,paperBounds.h,bounds.x,bounds.y,bounds.w,bounds.h);ctx.restore();
    // Foreground sword stays in front of the open parchment.
    ctx.save();ctx.beginPath();ctx.moveTo(0,812);ctx.lineTo(973,812);ctx.lineTo(977,793);ctx.lineTo(968,779);ctx.lineTo(984,766);ctx.lineTo(989,766);ctx.lineTo(1004,779);ctx.lineTo(997,793);ctx.lineTo(999,812);ctx.lineTo(W,812);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.closePath();ctx.clip();ctx.drawImage(desk,0,0,W,H);ctx.restore();
  }
  function frame(ms){
    const wasReady=ready;
    markers.forEach((m,i)=>{
      const p=clamp((ms-180-i*130)/650);
      const y=-95*(1-ease(p))+6*Math.sin(Math.PI*p);
      m.style.opacity=String(clamp(p*4));m.style.translate=`0 ${y}px`;m.style.scale='1';
    });
    ready=ms>=1300;root.dataset.phase=ready?'ready':'revealing';
    map.inert=!ready;skip.hidden=ready;status.hidden=true;
    if(ready&&!wasReady)root.dispatchEvent(new Event('lobbymapready'));
  }
  function tick(now){const ms=now-start;frame(ms);if(ms<1350)raf=requestAnimationFrame(tick);}
  function play(){if(!desk||!paper)return;cancelAnimationFrame(raf);ready=false;root.dataset.phase='revealing';map.inert=true;document.querySelector('.dossier').hidden=true;drawMap();
    if(reduced.matches){frame(2000);return;}start=performance.now();frame(0);raf=requestAnimationFrame(tick);
  }
  function finish(){if(!paper)return;cancelAnimationFrame(raf);frame(2000);}
  document.getElementById('replay-intro').addEventListener('click',play);skip.addEventListener('click',finish);
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&!ready)finish();});
  reduced.addEventListener('change',()=>{if(reduced.matches)finish();});
  map.inert=true;
  const loader=document.getElementById('lobby-loader'),progress=document.getElementById('lobby-progress'),detail=document.getElementById('loading-detail');
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const started=performance.now();
  const artwork=[...document.querySelectorAll('.badge-art,.game-brand img')];
  progress.max=2+artwork.length;
  let completed=0;
  const track=promise=>promise.then(value=>{progress.value=++completed;detail.textContent=`${Math.round(completed/progress.max*100)}%`;return value;});
  Promise.all([
    track(load('assets/animation-desk-v1.webp')),
    track(load('assets/animation-map-v2.webp')),
    ...artwork.map(im=>track(im.decode()))
  ]).then(async ([a,b])=>{
    desk=a;paper=b;paperBounds=alphaBounds(paper);drawMap();frame(0);
    window.lobbyAnimation={play,finish,renderAt(ms){cancelAnimationFrame(raf);drawMap();frame(ms);},get ready(){return ready;}};
    await wait(Math.max(0,650-(performance.now()-started)));
    loader.dataset.state='black';
    await wait(reduced.matches?0:180);
    loader.dataset.state='reveal';
    await wait(reduced.matches?0:1200);
    loader.hidden=true;root.inert=false;play();
  }).catch(()=>{
    root.dataset.phase='error';detail.textContent='로비를 불러오지 못했습니다. 다시 시도해 주세요.';
    progress.hidden=true;document.getElementById('loading-retry').hidden=false;skip.hidden=true;
  });
})();
