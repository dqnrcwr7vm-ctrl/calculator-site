/* One streaming media element for the whole game; never decode/preload the catalog. */
(() => {
  'use strict';
  const base=new URL('.',document.currentScript.src);
  let host=null;
  try { if(parent!==window&&parent.GameScreen?.ownsFrame(window)&&parent.DungeonMusic)host=parent.DungeonMusic; }catch{}
  if(host){window.DungeonMusic=host;return;}
  const audio=document.querySelector('#bgm')||document.createElement('audio');
  if(!audio.parentNode){audio.id='dungeon-music';audio.preload='none';document.body.append(audio);}
  const catalog=window.DungeonMusicCatalog||{},positions={};
  let key=audio.id==='bgm'?'title':null,paused=false,ended=false;
  try{const s=JSON.parse(localStorage.getItem('dungeon-breaker-audio')||'{}');audio.muted=!!s.muted;audio.volume=Number.isFinite(s.volume)?Math.max(0,Math.min(1,s.volume)):.65;}catch{audio.volume=.65;}
  function resume(){if(document.querySelector('.title-screen')?.dataset?.phase==='exited')return;if(key&&!paused&&!ended&&!document.hidden)audio.play().catch(()=>{});}
  function select(next){
    if(!catalog[next])next=catalog.title?'title':null;
    if(key===next)return;
    if(key)positions[key]=audio.currentTime||0;
    audio.pause();key=next;ended=false;
    if(!next){audio.removeAttribute('src');audio.load();return;}
    const track=catalog[next];audio.loop=track.loop!==false;
    try{if(navigator.mediaSession&&window.MediaMetadata)navigator.mediaSession.metadata=new MediaMetadata({title:track.name||next,artist:'DUNGEON BREAKER',album:'Dungeon Soundtrack'});}catch{}
    audio.src=new URL(track.file,base).href;audio.preload='metadata';
    try{audio.currentTime=next==='title'?(positions.title||0):0;}catch{}resume();
  }
  audio.addEventListener('ended',()=>{if(!audio.loop)ended=true;});
  document.addEventListener('pointerdown',resume,{capture:true});document.addEventListener('keydown',resume,{capture:true});
  document.addEventListener('visibilitychange',()=>document.hidden?audio.pause():resume());
  window.addEventListener('gamescreenhome',()=>{paused=false;select('title');resume();});
  window.DungeonMusic={select,resume,setPaused(value){if(paused===!!value)return;paused=!!value;if(paused)audio.pause();else resume();},get key(){return key;},get audio(){return audio;},get ended(){return ended;}};
})();
