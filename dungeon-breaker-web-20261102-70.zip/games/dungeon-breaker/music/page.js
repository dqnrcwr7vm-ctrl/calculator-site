(() => {
 const path=location.pathname;
 const preparation=path.endsWith('/battle/normal-entry.html')||document.documentElement.classList.contains('initial-draft');
 if(!path.includes('/battle/')||preparation)DungeonMusic.setPaused(false);
 if(path.endsWith('/lobby/index.html')||preparation){DungeonMusic.select('lobby');DungeonMusic.resume();}
 else if(path.endsWith('/lobby/town.html'))DungeonMusic.select('town');
 document.addEventListener('pointerdown',()=>DungeonMusic.resume(),{capture:true});
 document.addEventListener('keydown',()=>DungeonMusic.resume(),{capture:true});
})();
